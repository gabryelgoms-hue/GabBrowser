# GabBrowser

**Navegue livre. Navegue seguro.**

Navegador Android nativo em Kotlin e Jetpack Compose, sobre o Android System WebView.

## Estado atual: versão 1.0.0 (Etapas 1 a 5 no código)

> **Ainda não compilada nem testada no aparelho.** O código foi escrito sem compilador Kotlin nem Android SDK.
> A lógica de segurança foi testada fora do Android e o código passou por três revisões independentes
> (`docs/RELATORIO-SEGURANCA.md`). Antes de usar para banco, compras ou senhas importantes, compile e faça os
> testes de `docs/TESTES-NO-APARELHO.md`.

### Funcionalidades

- **Navegação:** tela inicial, barra que distingue endereço e pesquisa (Google, Bing, DuckDuckGo), voltar,
  avançar, atualizar, compartilhar, favoritos, tema claro/escuro, vídeo em tela cheia, envio de arquivos,
  abrir links de outros apps.
- **Abas e GabFlow:** cartões com miniatura, busca, grupos (Trabalho, Estudos...), reabertura ao iniciar,
  suspensão automática para poupar memória.
- **Aba anônima:** perfil isolado, apagado ao fechar; sem histórico; print bloqueado.
- **GabShield:** central com números reais e gráfico; alerta de golpes; HTTPS por padrão; permissões por site;
  relatório.
- **GabClean:** bloqueio de anúncios e rastreadores, YouTube, lista ampliada opcional.
- **GabAI:** resumir, explicar, traduzir e perguntar, com chave própria, confirmação e limite diário.
- **GabOne:** limpeza com um toque. **GabSaver:** economia de dados com relatório.
- **GabReader:** modo leitura, voz, artigos offline. **GabScan:** QR Code verificado antes de abrir.
- **Senhas:** cofre cifrado, digital/PIN para ver e preencher, só no mesmo site.
- **Downloads, favoritos com pastas, histórico com busca.**

Decisões técnicas: `docs/DECISOES.md` (D1 a D29).

### Limitações conhecidas

- Sincronização (GabSync) não existe: a arquitetura está preparada, mas exige criptografia de ponta a ponta e
  um servidor, que não foram construídos.
- Proteção contra fingerprinting limitada a bloquear scripts conhecidos (limite do WebView).
- O bloqueio do YouTube depende do site atual do YouTube e pode precisar de ajuste quando ele mudar.
- Downloads sem pausa manual (limite do Android) e sem suporte a arquivos gerados pela página (`blob:`).
- GabReader salva só o texto dos artigos, sem imagens.
- As bibliotecas são versões estáveis de dezembro de 2024; atualizar para as mais novas depois que esta versão
  compilar (o Dependabot do repositório propõe as atualizações).

## Como gerar o APK assinado pelo GitHub (sem computador)

1. No repositório, abra **Settings > Secrets and variables > Actions** e crie dois segredos:
   `SIGNING_KEY_BASE64` e `SIGNING_KEY_PASSWORD` (os valores vêm do arquivo de segredos entregue à parte).
2. Troque o conteúdo de `.github/workflows/apk.yml` pelo de `docs/apk.yml`.
3. Envie o zip do projeto. Em **Actions**, baixe **GabBrowser-release-apk** (assinado) ou **GabBrowser-debug-apk**.

Instale o release no lugar do debug: como as assinaturas são diferentes, desinstale o de depuração antes
(favoritos e histórico da versão de teste se perdem). Daí em diante, as próximas versões de release instalam
por cima, desde que assinadas com a mesma chave.

## Como gerar só o APK de depuração pelo GitHub

1. Envie este projeto para um repositório no GitHub, na branch `main`.
2. Abra a aba **Actions** do repositório e espere o fluxo **Build GabBrowser** terminar.
3. Na página da execução, baixe o artefato **GabBrowser-debug-apk** e extraia o `.apk`.
4. No celular, abra o `.apk` e permita a instalação de apps dessa origem.

Se a execução ficar vermelha, o erro de compilação está no passo que falhou; copie a mensagem para corrigir.

## Como compilar no Android Studio

Abra a pasta do projeto, aguarde a sincronização do Gradle e rode o módulo `app`.
Requer JDK 17 ou mais novo. Pela linha de comando, com Gradle 8.9 instalado:

```
gradle :core:common:test
gradle :app:assembleDebug
```

O APK sai em `app/build/outputs/apk/debug/`.

## Estrutura

```
app/                 telas e ligação entre módulos
core/common/         regras puras (barra de endereço, política de navegação) + testes
core/engine/         contrato do motor e implementação WebView
core/data/           Room e DataStore
core/designsystem/   tema, cores e logotipo
docs/DECISOES.md     registro das decisões técnicas
```

## Roteiro

1. **Fundação** — concluída (0.1.0).
2. **Navegador** — concluída no código (0.3.0), falta testar no aparelho.
3. **Segurança** — concluída no código (0.4.0), falta testar no aparelho.
4. **Diferenciais** — concluída no código (0.5.0 e 0.6.0), falta testar no aparelho.
5. **Finalização** — no código (1.0.0): funções que faltavam, três auditorias, assinatura de release. Falta: compilar e testar no aparelho.
6. **Futuro** — GabSync com criptografia de ponta a ponta.
