# Testes de segurança no aparelho

Testes que só podem ser feitos com o app instalado. Anote o número de qualquer item que não der o resultado esperado.

## Conexão e certificados

| # | Faça | Resultado esperado |
|---|---|---|
| 1 | Abra `expired.badssl.com` | Tela "Conexão não segura", sem botão de continuar |
| 2 | Abra `wrong.host.badssl.com` | Mesma tela |
| 3 | Abra `self-signed.badssl.com` | Mesma tela |
| 4 | Abra `untrusted-root.badssl.com` | Mesma tela |
| 5 | Depois do item 4, abra `wikipedia.org` | Cadeado azul, sem tela de erro |
| 6 | Abra `mixed-script.badssl.com` | Página abre com cadeado e o script http embutido nela não é carregado |
| 7 | Abra `http.badssl.com` | Tela "Site sem HTTPS" com opção de abrir assim mesmo |
| 8 | No item 7, toque em "Abrir sem HTTPS" | Abre com alerta vermelho no endereço; o site aparece no GabShield > Sites abertos sem HTTPS |
| 9 | Digite `javascript:alert(1)` na barra | Vira pesquisa; nenhum alerta aparece |
| 10 | Digite `file:///sdcard/` na barra | Vira pesquisa; nenhum arquivo aparece |

## Golpes e sites maliciosos

| # | Faça | Resultado esperado |
|---|---|---|
| 11 | Digite `nubank-seguranca.com` | Tela "Este site pode ser um golpe" com os motivos (o site nem precisa existir) |
| 12 | Digite `g00gle.com` | Mesmo aviso, citando a troca de letras |
| 13 | Digite `paypal.com.login-verificar.xyz` | Mesmo aviso |
| 14 | Abra `testsafebrowsing.appspot.com` e toque no primeiro link de phishing | Aviso vermelho da Navegação Segura; o contador "Tentativas suspeitas" do GabShield sobe |
| 15 | Abra `nubank.com.br`, `gov.br`, `caixa.gov.br`, `g1.globo.com` | Abrem normalmente, sem aviso |

## Aba anônima

| # | Faça | Resultado esperado |
|---|---|---|
| 16 | Em aba anônima, entre em um site com login (ex.: `github.com/login`) e faça login | Funciona |
| 17 | Abra uma aba normal no mesmo site | Você **não** está logado |
| 18 | Feche todas as abas anônimas e abra outra anônima no mesmo site | Você **não** está mais logado |
| 19 | Depois de navegar em anônimo, abra Histórico e "Mais acessados" | Nenhum site anônimo aparece |
| 20 | Tente tirar print de uma aba anônima | O Android bloqueia o print |
| 21 | Feche o app à força com uma aba anônima aberta e abra de novo | A aba anônima não volta |

## Permissões

| # | Faça | Resultado esperado |
|---|---|---|
| 22 | Abra `webcamtests.com` e inicie o teste | O GabBrowser pergunta; depois o Android pergunta |
| 23 | Toque em "Bloquear" com "Lembrar" marcado e recarregue | Câmera negada sem perguntar de novo |
| 24 | No escudo, toque em "Redefinir permissões" e teste de novo | Volta a perguntar |
| 25 | Abra `maps.google.com` e toque em "Sua localização" | Mesmo fluxo para localização |

## Downloads

| # | Faça | Resultado esperado |
|---|---|---|
| 26 | Baixe um PDF qualquer | Confirmação com nome, tamanho e site; arquivo aparece em Downloads e abre |
| 27 | Tente baixar um arquivo `.apk` (ex.: F-Droid em `f-droid.org`) | Confirmação com aviso vermelho de instalador |

## Bloqueador

| # | Faça | Resultado esperado |
|---|---|---|
| 28 | Abra `g1.globo.com` | O número no escudo sobe; menos banners |
| 29 | Toque no escudo e desligue o bloqueio no site | A página recarrega com anúncios |
| 30 | Assista a 3 vídeos no YouTube | Sem anúncios, ou anúncios silenciados e pulados |

## Senhas (1.0)

| # | Faça | Resultado esperado |
|---|---|---|
| 31 | Faça login em um site (ex.: `github.com/login`) em aba normal | Pergunta "Salvar senha?"; os botões só ficam ativos depois de um instante |
| 32 | Saia da conta e volte à página de login | Faixa "Preencher"; pede digital/PIN; preenche usuário e senha |
| 33 | Ferramentas > Senhas, toque numa senha | Pede digital/PIN, mostra por 30 s; print da tela é bloqueado |
| 34 | Faça login em aba anônima | Não pergunta se quer salvar |
| 35 | Celular sem bloqueio de tela (se puder testar) | O app não oferece salvar e explica por quê |

## GabScan, GabAI, GabReader (1.0)

| # | Faça | Resultado esperado |
|---|---|---|
| 36 | Leia o QR Code de um site conhecido | Mostra o site antes de abrir; só abre ao tocar em "Abrir" |
| 37 | Leia um QR de Wi-Fi ou Pix | Mostra o texto; só permite copiar |
| 38 | Ferramentas > GabAI, cole sua chave, toque em "Testar chave" | Lista os modelos disponíveis |
| 39 | Num artigo, ⋮ > GabAI > Resumir | Pede confirmação mostrando site e tamanho; depois responde em português |
| 40 | Num artigo, ⋮ > Modo leitura | Texto limpo; A−/A+, Noite, Ouvir e Salvar funcionam |

## Navegador (1.0)

| # | Faça | Resultado esperado |
|---|---|---|
| 41 | Vídeo do YouTube > tela cheia | Ocupa a tela; "voltar" sai da tela cheia |
| 42 | Em um site com envio de arquivo (ex.: formulário de anexo), escolha uma foto | O site recebe a foto |
| 43 | Em outro app (WhatsApp, por exemplo), toque num link e escolha GabBrowser | Abre em aba nova |
| 44 | Compartilhe um texto com o GabBrowser | Pesquisa o texto no buscador escolhido |
| 45 | GabOne > Limpar com tudo marcado | Abas fechadas, logins dos sites saem; favoritos e senhas continuam |
