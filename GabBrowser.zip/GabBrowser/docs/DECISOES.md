# GabBrowser — Registro de decisões técnicas

Este arquivo guarda o que foi decidido e por quê, para o projeto não perder o fio entre sessões.
Cada decisão nova entra no fim, com data.

## D1 — Motor de navegação: Android System WebView (2026-11-10)

Avaliados: GeckoView (Mozilla) e Android System WebView (Chromium).

| Critério | WebView do sistema | GeckoView |
|---|---|---|
| Atualizações de segurança | Chegam pela Play Store, sem recompilar o app | Ficam presas à versão embutida no APK; exige novo APK a cada ~4 semanas |
| Tamanho do APK | Poucos MB | Dezenas de MB por arquitetura |
| Consumo de memória | Motor compartilhado com o sistema | Motor próprio carregado pelo app |
| Compatibilidade com sites | Igual ao Chrome | Muito boa, com exceções pontuais |
| Bloqueio de rastreadores nativo | Não tem; precisa ser construído (GabShield) | Tem (Enhanced Tracking Protection) |
| Modo anônimo isolado | Via perfis do androidx.webkit, quando o WebView do aparelho suporta | Nativo |
| Manutenção | API estável há anos | API muda a cada versão |

**Decisão:** WebView do sistema.

**Motivo principal:** o projeto é mantido por uma pessoa, sem ciclo fixo de lançamentos. Com GeckoView, cada
mês sem novo APK deixaria o navegador com falhas de motor já públicas. Com o WebView, as correções do
Chromium chegam ao aparelho mesmo que o GabBrowser não seja atualizado.

**Custo assumido:** o bloqueio de rastreadores e anúncios (GabShield/GabClean) terá de ser implementado
pelo app, interceptando requisições; a proteção contra fingerprinting será limitada ao que o WebView permite;
o isolamento do modo anônimo depende da API de perfis do WebView e precisa de alternativa para aparelhos
sem suporte.

**Saída prevista:** as telas só conhecem a interface `EngineSession` (`core/engine`). Trocar para GeckoView
no futuro significa escrever outra implementação dessa interface.

## D2 — Somente HTTPS na Etapa 1 (2026-11-10)

`usesCleartextTraffic=false` e `network_security_config` sem tráfego em texto puro. Toda navegação `http://`
é reescrita para `https://`. Se o site devolver para http, a página mostra "Site sem HTTPS" e não abre.

Sites que só existem em http ficam inacessíveis nesta etapa. O acesso com aviso explícito e exceção por site
entra com o GabShield (Etapa 3), que é onde ficam as demais decisões de conexão.

## D3 — Erros de certificado não têm botão "continuar" (2026-11-10)

`onReceivedSslError` sempre cancela a carga. Não existe caminho de código que chame `proceed()`.
Certificados instalados pelo usuário também não são aceitos (`trust-anchors` só com `system`).

## D4 — Política de esquemas de URL (2026-11-10)

`NavigationPolicy` (em `core/common`, com testes): https permitido; http reescrito; `about:blank` permitido;
todo o resto bloqueado (`file:`, `content:`, `javascript:`, `data:`, `intent:`, `market:`, `tel:`, `mailto:`).

Consequência: links que abririam outros apps (telefone, e-mail, loja) não funcionam ainda. Entram na Etapa 3
com confirmação do usuário antes de sair do navegador.

Na barra de endereço, texto com esquema diferente de http/https vira pesquisa, assim como endereços no
formato `usuario@host`.

## D5 — Configuração do WebView (2026-11-10)

- JavaScript ligado (necessário para a web atual); nenhuma `addJavascriptInterface`.
- Acesso a arquivos e a content providers desligado.
- Conteúdo misto bloqueado (`MIXED_CONTENT_NEVER_ALLOW`).
- Cookies de terceiros desligados.
- Câmera, microfone e localização: todo pedido é negado até existir a tela de permissões (Etapa 3).
- Janelas pop-up por script desligadas.
- Navegação Segura do WebView ligada; envio de métricas do WebView desligado.

## D6 — Arquitetura em módulos (2026-11-10)

- `core/common`: Kotlin puro, sem Android. Classificador da barra de endereço, mecanismos de pesquisa e
  política de navegação. É onde ficam os testes unitários.
- `core/engine`: contrato do motor e implementação WebView.
- `core/data`: Room (histórico, favoritos) e DataStore (preferências).
- `core/designsystem`: cores, tema claro/escuro e logotipo em vetor.
- `app`: telas em Jetpack Compose e ligação entre os módulos.

Sem framework de injeção de dependência por enquanto: `GabApplication` cria os repositórios.
A Activity declara `configChanges` para que a rotação da tela não destrua o WebView.

## D7 — Dados locais (2026-11-10)

Histórico e favoritos em Room, preferências em DataStore, tudo em armazenamento interno do app.
Backup em nuvem e transferência entre aparelhos desligados (`allowBackup=false` + `data_extraction_rules`).
Única permissão no manifesto: `INTERNET`. Sem analytics e sem SDK de terceiros.

## D8 — Versões e build (2026-11-10)

minSdk 26 (Android 8.0), targetSdk/compileSdk 35. AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21, Compose BOM 2024.12.01.
São versões estáveis e compatíveis entre si, mas não as mais novas; o Dependabot (`.github/dependabot.yml`)
abre pedidos de atualização semanalmente. Atualizar tudo e conferir avisos de vulnerabilidade faz parte da Etapa 5.

Package: `com.gabbrowser.android`. versionCode 1, versionName 0.1.0.

Compilação pelo GitHub Actions (`.github/workflows/build.yml`), que roda os testes de `core/common` e gera o
APK de depuração. A assinatura de release fica para a Etapa 5, com a chave fora do repositório.

## Pendências conhecidas para a auditoria de segurança (Etapa 5)

- A barra de endereço passa a mostrar a URL de destino assim que a carga começa; conferir em aparelho se há
  janela em que o conteúdo antigo aparece com o endereço novo.
- Confirmar em aparelho a ordem dos eventos do WebView em erro de certificado (o cadeado nunca pode aparecer
  numa página de erro).
- Confirmar que o WebView do aparelho respeita `trust-anchors` do `network_security_config`.
- Diálogos JavaScript (`alert`, `confirm`) usam a janela padrão do WebView; avaliar limite contra abuso.
- A Navegação Segura depende dos serviços do Google no aparelho; sem eles não há proteção contra phishing
  nesta etapa.

## D9 — GabClean: bloqueio por domínio na camada de rede (2026-11-11)

O WebView não tem bloqueador nativo. O GabClean intercepta cada requisição de subrecurso em
`shouldInterceptRequest` (e, para service workers, em `ServiceWorkerClientCompat`) e responde
localmente com um corpo vazio quando o domínio está numa lista. O servidor de anúncio nunca é contatado.

Regras (`core/common/blocking/BlockRules.kt`, com testes):
- a página principal nunca é bloqueada: o que o usuário abriu sempre abre;
- requisições do próprio site (mesmo domínio registrável) não são bloqueadas pelas listas, para não quebrar
  sites que servem conteúdo de subdomínios;
- exceções por site desligam tudo naquele site e nos subdomínios;
- caminhos de anúncio do próprio YouTube (`/pagead/`, `/api/stats/ads`, `/ptracking`, `/get_midroll_info`,
  `/ad_break`) são bloqueados mesmo sendo do próprio site.

Listas:
- **Embutida padrão**: 112 domínios que só servem anúncio ou rastreamento.
- **Embutida rigorosa**: acrescenta domínios que às vezes carregam função do site (Google Tag Manager,
  SDK do Facebook, SDK de anúncio em vídeo).
- **Lista ampliada (opcional)**: AdGuard DNS filter, baixada só quando o usuário toca em "Baixar lista".
  Lida pelo `FilterListParser`, que aceita apenas regras de domínio (`||dominio^`, `@@||dominio^`, formato hosts)
  e ignora o resto. Limite de 8 MB e de 300 mil regras; menos de mil regras é tratado como download inválido.

Não há bloqueio cosmético completo como no uBlock Origin: só um CSS pequeno e específico que esconde os espaços
de anúncio que ficam vazios.

## D10 — GabClean no YouTube (2026-11-11)

Os anúncios do YouTube vêm dos mesmos servidores dos vídeos, então bloqueio por domínio não basta.
Um script (`ContentScripts.YOUTUBE`) é injetado no início do documento, só nas origens do YouTube,
via `WebViewCompat.addDocumentStartJavaScript`:
1. remove `adPlacements`, `adSlots` e `playerAds` das respostas do player (`JSON.parse`, `Response.json`
   e `ytInitialPlayerResponse`), a mesma técnica dos bloqueadores conhecidos;
2. se um anúncio tocar mesmo assim, silencia, avança até o fim, toca em "Pular" e restaura o som depois;
3. esconde blocos patrocinados do feed.

Sem suporte a script no início do documento (WebView antigo), o script entra quando a página aparece:
a camada 2 funciona, a 1 só a partir da navegação seguinte dentro do YouTube. A tela do GabClean avisa qual modo está ativo.

Limitação assumida: o YouTube muda o site para driblar bloqueadores. O script vai precisar de manutenção.

## D11 — Contagem real e canal de mensagens restrito (2026-11-11)

Números do GabClean vêm de eventos reais: cada requisição respondida localmente conta 1; cada resposta do player
da qual o script removeu anúncios, ou cada anúncio pulado, conta 1 em "YouTube". As contagens são somadas em
memória e gravadas em lote (3 s) num banco separado (`gabclean.db`), para não pesar na navegação nem exigir
migração do banco de histórico.

Para o script do YouTube avisar o app, foi usado `addWebMessageListener` em vez de `addJavascriptInterface`:
o objeto só existe nas origens do YouTube, não expõe métodos nativos e o app só aceita as mensagens fixas
"pruned" e "skipped". Um site do YouTube adulterado poderia, no máximo, inflar esse contador.

## D12 — Ajustes vindos do primeiro teste no aparelho (2026-11-11)

- Rótulos da barra inferior em uma linha (11 sp, sem quebra): "Ferramentas" quebrava em telas estreitas.
- "Mais acessados" agrupado por site: páginas diferentes do mesmo site viravam atalhos repetidos.

## D13 — Várias abas e memória (2026-11-11)

`TabManager` (app) mantém as abas. Cada aba tem sua própria sessão do motor, mas no máximo 4 ficam carregadas.
As que passam disso, começando pela usada há mais tempo, são suspensas: o histórico de voltar/avançar é guardado
com `WebView.saveState` e a página recarrega quando a aba volta. A aba em uso nunca é suspensa.
Abas em segundo plano recebem `onPause` (menos processamento e bateria).

Downloads não dependem da aba: correm no gerenciador de downloads do Android.

As abas normais (só endereço e título) são gravadas no aparelho e reabertas na próxima vez; isso também cobre
encerramento inesperado. Abas anônimas nunca são gravadas.

## D14 — Abas anônimas (2026-11-11)

Usam um perfil separado do WebView (`ProfileStore`, recurso `MULTI_PROFILE` do androidx.webkit): cookies,
armazenamento dos sites e cache não se misturam com a navegação normal. Todas as abas anônimas abertas ao mesmo
tempo compartilham esse perfil (como nos outros navegadores). Quando a última é fechada, cookies e armazenamento
são apagados na hora e o perfil é excluído logo depois; ao abrir o app, restos de uma sessão anônima interrompida
são apagados antes de tudo.

Sem histórico, sem entrada em "Mais acessados", sem restauração de abas. A janela recebe `FLAG_SECURE`
(sem print e sem miniatura nos apps recentes) e o app fica no tema escuro enquanto a aba anônima está à frente.

Sem suporte a perfis no WebView do aparelho, o modo anônimo não abre: o app explica e pede para atualizar o
WebView, em vez de oferecer um modo anônimo que misturaria os cookies.

Limitações: o filtro do GabClean para service workers só cobre o perfil normal; downloads de abas anônimas
ficam na pasta Downloads (o arquivo é do usuário), só não entram na lista do app.

## D15 — GabDownload (2026-11-11)

Usa o `DownloadManager` do Android: continua com o app fechado, mostra notificação e retoma sozinho após queda
de rede. Antes de baixar, o app mostra nome, tamanho e site, com aviso extra para instaladores (.apk, .exe etc.).
Endereços http viram https; `blob:` e `data:` (arquivos gerados pela página) ainda não são suportados.
Android 10+: pasta Downloads pública, sem permissão. Android 8 e 9: pasta do app, para não pedir permissão de
armazenamento. Pausa manual não existe no `DownloadManager`; a tela explica isso.

## D16 — Banco de dados versão 2 (2026-11-11)

Pastas de favoritos (`bookmark_folders` + coluna `folderId`) e lista de downloads (`downloads`).
Migração manual 1→2 preserva histórico e favoritos de quem já usa a 0.1/0.2.

## D17 — GabAI: chave do próprio usuário (decisão do Gabriel, 2026-11-11)

O GabAI vai usar a API da Anthropic com uma chave que o usuário cria e cola no app. A chave fica guardada
cifrada com o Android Keystore, só no aparelho, nunca no código nem no repositório. Haverá limite de gasto
configurável e confirmação antes de enviar o conteúdo de qualquer página. Implementação na Etapa 4.

## D18 — GabShield: alerta de golpes local (2026-11-11)

`SuspicionAnalyzer` (core/common, com testes) analisa o endereço antes de cada navegação principal, sem enviar
nada para fora. Sinais fortes (risco alto → a página é segurada com aviso):
- letras de outro alfabeto imitando letras latinas (homógrafos), ou imitando uma marca;
- nome de marca conhecida (bancos, lojas, gov.br, redes sociais) em site que não é dela, quando aparece no
  subdomínio de outro site ou junto de palavras de login/pagamento ("nubank-seguranca.com");
- nome do site que vira uma marca ao trocar números por letras ("g00gle", "paypa1", "arnazon").
Sinais fracos (só aparecem no painel do escudo; três juntos viram risco alto): IP público no lugar do nome,
extensões muito usadas em golpes, muitos subdomínios, endereço muito longo, marca sem palavra de login.

O aviso sempre permite continuar (heurística pode errar). O site em que o usuário continuou deixa de ser avisado
e fica listado no GabShield, com opção de voltar a avisar.

A Navegação Segura do WebView (lista do Google) continua ligada; cada alerta dela é contado.

## D19 — Sites sem HTTPS com aviso (2026-11-11), revisa a D2

O `network_security_config` passa a permitir texto puro no nível do sistema, porque o WebView precisa disso para
abrir um site http. A decisão continua no app: a `NavigationPolicy` troca todo http por https, e só os sites que o
usuário aceitou no aviso "Site sem HTTPS" abrem em http. Conteúdo misto continua bloqueado em páginas https.
Numa página http já aceita, quadros internos http carregam (a carga inicial de um quadro não passa pela política).
O endereço mostra o alerta vermelho de conexão não segura.

Barreira extra (auditoria, F1): envios de formulário (POST) não passam por `shouldOverrideUrlLoading`, então a
requisição principal também é checada em `shouldInterceptRequest`, antes de sair para a rede: http sem exceção
é barrado e site de golpe recebe o aviso. O aviso "Site sem HTTPS" só aparece quando o próprio servidor
redireciona para http (F2), nunca por navegação feita por script.

## D20 — Permissões por site (2026-11-11)

Câmera, microfone e localização: a página pede, o GabBrowser pergunta ("Permitir"/"Bloquear", com opção de lembrar)
e, se permitido, o Android pede a permissão do app na primeira vez. Decisões ficam por origem e podem ser
removidas no GabShield ou no painel do escudo. Abas anônimas perguntam sempre e não gravam decisão.
DRM e MIDI são sempre negados. Só origens https podem pedir. Permissões novas no manifesto: câmera, microfone,
ajuste de áudio (WebRTC) e localização, usadas apenas nesse fluxo.

## D21 — GabShield Center e níveis (2026-11-11)

Números exatos e locais: rastreadores e anúncios (GabClean), anúncios do YouTube, tentativas suspeitas
(avisos do GabShield + alertas da Navegação Segura), sites protegidos (sites em que houve ao menos um bloqueio),
gráfico de bloqueios dos últimos 7 dias. "Dados economizados" é a única estimativa (20 KB por requisição
bloqueada) e a tela diz isso.

Níveis: Padrão (GabClean padrão + alertas), Avançada (GabClean rigoroso, que inclui scripts de fingerprinting
conhecidos) e Personalizada. Proteção contra fingerprinting fica limitada a bloquear esses scripts: o WebView não
permite alterar o que a página consegue medir do aparelho sem quebrar sites.

O banco do GabClean vai para a versão 2 (tabelas `daily_blocks` e `protected_sites`, migração preserva contagens).

## D22 — GabAI (2026-11-11)

API da Anthropic (`POST /v1/messages`, cabeçalhos `x-api-key` e `anthropic-version: 2023-06-01`) chamada pelo
próprio app com a chave do usuário (decisão D17).
- Chave cifrada com AES-256-GCM; a chave AES fica no Android Keystore (`KeystoreCipher`). Nunca no código.
- O nome exato do modelo muda com o tempo: o padrão é o mais econômico conhecido e o botão "Testar chave" lista
  os modelos que a chave pode usar (`GET /v1/models`), para o usuário escolher.
- Consentimento a cada conversa: o app mostra quanto texto, de qual site e para qual serviço, antes de enviar.
  Só vai o texto da página (ou do trecho selecionado, até 15 mil caracteres) e as perguntas. Histórico, outras
  abas, cookies e senhas nunca saem.
- Defesa contra injeção de instruções: o texto da página vai dentro de `<conteudo>` e o prompt de sistema manda
  tratá-lo como dado não confiável. Não é garantia absoluta; por isso a IA não tem nenhuma ferramenta nem acesso
  ao navegador, só devolve texto.
- Custo: limite diário de tokens (padrão 50 mil), contado pelos números de uso que a própria API devolve.
- Endereço do serviço configurável (só https), para um backend próprio no futuro.
- Painel na parte de baixo da tela; a página continua visível. Uma conversa por aba.

## D23 — GabOne, GabFlow, GabSaver (2026-11-11)

- GabOne: botão único que executa as ações marcadas (histórico, cookies, dados de sites, cache, fechar abas,
  abrir anônima depois), sempre com confirmação. Favoritos, senhas e arquivos baixados não fazem parte das ações.
- GabFlow: grupos de abas com categorias sugeridas (Trabalho, Estudos, Pessoal, Entretenimento, Compras) e grupos
  próprios; filtro por grupo na tela de abas; o grupo é salvo com a sessão.
- GabSaver: não carregar imagens; modo leve (2 abas carregadas em vez de 4). Relatório: bytes recebidos pelo app
  desde a abertura (medidos pelo Android, `TrafficStats`) e a estimativa do GabClean, identificada como estimativa.

## D24 — GabReader (2026-11-11)

Um script do próprio app (`ReaderScript`, nunca código vindo de sites) escolhe o bloco com mais texto
(article, main ou body), ignora menus, rodapés, comentários e formulários, e devolve só título e parágrafos em JSON.
A tela de leitura tem tamanho de letra, espaçamento, fonte, modo noturno e leitura em voz alta pelo motor de voz
do Android (nada sai do aparelho). "Salvar" grava o texto na pasta interna do app para ler offline (sem imagens).

## D25 — GabScan (2026-11-11)

CameraX + ZXing (biblioteca de código aberto, sem serviços do Google). A imagem é analisada no aparelho e
descartada. O resultado nunca abre sozinho: o app mostra o site de destino e passa pela mesma política de esquemas
e pelo mesmo alerta de golpes da barra de endereço. Códigos que não são link de site (Wi-Fi, telefone, Pix,
intent:) só podem ser copiados.

## D26 — Senhas (2026-11-11)

- Salvar é opcional e sempre perguntado (com "Nunca neste site"). Nunca em aba anônima. Só em páginas https.
- Armazenamento: banco próprio (`vault.db`); a senha só existe cifrada com AES-256-GCM, chave no Android Keystore.
  Site e usuário ficam em claro para a lista.
- Ver ou preencher exige autenticação do Android (digital, rosto, ou o PIN/padrão/senha do aparelho, que é o
  "PIN alternativo"). Sem bloqueio de tela configurado, o app não oferece salvar nem abre o cofre.
- Captura: script do app no quadro principal manda usuário e senha por um canal de mensagens. A origem usada é a
  informada pelo WebView, não pela página, então um site não consegue gravar senha em nome de outro.
- Preenchimento: só depois da autenticação e só se a página ainda estiver na mesma origem em que a senha foi
  salva (esquema + host + porta). Isso protege contra páginas falsas com outro endereço. Os valores entram no
  script como literais JSON escapados, nunca como código.
- Senha revelada some da tela em 30 s; cópia marcada como sensível no Android 13+.
- Sem sincronização (D17/GabSync fica para o futuro, com criptografia de ponta a ponta).

## D27 — Correções da revisão das Etapas 4 (2026-11-11)

- Cofre de senhas (`VaultCrypto`): cada senha cifrada com AES-256-GCM própria; essa chave embrulhada com RSA-OAEP.
  A chave privada RSA fica no Keystore e só funciona até 30 s depois da digital/rosto forte/PIN do aparelho, com
  o aparelho desbloqueado. Comparação de senha já salva por HMAC, sem decifrar. Android 11+: autenticação
  biométrica forte ou PIN; antes disso, a combinação disponível no Android.
- Preenchimento: o próprio script confere `location.origin` e se está no quadro principal antes de escrever.
- Oferta de salvar: no máximo uma por página carregada, intervalo mínimo de 5 s, botões ativos após 0,7 s.
- Tela de senhas sem print; área de transferência limpa após 45 s.
- GabScan: links com barra invertida, espaços, caracteres invisíveis ou "@" antes do caminho são recusados
  (o endereço mostrado seria diferente do aberto).
- GabAI: texto da página não consegue abrir/fechar `<conteudo>`; corte de tamanho também no app; estimativa de
  tokens antes de enviar; conversa limitada às 12 mensagens mais recentes (a primeira, com a página, fica);
  sem seguir redirecionamentos (a chave não vai para outro servidor); envio cancelado se a página mudar entre a
  leitura e a confirmação; o diálogo diz que título e endereço também vão.
- GabReader: "Salvar" não aparece para artigos de aba anônima; nomes de arquivo por SHA-256.
- GabOne espera a confirmação da remoção de cookies e grava a sessão vazia na hora.

## D28 — Etapa 5: funções de navegador que faltavam (2026-11-11)

- Vídeo em tela cheia (`onShowCustomView`), por cima da página, com as barras do sistema escondidas.
- Envio de arquivos em formulários (`onShowFileChooser`) pelo seletor do Android; o site só recebe o que o
  usuário escolhe.
- Abrir links de outros apps (VIEW http/https), "Compartilhar com GabBrowser" e pesquisa do sistema. Tudo passa
  pela barra de endereço, política de esquemas e alerta de golpes, e abre em aba nova normal.
- Cancelamento de pedido de permissão pela página fecha o diálogo; WebView com renderizador caído não é mais
  desenhado nem salvo.

## D29 — APK de release (2026-11-11)

Assinatura com chave RSA 4096 (PKCS12), gerada fora do repositório e entregue ao dono do projeto para ser guardada
como segredo do GitHub (`SIGNING_KEY_BASE64`, `SIGNING_KEY_PASSWORD`). O Gradle só lê a chave de variáveis de
ambiente; sem elas, gera apenas o APK de depuração. A receita (`docs/apk.yml`) decodifica a chave numa pasta
temporária do servidor e a apaga no fim. Sem ofuscação (R8) nesta versão, para não arriscar um APK que quebre
sem ter sido testado.

## D30 — Ícone oficial, lista semanal e receita fixada (1.0.0)
- Ícone do app: o símbolo da marca, recortado da imagem oficial e pintado em #1769E8 sobre fundo branco,
  com camada monocromática para os ícones temáticos do Android 13+.
- Lista do AdGuard: se o usuário já a baixou, o app a atualiza sozinho uma vez por semana, 15 s depois de abrir.
  Sem download prévio, nada é baixado.
- Receita do GitHub: roda só no `main`, e cada action é fixada pelo commit exato, não por uma tag que poderia mudar.
