# Relatório de segurança — GabBrowser 1.0.0

Data: 11/11/2026. Escopo: todo o código do repositório (app, core/common, core/engine, core/data,
core/designsystem), manifesto, configurações, assinatura e receita de compilação.

**Este relatório não classifica o navegador como seguro.** O código da 1.0.0 ainda não foi compilado nem
executado: não havia compilador Kotlin nem Android SDK no ambiente de desenvolvimento. Os testes abaixo cobrem a
lógica e o código. Os testes com o app rodando estão em `TESTES-NO-APARELHO.md` (45 itens) e precisam ser feitos
antes de usar o navegador para banco, compras ou senhas importantes.

Nenhuma proteção é absoluta. A segurança deve ser revisada a cada nova versão.

## 1. O que foi executado

| Teste | Como | Resultado |
|---|---|---|
| Regras de navegação, barra de endereço e bloqueio (todos os casos dos testes unitários Kotlin + casos de ataque) | Porte fiel das regras para Python | 108 de 108 aprovados |
| Alerta de golpes, 33 endereços reais e de ataque (inclui homógrafos em Unicode e punycode) | Porte fiel para Python | 0 falhas |
| Script do YouTube | Node.js com página simulada | Aprovado |
| Preenchimento de senha: mesma origem, outra origem, dentro de iframe, injeção de código pelo usuário/senha | Node.js com página simulada | Preenche só na mesma origem e no quadro principal; injeção tratada como texto |
| Captura de senha: envio de formulário, envio repetido | Node.js | Uma oferta, sem repetição |
| Sintaxe de todos os scripts injetados (GabClean, YouTube, senhas, GabReader) | `node --check` | Aprovado |
| Verificações estáticas (WebView, manifesto, certificados, segredos, logs, aba anônima, downloads) | Script sobre o código-fonte | 35 de 35 |
| Conferência de nomes, imports e sintaxe dos 55 arquivos Kotlin | Script | Sem problemas |
| Revisão de código guiada pelo OWASP MASVS | 3 rodadas com revisores independentes (que não escreveram o código) | 42 achados, nenhum crítico ou alto |

**Não executado:** testes unitários Kotlin no Gradle (rodam no GitHub Actions a cada compilação), testes no
aparelho, análise de dependências contra base de vulnerabilidades (sem rede no ambiente; o Dependabot está
configurado no repositório).

## 2. Achados e situação

### Rodada 1 — Etapas 1 a 3 (F1–F14)

| ID | Gravidade | Problema | Situação |
|---|---|---|---|
| F1 | Média | Envio de formulário (POST) para http ou site de golpe passava sem checagem | Corrigido |
| F2 | Média | Script podia forçar o aviso "Site sem HTTPS" para qualquer site | Corrigido |
| F3 | Média | Cookies de aba anônima iam para o gerenciador de downloads | Corrigido (abas normais ainda enviam cookies; ver pendências) |
| F4 | Média | Decisões e estatísticas de aba anônima vazavam para a navegação normal | Corrigido |
| F5 | Baixa | "Lembrar permissão" vinha marcado | Corrigido |
| F6 | Baixa | Pedido de permissão pendente / sem cancelamento | Corrigido |
| F7 | Baixa | Homógrafo em Unicode escapava da análise | Corrigido |
| F8 | Baixa | Nome de download podia esconder a extensão | Corrigido |
| F9 | Baixa | Erro de banco derrubava o app | Corrigido |
| F10 | Baixa | WebView com renderizador caído continuava em uso | Corrigido (A3) |
| F11–F14 | Informativas | Lista sem assinatura; detecção do bloqueador; documentação; APK de depuração | Aceitos/documentados; release assinado entregue (F14) |

### Rodada 2 — Etapa 4 (V1–V13)

| ID | Gravidade | Problema | Situação |
|---|---|---|---|
| V1 | Média | Origem do preenchimento conferida só no app | Corrigido: o script confere `location.origin` e quadro principal |
| V2 | Média | Chave do cofre não exigia autenticação | Corrigido: RSA no Keystore exige digital/PIN nos últimos 30 s |
| V3 | Baixa | Site podia abrir o "Salvar senha?" quando quisesse | Corrigido: 1 oferta por página, intervalo, botões com atraso |
| V4 | Baixa | Senha revelada aparecia em print; área de transferência não era limpa | Corrigido |
| V5 | Média | QR Code podia mostrar um site e abrir outro | Corrigido: endereços disfarçados são recusados |
| V6 | Média | Texto da página podia sair da marcação da IA | Corrigido (A10 incluído) |
| V7 | Baixa/Média | Limite de custo da IA podia ser furado | Corrigido |
| V8 | Baixa | Consentimento podia mostrar outro site | Corrigido |
| V9 | Baixa | Chave da IA podia seguir redirecionamento | Corrigido |
| V10 | Baixa | Artigo de aba anônima salvo em disco | Corrigido |
| V11 | Baixa | Câmera ligada depois de fechar a tela | Corrigido |
| V12 | Baixa | GabOne não esperava a remoção de cookies | Corrigido |
| V13 | Informativa | Normalização de origem; preenchimento em aba anônima | Corrigido / documentado |

### Rodada 3 — auditoria final (A1–A15)

| ID | Gravidade | Problema | Situação |
|---|---|---|---|
| A1 | Média | Vídeo em tela cheia continuava por cima após troca de aba (inclusive de aba anônima) | Corrigido |
| A2 | Média | Diálogo de permissão sem atraso (toque induzido) | Corrigido |
| A3 | Média (incerto) | Comandos em WebView com renderizador caído | Corrigido: comandos recusados e aba recriada |
| A4 | Média | Artigo lido em aba anônima continuava disponível | Corrigido |
| A5 | Baixa | Limpeza da área de transferência não funcionava em segundo plano | Corrigido |
| A6 | Baixa | Outro app podia derrubar o navegador com extras malformados | Corrigido |
| A7 | Baixa | Link externo na abertura usava o buscador padrão | Corrigido |
| A8 | Baixa | Defeito do Keystore derrubava o app | Corrigido |
| A9 | Baixa | Envio de vários arquivos | Corrigido |
| A10 | Baixa | Caracteres invisíveis furavam a marcação da IA | Corrigido |
| A11 | Baixa | Resposta enorme do serviço de IA podia esgotar memória | Corrigido |
| A12 | Baixa | Estatística do YouTube em aba anônima; "sites protegidos" fora do GabOne | Corrigido |
| A13 | Baixa | Receita do GitHub: actions por tag; todos os branches | Corrigido: só o branch `main`, actions fixadas pelo commit exato |
| A14 | Informativa | Arquivos da chave de assinatura | `.gitignore` atualizado; chave entregue ao dono para guardar fora do repositório |
| A15 | Informativa | Inundação de abas por outros apps; StrandHogg; detecção do canal de senhas; rosto fraco no Android 8–10 | `taskAffinity` vazio aplicado; demais documentados |

## 3. Verificado e sem problemas (resumo)

- WebView: sem interface JavaScript nativa; sem acesso a arquivos; conteúdo misto bloqueado; Navegação Segura;
  cookies de terceiros bloqueados; pop-ups automáticos bloqueados.
- Certificado inválido sempre bloqueado, sem opção de continuar; só certificados do sistema.
- Política de esquemas por lista de permitidos; links de outros apps passam pela mesma política e pelo alerta de golpes.
- Permissões de câmera, microfone e localização só com decisão do usuário, só para https; DRM e MIDI negados.
- Aba anônima: perfil isolado, apagado ao fechar a última e ao abrir o app; sem histórico, sessão, estatísticas,
  decisões gravadas, downloads listados, artigos salvos ou senhas salvas; print bloqueado.
- Senhas: nunca em texto puro; autenticação exigida pelo Keystore; preenchimento só na mesma origem.
- GabAI: chave cifrada; nada enviado sem confirmação; histórico nunca enviado; só https.
- Manifesto: só a tela principal exportada; backup desligado; sem segredos ou logs no código.
- Assinatura: chave só por variáveis de ambiente; apagada do servidor de compilação ao final.

## 4. Pendências

1. Executar os 45 testes de `TESTES-NO-APARELHO.md` e registrar o resultado aqui.
2. F3: cookies enviados ao gerenciador de downloads em abas normais seguem um eventual redirecionamento para outro site.
3. Compilação com ofuscação (R8) desligada nesta versão; avaliar depois de testada.
4. Dependências: as versões são estáveis, mas de dezembro de 2024; o Dependabot propõe as novas. Fazer a análise com uma ferramenta de vulnerabilidades quando houver rede.
5. Revisar este relatório a cada versão.
