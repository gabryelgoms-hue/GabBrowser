# Regras específicas do GabBrowser para o build de release (Etapa 5).
