package com.gabbrowser.android.ui

import android.content.ActivityNotFoundException
import android.text.format.Formatter
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.data.downloads.DownloadItem
import com.gabbrowser.core.data.downloads.DownloadRequest
import com.gabbrowser.core.data.downloads.DownloadStatus
import com.gabbrowser.core.data.downloads.GabDownloads
import com.gabbrowser.core.designsystem.GabIcons
import kotlinx.coroutines.launch

@Composable
fun DownloadsScreen(downloads: GabDownloads) {
    val items by downloads.items.collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var message by remember { mutableStateOf<String?>(null) }

    ScreenColumn(title = "Downloads") {
        if (items.isEmpty()) {
            Note(
                "Nenhum download ainda. Os arquivos baixados vão para a pasta Downloads do celular " +
                    "e continuam baixando mesmo com o GabBrowser fechado.",
            )
        }
        message?.let {
            Note(it)
            Spacer(Modifier.height(8.dp))
        }
        items.forEach { item ->
            DownloadRow(
                item = item,
                onOpen = {
                    val intent = downloads.openIntent(item)
                    message = if (intent == null) {
                        "O arquivo ${item.fileName} não foi encontrado no aparelho."
                    } else {
                        try {
                            context.startActivity(intent)
                            null
                        } catch (e: ActivityNotFoundException) {
                            "Nenhum app instalado abre este tipo de arquivo."
                        }
                    }
                },
                onDelete = { scope.launch { downloads.deleteFile(item.id) } },
                onForget = { scope.launch { downloads.forget(item.id) } },
            )
        }
        Spacer(Modifier.height(12.dp))
        Note(
            "Pausar e retomar: o Android pausa sozinho quando a internet cai e retoma quando ela volta. " +
                "Pausa manual ainda não é possível. Downloads feitos em abas anônimas não aparecem nesta lista, " +
                "mas o arquivo fica na pasta Downloads.",
        )
    }
}

@Composable
private fun DownloadRow(
    item: DownloadItem,
    onOpen: () -> Unit,
    onDelete: () -> Unit,
    onForget: () -> Unit,
) {
    val context = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }
    val active = item.status == DownloadStatus.RUNNING ||
        item.status == DownloadStatus.PENDING ||
        item.status == DownloadStatus.PAUSED

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = item.status == DownloadStatus.SUCCESSFUL, onClick = onOpen)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Surface(
            modifier = Modifier.size(42.dp),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = GabIcons.Download,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = item.fileName,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val size = { bytes: Long -> Formatter.formatShortFileSize(context, bytes) }
            Text(
                text = when (item.status) {
                    DownloadStatus.PENDING -> "Na fila"
                    DownloadStatus.RUNNING -> if (item.totalBytes > 0) {
                        "${size(item.downloadedBytes)} de ${size(item.totalBytes)}"
                    } else {
                        "${size(item.downloadedBytes)} baixados"
                    }
                    DownloadStatus.PAUSED -> "Aguardando conexão"
                    DownloadStatus.SUCCESSFUL -> "${size(item.totalBytes.coerceAtLeast(item.downloadedBytes))} · toque para abrir"
                    DownloadStatus.FAILED -> "Falhou"
                    DownloadStatus.MISSING -> "Removido do aparelho"
                },
                style = MaterialTheme.typography.bodySmall,
                color = if (item.status == DownloadStatus.FAILED) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
            )
            if (active) {
                Spacer(Modifier.height(6.dp))
                val progress = item.progress
                if (progress != null) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }
        }
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Opções de ${item.fileName}")
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text(if (active) "Cancelar download" else "Apagar arquivo") },
                    onClick = {
                        menuOpen = false
                        onDelete()
                    },
                )
                if (!active) {
                    DropdownMenuItem(
                        text = { Text("Tirar da lista (manter arquivo)") },
                        onClick = {
                            menuOpen = false
                            onForget()
                        },
                    )
                }
            }
        }
    }
}

/** Confirmação antes de baixar: mostra nome, tamanho e origem, com aviso extra para instaladores. */
@Composable
fun DownloadConfirmDialog(
    request: DownloadRequest,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = if (request.isRisky) Icons.Filled.Warning else GabIcons.Download,
                contentDescription = null,
                tint = if (request.isRisky) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            )
        },
        title = { Text("Baixar arquivo?") },
        text = {
            Column {
                Text(
                    text = request.fileName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                )
                val size = if (request.sizeBytes > 0) Formatter.formatShortFileSize(context, request.sizeBytes) else "tamanho desconhecido"
                Text(
                    text = "$size · de ${request.host}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (request.isRisky) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "Este arquivo instala ou executa programas. Só baixe se você confia em ${request.host}: " +
                            "instaladores de sites desconhecidos são a forma mais comum de colocar vírus no celular.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Baixar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
