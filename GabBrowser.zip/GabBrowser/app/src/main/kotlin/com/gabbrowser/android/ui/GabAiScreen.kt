package com.gabbrowser.android.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.data.ai.AiSettings
import com.gabbrowser.core.data.ai.GabAiRepository
import kotlinx.coroutines.launch

private val LIMIT_OPTIONS = listOf(20_000, 50_000, 100_000, 250_000)

@Composable
fun GabAiScreen(ai: GabAiRepository) {
    val settings by ai.settings.collectAsStateWithLifecycle(initialValue = AiSettings())
    val scope = rememberCoroutineScope()
    var keyInput by remember { mutableStateOf("") }
    var keyMessage by remember { mutableStateOf<String?>(null) }
    var models by remember { mutableStateOf<List<String>>(emptyList()) }
    var testing by remember { mutableStateOf(false) }
    var modelInput by remember { mutableStateOf("") }
    var baseUrlInput by remember { mutableStateOf("") }
    var advancedMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(settings.model, settings.baseUrl) {
        modelInput = settings.model
        baseUrlInput = settings.baseUrl
    }

    ScreenColumn(title = "GabAI") {
        Note(
            "Resume, explica e traduz páginas, e responde perguntas sobre o que está aberto. " +
                "Usa a API da Anthropic (Claude) com uma chave sua, cobrada pela Anthropic conforme o uso.",
        )

        GroupTitle("Chave de API")
        if (settings.hasKey) {
            Text(
                text = "Chave configurada e guardada cifrada neste aparelho.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    enabled = !testing,
                    onClick = {
                        testing = true
                        keyMessage = null
                        scope.launch {
                            val result = ai.listModels()
                            testing = false
                            result.onSuccess { list ->
                                models = list
                                keyMessage = if (list.isEmpty()) {
                                    "Chave válida, mas nenhum modelo foi listado."
                                } else {
                                    "Chave válida. Escolha um modelo abaixo (os \"haiku\" são os mais baratos)."
                                }
                            }.onFailure { keyMessage = it.message }
                        }
                    },
                ) { Text("Testar chave") }
                OutlinedButton(onClick = {
                    models = emptyList()
                    scope.launch { ai.removeKey() }
                }) { Text("Remover chave") }
                if (testing) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
            }
        } else {
            OutlinedTextField(
                value = keyInput,
                onValueChange = { keyInput = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Cole sua chave aqui") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                scope.launch {
                    keyMessage = ai.saveKey(keyInput) ?: "Chave salva. Toque em \"Testar chave\" para conferir."
                    keyInput = ""
                }
            }) { Text("Salvar chave") }
            Spacer(Modifier.height(8.dp))
            Note(
                "Como conseguir uma chave: entre no Console da Anthropic (platform.claude.com) com sua conta, " +
                    "adicione créditos em Billing e crie uma chave em API Keys. Nunca compartilhe a chave com ninguém.",
            )
        }
        keyMessage?.let {
            Spacer(Modifier.height(6.dp))
            Note(it)
        }

        if (models.isNotEmpty()) {
            GroupTitle("Modelos disponíveis")
            models.forEach { model ->
                RadioRow(
                    label = model,
                    selected = settings.model == model,
                    onSelect = { scope.launch { ai.setModel(model) } },
                )
            }
        }

        GroupTitle("Limite diário de uso")
        Note("Hoje: ${settings.usedToday} de ${settings.dailyTokenLimit} tokens. Ao chegar no limite, o GabAI pausa até o dia seguinte.")
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LIMIT_OPTIONS.forEach { limit ->
                val selected = settings.dailyTokenLimit == limit
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { scope.launch { ai.setDailyLimit(limit) } },
                    shape = RoundedCornerShape(14.dp),
                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                ) {
                    Text(
                        text = "${limit / 1000} mil",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.labelLarge,
                        color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Note("Um resumo de página comum usa de 2 a 6 mil tokens.")

        GroupTitle("Privacidade")
        Note(
            "Nada é enviado sozinho. Antes de cada conversa, o GabAI mostra o que vai sair do aparelho e pede sua " +
                "confirmação. Só vai o texto da página aberta (ou o trecho selecionado) e suas perguntas. Histórico, " +
                "outras abas, senhas e cookies nunca são enviados. O texto da página é tratado como não confiável, " +
                "para que um site não consiga dar ordens à IA.",
        )

        GroupTitle("Avançado")
        OutlinedTextField(
            value = modelInput,
            onValueChange = { modelInput = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Modelo") },
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = baseUrlInput,
            onValueChange = { baseUrlInput = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Endereço do serviço") },
        )
        Spacer(Modifier.height(4.dp))
        Note(
            "Troque o endereço só para um servidor seu, compatível com a API da Anthropic. " +
                "A chave é enviada para esse endereço.",
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                scope.launch {
                    val urlOk = ai.setBaseUrl(baseUrlInput)
                    if (modelInput.isNotBlank()) ai.setModel(modelInput)
                    advancedMessage = if (urlOk) "Salvo." else "O endereço precisa começar com https://."
                }
            }) { Text("Salvar") }
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = {
                scope.launch {
                    ai.setBaseUrl(GabAiRepository.DEFAULT_BASE_URL)
                    ai.setModel(GabAiRepository.DEFAULT_MODEL)
                    advancedMessage = "Valores originais restaurados."
                }
            }) { Text("Restaurar") }
        }
        advancedMessage?.let { Note(it) }
    }
}
