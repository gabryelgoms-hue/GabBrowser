package com.gabbrowser.android.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.gabbrowser.core.common.NavigationPolicy
import com.gabbrowser.core.common.security.RiskLevel
import com.gabbrowser.core.common.security.SuspicionReport
import com.gabbrowser.core.data.gabshield.GabShieldRepository
import com.google.zxing.BinaryBitmap
import com.google.zxing.ChecksumException
import com.google.zxing.DecodeHintType
import com.google.zxing.FormatException
import com.google.zxing.NotFoundException
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import java.util.concurrent.Executors

/** Resultado da leitura, já analisado antes de qualquer coisa ser aberta. */
private data class ScanResult(
    val text: String,
    /** Endereço que seria aberto (http vira https), ou null quando o código não é um link de site. */
    val url: String?,
    val report: SuspicionReport,
    /** Endereço com truques que fazem o site mostrado ser diferente do site aberto. */
    val disguised: Boolean = false,
)

/**
 * GabScan: lê QR Codes com a câmera, mostra o destino e verifica se parece golpe.
 * Nada é aberto sem o usuário tocar em "Abrir". A imagem da câmera é analisada no aparelho e descartada.
 */
@Composable
fun GabScanScreen(shield: GabShieldRepository, onOpen: (String) -> Unit) {
    val context = LocalContext.current
    var hasCamera by remember { mutableStateOf(isCameraGranted(context)) }
    var asked by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ScanResult?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCamera = granted
        asked = true
    }
    LaunchedEffect(Unit) {
        if (!hasCamera) launcher.launch(Manifest.permission.CAMERA)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
    ) {
        Text(
            text = "GabScan",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.height(12.dp))

        val current = result
        when {
            current != null -> ResultCard(
                result = current,
                onOpen = { current.url?.let(onOpen) },
                onCopy = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("QR Code", current.text))
                },
                onAgain = { result = null },
            )

            !hasCamera -> {
                Note(
                    if (asked) {
                        "Sem acesso à câmera não é possível ler QR Codes. Libere em Configurações > Apps > GabBrowser > Permissões."
                    } else {
                        "O GabScan precisa da câmera para ler o QR Code. A imagem é analisada só no aparelho."
                    },
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Permitir câmera") }
            }

            else -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(24.dp))
                        .border(3.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(24.dp)),
                ) {
                    CameraPreview { text -> result = analyze(text, shield) }
                }
                Spacer(Modifier.height(12.dp))
                Note("Aponte para um QR Code. O GabBrowser mostra para onde ele leva antes de abrir.")
            }
        }
    }
}

private fun isCameraGranted(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

private fun analyze(text: String, shield: GabShieldRepository): ScanResult {
    val trimmed = text.trim()
    // "https://golpe.com\@banco.com.br": o Android lê banco.com.br, o navegador abre golpe.com.
    // Barra invertida, espaços, caracteres invisíveis ou "@" antes do caminho não têm uso legítimo num QR de site.
    val lower = trimmed.lowercase()
    if (lower.startsWith("http://") || lower.startsWith("https://")) {
        val authority = trimmed.substringAfter("://").takeWhile { it != '/' && it != '?' && it != '#' }
        val tricky = trimmed.any { it == '\\' || it.isWhitespace() || Character.getType(it) == Character.FORMAT.toInt() || it.isISOControl() } ||
            authority.contains('@')
        if (tricky) return ScanResult(trimmed, url = null, report = SuspicionReport.SAFE, disguised = true)
    }
    val url = when (val decision = NavigationPolicy.evaluate(trimmed)) {
        is NavigationPolicy.Decision.Allow -> trimmed.takeIf { it.startsWith("https://", ignoreCase = true) }
        is NavigationPolicy.Decision.UpgradeToHttps -> decision.url
        is NavigationPolicy.Decision.Block -> null
    }
    val host = url?.let { android.net.Uri.parse(it).host }
    val report = if (host != null) shield.inspect(host, private = false) else SuspicionReport.SAFE
    return ScanResult(trimmed, url, report)
}

@Composable
private fun ResultCard(result: ScanResult, onOpen: () -> Unit, onCopy: () -> Unit, onAgain: () -> Unit) {
    val risky = result.report.level == RiskLevel.HIGH
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = if (risky) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(
                text = when {
                    result.disguised -> "Cuidado: endereço disfarçado"
                    result.url == null -> "O código contém um texto"
                    risky -> "Cuidado: este link parece golpe"
                    else -> "O código leva para"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = if (risky) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurface,
            )
            Spacer(Modifier.height(8.dp))
            if (result.url != null) {
                Text(
                    text = displayHost(result.url),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (risky) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.primary,
                )
            }
            Text(
                text = result.text.take(500),
                style = MaterialTheme.typography.bodySmall,
                color = if (risky) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (result.report.reasons.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                result.report.reasons.forEach { reason ->
                    Row {
                        Icon(
                            Icons.Filled.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp),
                        )
                        Text(" $reason", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (result.disguised) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Este link usa caracteres que fazem o endereço mostrado ser diferente do site que abriria. " +
                        "É um truque comum de golpe, então o GabBrowser não vai abri-lo.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            } else if (result.url == null && result.text.contains(':')) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Não é um link de site (pode ser Wi-Fi, telefone, Pix ou outro app). O GabBrowser não abre esse tipo de código; copie se precisar.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (result.url != null) {
                    if (risky) {
                        OutlinedButton(onClick = onAgain) { Text("Não abrir") }
                        TextButton(onClick = onOpen) { Text("Abrir mesmo assim", color = MaterialTheme.colorScheme.error) }
                    } else {
                        Button(onClick = onOpen) { Text("Abrir") }
                    }
                }
                OutlinedButton(onClick = onCopy) { Text("Copiar") }
                if (!risky) TextButton(onClick = onAgain) { Text("Ler outro") }
            }
        }
    }
}

@Composable
private fun CameraPreview(onDecoded: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context) }
    val executor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(lifecycleOwner) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        var disposed = false
        val mainExecutor = ContextCompat.getMainExecutor(context)
        providerFuture.addListener(
            {
                val cameraProvider = try {
                    providerFuture.get()
                } catch (e: Exception) {
                    return@addListener
                }
                // A tela pode ter sido fechada antes de a câmera ficar pronta.
                if (disposed) return@addListener
                provider = cameraProvider
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor, QrAnalyzer { text -> mainExecutor.execute { onDecoded(text) } })
                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                } catch (e: IllegalArgumentException) {
                    // Aparelho sem câmera traseira.
                } catch (e: IllegalStateException) {
                    // Câmera em uso por outro app.
                }
            },
            mainExecutor,
        )
        onDispose {
            disposed = true
            provider?.unbindAll()
            executor.shutdown()
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        Box(
            Modifier
                .align(Alignment.Center)
                .size(180.dp)
                .border(2.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(16.dp)),
        )
    }
}

/** Lê o canal de luminância do quadro da câmera e procura um QR Code com o ZXing. */
private class QrAnalyzer(private val onResult: (String) -> Unit) : ImageAnalysis.Analyzer {
    private val reader = QRCodeReader()
    private val hints = mapOf(DecodeHintType.TRY_HARDER to true)

    @Volatile
    private var done = false

    override fun analyze(image: ImageProxy) {
        try {
            if (done) return
            val plane = image.planes[0]
            val buffer = plane.buffer
            val width = image.width
            val height = image.height
            val rowStride = plane.rowStride
            val data = ByteArray(width * height)
            for (row in 0 until height) {
                buffer.position(row * rowStride)
                buffer.get(data, row * width, width)
            }
            val source = PlanarYUVLuminanceSource(data, width, height, 0, 0, width, height, false)
            val decoded = reader.decode(BinaryBitmap(HybridBinarizer(source)), hints)
            done = true
            onResult(decoded.text)
        } catch (e: NotFoundException) {
            // Nenhum QR Code neste quadro.
        } catch (e: ChecksumException) {
            // Leitura incompleta; tenta no próximo quadro.
        } catch (e: FormatException) {
            // Idem.
        } finally {
            reader.reset()
            image.close()
        }
    }
}
