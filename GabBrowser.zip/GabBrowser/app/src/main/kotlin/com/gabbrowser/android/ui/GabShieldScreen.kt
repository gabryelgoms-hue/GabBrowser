package com.gabbrowser.android.ui

import android.content.Intent
import android.text.format.Formatter
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.data.gabclean.GabCleanRepository
import com.gabbrowser.core.data.gabclean.GabCleanSettings
import com.gabbrowser.core.data.gabclean.GabCleanStats
import com.gabbrowser.core.data.gabshield.GabShieldRepository
import com.gabbrowser.core.data.gabshield.GabShieldSettings
import com.gabbrowser.core.data.gabshield.ShieldLevel
import com.gabbrowser.core.designsystem.GabIcons
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

/** Média usada na estimativa de economia de dados por requisição bloqueada. */
private const val ESTIMATED_BYTES_PER_BLOCK = 20L * 1024

@Composable
fun GabShieldScreen(
    shield: GabShieldRepository,
    gabClean: GabCleanRepository,
    onNavigate: (Screen) -> Unit,
) {
    val settings by shield.settings.collectAsStateWithLifecycle(initialValue = GabShieldSettings())
    val clean by gabClean.settings.collectAsStateWithLifecycle(initialValue = GabCleanSettings())
    val stats by gabClean.stats.collectAsStateWithLifecycle(initialValue = GabCleanStats())
    val sites by gabClean.protectedSites.collectAsStateWithLifecycle(initialValue = 0)
    val daily by remember { gabClean.dailyBlocks(7) }.collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val saved = Formatter.formatShortFileSize(context, stats.requests * ESTIMATED_BYTES_PER_BLOCK)
    val fullProtection = clean.enabled && settings.phishingAlerts

    ScreenColumn(title = "GabShield") {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            color = if (fullProtection) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        ) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = GabIcons.Shield,
                    contentDescription = null,
                    tint = if (fullProtection) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(44.dp),
                )
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(
                        text = if (fullProtection) "Proteção ativa" else "Proteção parcial",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = "Nível ${settings.level.label.lowercase()}" +
                            if (fullProtection) "" else " · algumas proteções estão desligadas",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        GroupTitle("Desde a instalação")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("Rastreadores bloqueados", format(stats.trackers), Modifier.weight(1f))
            StatTile("Anúncios bloqueados", format(stats.ads + stats.extended), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("Tentativas suspeitas", format(settings.suspiciousAttempts), Modifier.weight(1f))
            StatTile("Sites protegidos", format(sites.toLong()), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("Anúncios do YouTube", format(stats.youtube), Modifier.weight(1f))
            StatTile("Dados economizados*", saved, Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Note(
            "* Estimativa: ${format(stats.requests)} requisições bloqueadas × 20 KB, um tamanho médio de " +
                "scripts e imagens de anúncio. O valor real varia. Os outros números são contagens exatas, feitas no aparelho.",
        )

        GroupTitle("Últimos 7 dias")
        WeekChart(daily)

        GroupTitle("Nível de proteção")
        LevelOption(
            level = ShieldLevel.STANDARD,
            selected = settings.level == ShieldLevel.STANDARD,
            description = "Bloqueia anúncios e rastreadores conhecidos e avisa sobre golpes. Quase nunca atrapalha sites.",
        ) { scope.launch { shield.setLevel(ShieldLevel.STANDARD) } }
        LevelOption(
            level = ShieldLevel.ADVANCED,
            selected = settings.level == ShieldLevel.ADVANCED,
            description = "Filtros mais rígidos: também bloqueia gerenciadores de rastreamento, scripts de " +
                "fingerprinting conhecidos e o SDK do Facebook. Pode atrapalhar login social.",
        ) { scope.launch { shield.setLevel(ShieldLevel.ADVANCED) } }
        LevelOption(
            level = ShieldLevel.CUSTOM,
            selected = settings.level == ShieldLevel.CUSTOM,
            description = "Você escolhe cada proteção abaixo e no GabClean.",
        ) { scope.launch { shield.setLevel(ShieldLevel.CUSTOM) } }

        GroupTitle("Proteções")
        ToggleRow(
            title = "Alerta de golpes",
            subtitle = "Segura sites que imitam bancos, lojas e serviços antes de abrir.",
            checked = settings.phishingAlerts,
        ) { scope.launch { shield.setPhishingAlerts(it) } }
        ToggleRow(
            title = "Bloqueio de anúncios e rastreadores",
            subtitle = "GabClean. Toque em \"Ajustar\" para níveis, YouTube e listas.",
            checked = clean.enabled,
        ) { scope.launch { gabClean.setEnabled(it) } }
        TextButton(onClick = { onNavigate(Screen.GABCLEAN) }) { Text("Ajustar GabClean") }
        FixedProtection("Navegação Segura do Google: aviso em sites de malware e phishing já denunciados.")
        FixedProtection("Só HTTPS: endereços http são trocados por https automaticamente.")
        FixedProtection("Certificado inválido é sempre bloqueado, sem opção de continuar.")
        FixedProtection("Cookies de terceiros bloqueados (rastreamento entre sites).")
        FixedProtection("Páginas não acessam arquivos do celular nem abrem outros apps sozinhas.")

        GroupTitle("Permissões de sites")
        if (settings.permissions.isEmpty()) {
            Note("Nenhum site tem permissão gravada. Quando um site pedir câmera, microfone ou localização, o GabBrowser pergunta.")
        }
        settings.permissions.groupBy { it.origin }.forEach { (origin, decisions) ->
            RemovableRow(
                title = displayHost(origin),
                subtitle = decisions.joinToString(" · ") {
                    "${it.permission.label}: ${if (it.allowed) "permitida" else "bloqueada"}"
                },
                action = "Remover",
            ) { scope.launch { shield.forgetPermissions(origin) } }
        }

        GroupTitle("Sites abertos sem HTTPS")
        if (settings.httpHosts.isEmpty()) Note("Nenhum.")
        settings.httpHosts.sorted().forEach { host ->
            RemovableRow(host, "Você aceitou abrir sem criptografia.", "Remover") {
                scope.launch { shield.disallowHttp(host) }
            }
        }

        GroupTitle("Avisos de golpe ignorados")
        if (settings.trustedHosts.isEmpty()) Note("Nenhum.")
        settings.trustedHosts.sorted().forEach { host ->
            RemovableRow(host, "Você escolheu abrir mesmo com o aviso.", "Avisar de novo") {
                scope.launch { shield.untrust(host) }
            }
        }

        Spacer(Modifier.height(16.dp))
        OutlinedButton(
            onClick = {
                val report = buildReport(settings, clean, stats, sites, saved)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Relatório de proteção do GabBrowser")
                    putExtra(Intent.EXTRA_TEXT, report)
                }
                context.startActivity(Intent.createChooser(send, "Compartilhar relatório"))
            },
        ) {
            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Compartilhar relatório de proteção")
        }

        GroupTitle("Limites")
        Note(
            "Nenhuma proteção é absoluta. O alerta de golpes analisa o endereço no próprio aparelho e pode errar " +
                "para os dois lados; a Navegação Segura só conhece sites já denunciados. Desconfie de links recebidos " +
                "por mensagem, mesmo sem aviso.",
        )
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun WeekChart(days: List<Pair<LocalDate, Long>>) {
    val barColor = MaterialTheme.colorScheme.primary
    val emptyColor = MaterialTheme.colorScheme.surfaceVariant
    val max = days.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
    ) {
        Column(Modifier.padding(14.dp)) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp),
            ) {
                if (days.isEmpty()) return@Canvas
                val slot = size.width / days.size
                val barWidth = slot * 0.55f
                days.forEachIndexed { index, (_, count) ->
                    val fraction = count.toFloat() / max
                    val barHeight = (size.height * fraction).coerceAtLeast(4f)
                    drawRoundRect(
                        color = if (count > 0) barColor else emptyColor,
                        topLeft = Offset(slot * index + (slot - barWidth) / 2, size.height - barHeight),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(8f, 8f),
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                days.forEach { (day, count) ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = format(count),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                        )
                        Text(
                            text = day.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("pt", "BR"))
                                .take(3).replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelOption(level: ShieldLevel, selected: Boolean, description: String, onSelect: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onSelect),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                text = level.label,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onBackground)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun FixedProtection(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Icon(
            imageVector = Icons.Filled.Check,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground)
    }
}

@Composable
private fun RemovableRow(title: String, subtitle: String, action: String, onAction: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        TextButton(onClick = onAction) { Text(action) }
    }
}

private fun format(value: Long): String = NumberFormat.getIntegerInstance().format(value)

private fun buildReport(
    settings: GabShieldSettings,
    clean: GabCleanSettings,
    stats: GabCleanStats,
    sites: Int,
    saved: String,
): String = buildString {
    appendLine("Relatório de proteção do GabBrowser")
    appendLine()
    appendLine("Nível: ${settings.level.label}")
    appendLine("Bloqueio de anúncios e rastreadores: ${if (clean.enabled) "ligado" else "desligado"}")
    appendLine("Alerta de golpes: ${if (settings.phishingAlerts) "ligado" else "desligado"}")
    appendLine()
    appendLine("Rastreadores bloqueados: ${format(stats.trackers)}")
    appendLine("Anúncios bloqueados: ${format(stats.ads + stats.extended)}")
    appendLine("Anúncios do YouTube removidos ou pulados: ${format(stats.youtube)}")
    appendLine("Tentativas suspeitas identificadas: ${format(settings.suspiciousAttempts)}")
    appendLine("  - avisos de golpe do GabShield: ${format(settings.warningsShown)}")
    appendLine("  - alertas da Navegação Segura: ${format(settings.safeBrowsingHits)}")
    appendLine("Sites protegidos: ${format(sites.toLong())}")
    appendLine("Dados economizados (estimativa, 20 KB por bloqueio): $saved")
    appendLine()
    appendLine("Contagens feitas no aparelho. Nenhuma proteção é absoluta.")
}
