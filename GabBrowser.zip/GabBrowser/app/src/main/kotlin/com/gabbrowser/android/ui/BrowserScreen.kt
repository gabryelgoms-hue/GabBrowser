package com.gabbrowser.android.ui

import android.content.Intent
import androidx.activity.compose.BackHandler
import android.view.ViewGroup
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.data.SiteRepository
import com.gabbrowser.core.data.ai.GabAiRepository
import com.gabbrowser.core.data.passwords.CredentialInfo
import com.gabbrowser.core.data.passwords.PasswordVault
import com.gabbrowser.core.data.reader.ReaderArticle
import com.gabbrowser.core.data.reader.ReaderStore
import com.gabbrowser.core.common.reader.ReaderScript
import androidx.fragment.app.FragmentActivity
import com.gabbrowser.core.data.gabclean.GabCleanRepository
import com.gabbrowser.core.data.gabclean.GabCleanSettings
import com.gabbrowser.core.data.gabshield.GabShieldRepository
import com.gabbrowser.core.data.gabshield.GabShieldSettings
import com.gabbrowser.core.data.gabshield.PermissionDecision
import com.gabbrowser.core.designsystem.GabIcons
import com.gabbrowser.core.engine.ConnectionSecurity
import com.gabbrowser.core.engine.EngineSession
import com.gabbrowser.core.engine.PageError
import com.gabbrowser.core.engine.PageState
import kotlinx.coroutines.launch

@Composable
fun BrowserScreen(
    session: EngineSession,
    page: PageState,
    sites: SiteRepository,
    gabClean: GabCleanRepository,
    shield: GabShieldRepository,
    focusRequested: Boolean,
    onFocusConsumed: () -> Unit,
    onSubmit: (String) -> Unit,
    onNewTab: (Boolean) -> Unit,
    onNavigate: (Screen) -> Unit,
    onHome: () -> Unit,
    onRecover: () -> Unit,
    ai: GabAiRepository,
    aiConversation: AiConversation,
    vault: PasswordVault,
    reader: ReaderStore,
    onReader: (ReaderArticle) -> Unit,
    notify: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var aiOpen by remember { mutableStateOf(false) }
    val activity = context as? FragmentActivity

    // Senhas salvas para o site atual (só usuário; a senha só sai do cofre depois da autenticação).
    val origin = remember(page.url) { if (page.url.startsWith("https://")) PasswordVault.normalizeOrigin(page.url) else null }
    var savedLogins by remember(origin) { mutableStateOf<List<CredentialInfo>>(emptyList()) }
    LaunchedEffect(origin, page.hasPasswordField) {
        savedLogins = if (origin != null && page.hasPasswordField) vault.forOrigin(origin) else emptyList()
    }
    var fillDismissed by remember(origin) { mutableStateOf(false) }

    fun fill(login: CredentialInfo) {
        val target = origin ?: return
        if (activity == null || !BiometricGate.isAvailable(context)) {
            notify(BiometricGate.NO_LOCK_MESSAGE)
            return
        }
        BiometricGate.authenticate(
            activity = activity,
            title = "Preencher senha",
            subtitle = "${displayHost(target)} · ${login.username.ifEmpty { "sem usuário" }}",
            onSuccess = {
                scope.launch {
                    val password = revealAfterAuth(vault, login.id)
                    when {
                        password == null -> notify("Não foi possível abrir esta senha.")
                        !session.fillCredentials(target, login.username, password) ->
                            notify("A página mudou de site; nada foi preenchido.")
                        else -> fillDismissed = true
                    }
                }
            },
            onFailure = notify,
        )
    }

    fun openReader() {
        session.evaluateAppScript(ReaderScript.EXTRACT) { raw ->
            val article = reader.parse(raw, page.url)
            if (article == null) notify("Esta página não parece um artigo para o modo leitura.") else onReader(article)
        }
    }
    BackHandler(enabled = aiOpen) { aiOpen = false }
    val bookmarked by remember(page.url) { sites.isBookmarked(page.url) }
        .collectAsStateWithLifecycle(initialValue = false)
    val cleanSettings by gabClean.settings.collectAsStateWithLifecycle(initialValue = GabCleanSettings())
    val shieldSettings by shield.settings.collectAsStateWithLifecycle(initialValue = GabShieldSettings())
    var cleanDialogOpen by remember { mutableStateOf(false) }
    val siteHost = displayHost(page.url)
    val protectedHere = cleanSettings.enabled && !cleanSettings.isException(siteHost)

    if (cleanDialogOpen) {
        SiteProtectionDialog(
            host = siteHost,
            page = page,
            cleanEnabled = cleanSettings.enabled,
            protectedHere = protectedHere,
            isPrivate = session.isPrivate,
            permissions = shieldSettings.permissions.filter { displayHost(it.origin) == siteHost },
            onToggle = { block ->
                scope.launch {
                    gabClean.setBlockingOnSite(siteHost, block)
                    session.reload()
                }
            },
            onResetPermissions = {
                val origins = shieldSettings.permissions.filter { displayHost(it.origin) == siteHost }.map { it.origin }
                scope.launch { origins.distinct().forEach { shield.forgetPermissions(it) } }
            },
            onOpenShield = {
                cleanDialogOpen = false
                onNavigate(Screen.GABSHIELD)
            },
            onDismiss = { cleanDialogOpen = false },
        )
    }

    Column(Modifier.fillMaxSize()) {
        BrowserTopBar(
            page = page,
            isPrivate = session.isPrivate,
            bookmarked = bookmarked,
            onNewTab = onNewTab,
            onNavigate = onNavigate,
            onOpenAi = { aiOpen = true },
            onReader = { openReader() },
            protectedHere = protectedHere,
            onShieldClick = { cleanDialogOpen = true },
            focusRequested = focusRequested,
            onFocusConsumed = onFocusConsumed,
            onSubmit = onSubmit,
            onBack = { session.goBack() },
            onForward = { session.goForward() },
            onReload = { session.reload() },
            onStop = { session.stop() },
            onHome = onHome,
            onShare = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, page.title)
                    putExtra(Intent.EXTRA_TEXT, page.url)
                }
                context.startActivity(Intent.createChooser(send, "Compartilhar página"))
            },
            onToggleBookmark = {
                val url = page.url
                val title = page.title
                scope.launch {
                    if (bookmarked) sites.removeBookmark(url) else sites.addBookmark(url, title)
                }
            },
        )

        if (page.isLoading) {
            LinearProgressIndicator(
                progress = { page.progress / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
            )
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            key(session) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = {
                        session.view.also { view ->
                            (view.parent as? ViewGroup)?.removeView(view)
                        }
                    },
                )
            }

            if (savedLogins.isNotEmpty() && !fillDismissed && page.error == null) {
                FillBanner(
                    logins = savedLogins,
                    onFill = { fill(it) },
                    onDismiss = { fillDismissed = true },
                    modifier = Modifier.align(Alignment.TopCenter),
                )
            }

            if (aiOpen) {
                GabAiPanel(
                    session = session,
                    page = page,
                    ai = ai,
                    conversation = aiConversation,
                    onClose = { aiOpen = false },
                    onOpenSettings = {
                        aiOpen = false
                        onNavigate(Screen.GABAI)
                    },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .fillMaxHeight(0.62f),
                )
            }

            val error = page.error
            if (error != null) {
                ErrorPanel(
                    error = error,
                    onRetry = { if (error is PageError.RendererCrashed) onRecover() else session.reload() },
                    onHome = onHome,
                    onContinue = {
                        when (error) {
                            is PageError.Suspicious -> scope.launch {
                                shield.trust(error.host, private = session.isPrivate)
                                session.loadUrl(error.url)
                            }

                            is PageError.InsecureOnly -> scope.launch {
                                shield.allowHttp(error.host, private = session.isPrivate)
                                session.loadUrl(error.httpUrl)
                            }

                            else -> Unit
                        }
                    },
                )
            }
        }
    }
}

@Composable
private fun BrowserTopBar(
    page: PageState,
    isPrivate: Boolean,
    bookmarked: Boolean,
    onNewTab: (Boolean) -> Unit,
    onNavigate: (Screen) -> Unit,
    onOpenAi: () -> Unit,
    onReader: () -> Unit,
    protectedHere: Boolean,
    onShieldClick: () -> Unit,
    focusRequested: Boolean,
    onFocusConsumed: () -> Unit,
    onSubmit: (String) -> Unit,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReload: () -> Unit,
    onStop: () -> Unit,
    onHome: () -> Unit,
    onShare: () -> Unit,
    onToggleBookmark: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }

    Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack, enabled = page.canGoBack, modifier = Modifier.size(40.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
            }
            IconButton(onClick = onForward, enabled = page.canGoForward, modifier = Modifier.size(40.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Avançar")
            }

            AddressPill(
                page = page,
                isPrivate = isPrivate,
                focusRequested = focusRequested,
                onFocusConsumed = onFocusConsumed,
                onSubmit = onSubmit,
                onReload = onReload,
                onStop = onStop,
                modifier = Modifier.weight(1f),
            )

            ShieldButton(
                count = page.blockedCount,
                active = protectedHere,
                onClick = onShieldClick,
            )

            Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Menu de ferramentas")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Nova aba") },
                        leadingIcon = { Icon(Icons.Filled.Add, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onNewTab(false)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Nova aba anônima") },
                        leadingIcon = { Icon(GabIcons.Mask, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onNewTab(true)
                        },
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text("GabAI: resumir, explicar, traduzir") },
                        leadingIcon = { Icon(GabIcons.Spark, contentDescription = null) },
                        enabled = page.url.isNotEmpty(),
                        onClick = {
                            menuOpen = false
                            onOpenAi()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Modo leitura (GabReader)") },
                        leadingIcon = { Icon(GabIcons.Book, contentDescription = null) },
                        enabled = page.url.startsWith("https://") && page.error == null,
                        onClick = {
                            menuOpen = false
                            onReader()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("GabOne: limpar dados") },
                        leadingIcon = { Icon(GabIcons.Sweep, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onNavigate(Screen.GABONE)
                        },
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text(if (bookmarked) "Remover dos favoritos" else "Adicionar aos favoritos") },
                        leadingIcon = { Icon(Icons.Filled.Star, contentDescription = null) },
                        enabled = page.url.startsWith("https://"),
                        onClick = {
                            menuOpen = false
                            onToggleBookmark()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Compartilhar página") },
                        leadingIcon = { Icon(Icons.Filled.Share, contentDescription = null) },
                        enabled = page.url.isNotEmpty(),
                        onClick = {
                            menuOpen = false
                            onShare()
                        },
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text("Favoritos") },
                        leadingIcon = { Icon(Icons.Filled.Star, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onNavigate(Screen.BOOKMARKS)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Histórico") },
                        leadingIcon = { Icon(Icons.Filled.DateRange, contentDescription = null) },
                        enabled = !isPrivate,
                        onClick = {
                            menuOpen = false
                            onNavigate(Screen.HISTORY)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Downloads") },
                        leadingIcon = { Icon(GabIcons.Download, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onNavigate(Screen.DOWNLOADS)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Página inicial") },
                        leadingIcon = { Icon(Icons.Filled.Home, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onHome()
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun AddressPill(
    page: PageState,
    isPrivate: Boolean,
    focusRequested: Boolean,
    onFocusConsumed: () -> Unit,
    onSubmit: (String) -> Unit,
    onReload: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf(TextFieldValue("")) }

    LaunchedEffect(focusRequested) {
        if (focusRequested) {
            focusRequester.requestFocus()
            onFocusConsumed()
        }
    }

    // Fora de edição, mostra só o host: é a parte do endereço que identifica o site.
    val shown = if (focused) draft else TextFieldValue(displayHost(page.url))

    Surface(
        modifier = modifier.height(44.dp),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (isPrivate) {
                Icon(
                    imageVector = GabIcons.Mask,
                    contentDescription = "Aba anônima",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(6.dp))
            }
            SecurityIcon(page.security)
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = shown,
                onValueChange = { if (focused) draft = it },
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focusRequester)
                    .onFocusChanged { state ->
                        if (state.isFocused && !focused) {
                            draft = TextFieldValue(page.url, TextRange(0, page.url.length))
                        }
                        focused = state.isFocused
                    },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    color = MaterialTheme.colorScheme.onSurface,
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.None,
                    imeAction = ImeAction.Go,
                ),
                keyboardActions = KeyboardActions(
                    onGo = {
                        val text = draft.text
                        focusManager.clearFocus()
                        if (text.isNotBlank()) onSubmit(text)
                    },
                ),
            )
            if (page.isLoading) {
                IconButton(onClick = onStop, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = "Cancelar carregamento")
                }
            } else {
                IconButton(onClick = onReload, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Atualizar")
                }
            }
        }
    }
}

/** Escudo do GabClean na barra: azul quando protegendo, cinza quando desligado neste site. */
@Composable
private fun ShieldButton(count: Int, active: Boolean, onClick: () -> Unit) {
    val description = if (active) {
        "GabClean: $count bloqueios nesta página"
    } else {
        "GabClean desligado neste site"
    }
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = GabIcons.Shield,
            contentDescription = null,
            tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(22.dp),
        )
        if (active && count > 0) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 3.dp, end = 1.dp),
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primary,
            ) {
                Text(
                    text = if (count > 99) "99+" else count.toString(),
                    modifier = Modifier.padding(horizontal = 4.dp),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary,
                )
            }
        }
    }
}

@Composable
private fun SiteProtectionDialog(
    host: String,
    page: PageState,
    cleanEnabled: Boolean,
    protectedHere: Boolean,
    isPrivate: Boolean,
    permissions: List<PermissionDecision>,
    onToggle: (Boolean) -> Unit,
    onResetPermissions: () -> Unit,
    onOpenShield: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(GabIcons.Shield, contentDescription = null) },
        title = { Text(host.ifEmpty { "Proteção" }) },
        text = {
            Column {
                val connection = when (page.security) {
                    ConnectionSecurity.SECURE -> "Conexão segura (HTTPS)."
                    ConnectionSecurity.INSECURE -> "Conexão sem HTTPS: quem estiver na mesma rede pode ver e alterar a página."
                    ConnectionSecurity.CERTIFICATE_ERROR -> "Certificado inválido: a página foi bloqueada."
                    ConnectionSecurity.NONE -> "Conexão ainda não verificada."
                }
                Text(connection, style = MaterialTheme.typography.bodyMedium)
                if (page.suspicion.reasons.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Pontos de atenção neste endereço:",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.error,
                    )
                    page.suspicion.reasons.forEach { reason ->
                        Text("• $reason", style = MaterialTheme.typography.bodySmall)
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text("GabClean", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text(
                    text = when {
                        !cleanEnabled -> "Bloqueio de anúncios desligado."
                        !protectedHere -> "Bloqueio desligado neste site."
                        page.blockedCount == 1 -> "1 anúncio ou rastreador bloqueado nesta página."
                        else -> "${page.blockedCount} anúncios e rastreadores bloqueados nesta página."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                )
                if (isPrivate) {
                    Text(
                        text = "Em aba anônima, exceções não podem ser criadas: elas guardariam o nome do site.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else if (cleanEnabled && host.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Bloquear neste site",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyLarge,
                        )
                        Switch(checked = protectedHere, onCheckedChange = onToggle)
                    }
                }

                if (permissions.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("Permissões", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    permissions.forEach { decision ->
                        Text(
                            text = "${decision.permission.label.replaceFirstChar { it.uppercase() }}: " +
                                if (decision.allowed) "permitida" else "bloqueada",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    TextButton(onClick = onResetPermissions) { Text("Redefinir permissões") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Fechar") }
        },
        dismissButton = {
            TextButton(onClick = onOpenShield) { Text("GabShield") }
        },
    )
}

/** Faixa discreta no topo da página quando há login salvo para o site. */
@Composable
private fun FillBanner(
    logins: List<CredentialInfo>,
    onFill: (CredentialInfo) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        shadowElevation = 4.dp,
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
            logins.take(3).forEach { login ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = login.username.ifEmpty { "Login salvo" },
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        maxLines = 1,
                    )
                    TextButton(onClick = { onFill(login) }) { Text("Preencher") }
                }
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Agora não") }
        }
    }
}

@Composable
private fun SecurityIcon(security: ConnectionSecurity) {
    when (security) {
        ConnectionSecurity.SECURE -> Icon(
            imageVector = Icons.Filled.Lock,
            contentDescription = "Conexão segura (HTTPS)",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp),
        )

        ConnectionSecurity.CERTIFICATE_ERROR -> Icon(
            imageVector = Icons.Filled.Warning,
            contentDescription = "Certificado inválido",
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(18.dp),
        )

        ConnectionSecurity.INSECURE -> Icon(
            imageVector = Icons.Filled.Warning,
            contentDescription = "Conexão sem HTTPS, não segura",
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(18.dp),
        )

        ConnectionSecurity.NONE -> Icon(
            imageVector = Icons.Filled.Info,
            contentDescription = "Conexão ainda não verificada",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
    }
}

@Composable
private fun ErrorPanel(
    error: PageError,
    onRetry: () -> Unit,
    onHome: () -> Unit,
    onContinue: () -> Unit,
) {
    val title: String
    val body: String
    val canRetry: Boolean
    var continueLabel: String? = null
    var reasons: List<String> = emptyList()
    when (error) {
        is PageError.Suspicious -> {
            title = "Este site pode ser um golpe"
            body = "O GabShield segurou ${error.host} antes de abrir. Sites assim imitam bancos, lojas e " +
                "serviços para roubar senhas e dados de pagamento. Se chegou aqui por mensagem ou anúncio, volte."
            canRetry = false
            reasons = error.reasons
            continueLabel = "Entendo o risco, abrir mesmo assim"
        }

        is PageError.Certificate -> {
            title = "Conexão não segura"
            body = "O GabBrowser bloqueou ${error.host} porque ${error.reason}. " +
                "Alguém pode estar tentando se passar por este site, então não há opção de continuar."
            canRetry = false
        }

        is PageError.InsecureOnly -> {
            title = "Site sem HTTPS"
            body = "${error.host} só funciona sem HTTPS. Sem essa proteção, quem estiver na mesma rede " +
                "(um Wi-Fi público, por exemplo) pode ver o que você faz e alterar a página. " +
                "Não digite senhas nem dados de cartão nele."
            canRetry = false
            continueLabel = "Abrir sem HTTPS"
        }

        is PageError.Network -> {
            title = "Não foi possível abrir a página"
            body = error.description.ifBlank { "Verifique sua conexão e tente de novo." }
            canRetry = true
        }

        is PageError.RendererCrashed -> {
            title = "A página parou de responder"
            body = "O processo que exibia esta página foi encerrado. Recarregue para continuar."
            canRetry = true
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(48.dp))
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(52.dp),
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = body,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            if (reasons.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            text = "Por que o aviso:",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        reasons.forEach { reason ->
                            Text(
                                text = "• $reason",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            if (canRetry) {
                Button(onClick = onRetry) { Text("Tentar novamente") }
                Spacer(Modifier.height(8.dp))
            }
            val label = continueLabel
            if (label != null) {
                Button(onClick = onHome) { Text("Voltar para um lugar seguro") }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onContinue) {
                    Text(label, color = MaterialTheme.colorScheme.error)
                }
            } else {
                OutlinedButton(onClick = onHome) { Text("Voltar") }
            }
        }
    }
}
