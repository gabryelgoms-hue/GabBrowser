package com.gabbrowser.android.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.data.ai.AiAction
import com.gabbrowser.core.data.ai.AiResult
import com.gabbrowser.core.data.ai.AiSettings
import com.gabbrowser.core.data.ai.ChatMessage
import com.gabbrowser.core.data.ai.GabAiRepository
import com.gabbrowser.core.data.ai.PageContext
import com.gabbrowser.core.designsystem.GabIcons
import com.gabbrowser.core.engine.EngineSession
import com.gabbrowser.core.engine.PageState
import kotlinx.coroutines.launch

/** Conversa do GabAI de uma aba. Fica viva enquanto a aba existir, para o painel abrir de onde parou. */
class AiConversation {
    val messages = mutableStateListOf<ChatMessage>()
    var context by mutableStateOf<PageContext?>(null)
    var contextUrl by mutableStateOf("")
    var loading by mutableStateOf(false)
}

/** Pedido aguardando o consentimento do usuário para enviar o texto da página. */
private data class PendingSend(
    val userText: String,
    val text: String,
    val isSelection: Boolean,
    val url: String,
    val title: String,
)

/** Painel na parte de baixo da tela: a página continua visível e navegável acima dele. */
@Composable
fun GabAiPanel(
    session: EngineSession,
    page: PageState,
    ai: GabAiRepository,
    conversation: AiConversation,
    onClose: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val settings by ai.settings.collectAsStateWithLifecycle(initialValue = AiSettings())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var useSelection by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<PendingSend?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }

    // A página mudou: o texto autorizado era de outra página e deixa de valer.
    if (conversation.contextUrl.isNotEmpty() && conversation.contextUrl != page.url) {
        conversation.context = null
        conversation.contextUrl = ""
    }

    LaunchedEffect(conversation.messages.size) {
        if (conversation.messages.isNotEmpty()) listState.animateScrollToItem(conversation.messages.size - 1)
    }

    fun deliver(userText: String, pageContext: PageContext?) {
        conversation.messages += ChatMessage(fromUser = true, text = userText)
        conversation.loading = true
        scope.launch {
            val result = ai.send(conversation.messages.toList(), pageContext)
            conversation.loading = false
            when (result) {
                is AiResult.Success -> conversation.messages += ChatMessage(fromUser = false, text = result.text)
                is AiResult.Failure -> {
                    // A pergunta que falhou sai da conversa, para não confundir os próximos pedidos.
                    conversation.messages.removeAt(conversation.messages.lastIndex)
                    notice = result.message
                }
            }
        }
    }

    /** Primeira mensagem da conversa: busca o texto e pede autorização antes de enviar. */
    fun ask(userText: String, needsPage: Boolean) {
        notice = null
        if (!settings.hasKey) {
            notice = GabAiRepository.NOT_CONFIGURED
            return
        }
        if (conversation.messages.isNotEmpty() || !needsPage) {
            deliver(userText, if (conversation.messages.isEmpty()) null else conversation.context)
            return
        }
        session.extractText(useSelection, GabAiRepository.MAX_PAGE_CHARS) { text ->
            if (text.isBlank()) {
                notice = if (useSelection) {
                    "Nenhum texto selecionado. Toque e segure na página para selecionar um trecho."
                } else {
                    "Esta página não tem texto para enviar."
                }
            } else {
                pending = PendingSend(userText, text, useSelection, page.url, page.title)
            }
        }
    }

    pending?.let { request ->
        ConsentDialog(
            host = displayHost(request.url),
            service = displayHost(settings.baseUrl),
            request = request,
            isPrivate = session.isPrivate,
            onConfirm = {
                pending = null
                if (page.url != request.url) {
                    notice = "A página mudou antes do envio. Nada foi enviado; peça de novo."
                } else {
                    val pageContext = PageContext(request.title, request.url, request.text, request.isSelection)
                    conversation.context = pageContext
                    conversation.contextUrl = request.url
                    deliver(request.userText, pageContext)
                }
            },
            onDismiss = { pending = null },
        )
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 12.dp,
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(GabIcons.Spark, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "GabAI",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                TextButton(onClick = onOpenSettings) { Text("Ajustes") }
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Fechar GabAI") }
            }

            if (!settings.hasKey) {
                Text(GabAiRepository.NOT_CONFIGURED, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                Button(onClick = onOpenSettings) { Text("Configurar GabAI") }
                Spacer(Modifier.height(8.dp))
            } else {
                ChatBody(
                    conversation = conversation,
                    listState = listState,
                    useSelection = useSelection,
                    onToggleSelection = { useSelection = it },
                    input = input,
                    onInput = { input = it },
                    notice = notice,
                    settings = settings,
                    onAsk = { text -> ask(text, needsPage = true) },
                    onShare = { text ->
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        context.startActivity(Intent.createChooser(send, "Compartilhar resposta"))
                    },
                )
            }
        }
    }
}

@Composable
private fun ColumnScope.ChatBody(
    conversation: AiConversation,
    listState: LazyListState,
    useSelection: Boolean,
    onToggleSelection: (Boolean) -> Unit,
    input: String,
    onInput: (String) -> Unit,
    notice: String?,
    settings: AiSettings,
    onAsk: (String) -> Unit,
    onShare: (String) -> Unit,
) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(AiAction.entries) { action ->
            ActionChip(action.label, enabled = !conversation.loading) { onAsk(action.prompt) }
        }
    }
    if (conversation.messages.isEmpty()) {
        Row(
            modifier = Modifier.clickable { onToggleSelection(!useSelection) },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Checkbox(checked = useSelection, onCheckedChange = onToggleSelection)
            Text("Usar só o trecho selecionado na página", style = MaterialTheme.typography.bodySmall)
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier
            .weight(1f, fill = false)
            .fillMaxWidth(),
        contentPadding = PaddingValues(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(conversation.messages) { message ->
            Bubble(message = message, onShare = { onShare(message.text) })
        }
        if (conversation.loading) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Pensando…", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    notice?.let {
        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(4.dp))
    }

    val submit = {
        if (input.isNotBlank() && !conversation.loading) {
            onAsk(input.trim())
            onInput("")
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = input,
            onValueChange = onInput,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Pergunte sobre esta página") },
            maxLines = 3,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { submit() }),
        )
        IconButton(onClick = submit) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar", tint = MaterialTheme.colorScheme.primary)
        }
    }
    Text(
        text = "Hoje: ${settings.usedToday} de ${settings.dailyTokenLimit} tokens. Respostas de IA podem conter erros.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun ActionChip(label: String, enabled: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
        )
    }
}

@Composable
private fun Bubble(message: ChatMessage, onShare: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    if (message.fromUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                )
                .padding(12.dp),
        ) {
            // Pedidos das ações rápidas aparecem pelo nome ("Resumir"), não pelo texto completo do pedido.
            val shown = AiAction.entries.firstOrNull { it.prompt == message.text }?.label ?: message.text
            SelectionContainer {
                Text(
                    text = shown,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (message.fromUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                )
            }
            if (!message.fromUser) {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                    IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Share, contentDescription = "Compartilhar resposta", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ConsentDialog(
    host: String,
    service: String,
    request: PendingSend,
    isPrivate: Boolean,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(GabIcons.Spark, contentDescription = null) },
        title = { Text("Enviar para a IA?") },
        text = {
            Column {
                Text(
                    text = "O GabAI vai enviar ${if (request.isSelection) "o trecho selecionado" else "o texto desta página"} " +
                        "de $host (${request.text.length} caracteres), com o título e o endereço da página, para " +
                        "$service, que processa o pedido. Seu histórico e outras abas não são enviados.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                if (isPrivate) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Você está em uma aba anônima: o texto sai do aparelho mesmo assim.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Não envie páginas com dados pessoais, bancários ou senhas.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Enviar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
