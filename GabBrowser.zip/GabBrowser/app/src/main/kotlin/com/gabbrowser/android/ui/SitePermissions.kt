package com.gabbrowser.android.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.gabbrowser.core.common.security.SitePermission
import com.gabbrowser.core.designsystem.GabIcons
import com.gabbrowser.core.engine.EngineEvent
import kotlinx.coroutines.delay

/** Permissões do Android necessárias para cada recurso pedido por um site. */
internal fun androidPermissionsFor(permission: SitePermission): List<String> = when (permission) {
    SitePermission.CAMERA -> listOf(Manifest.permission.CAMERA)
    SitePermission.MICROPHONE -> listOf(Manifest.permission.RECORD_AUDIO)
    SitePermission.LOCATION -> listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
}

/** Localização aproximada já basta; câmera e microfone precisam da própria permissão. */
internal fun hasAndroidPermission(context: Context, permission: SitePermission): Boolean =
    androidPermissionsFor(permission).any {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

/** "a câmera e o microfone" */
internal fun describePermissions(permissions: Set<SitePermission>): String {
    val parts = permissions.sortedBy { it.ordinal }.map { permission ->
        val article = if (permission == SitePermission.MICROPHONE) "o" else "a"
        "$article ${permission.label}"
    }
    return when (parts.size) {
        0 -> ""
        1 -> parts[0]
        else -> parts.dropLast(1).joinToString(", ") + " e " + parts.last()
    }
}

@Composable
internal fun SitePermissionDialog(
    request: EngineEvent.PermissionRequested,
    canRemember: Boolean,
    onDecision: (allow: Boolean, remember: Boolean) -> Unit,
) {
    // Desmarcado: permitir uma vez não vira permissão permanente sem o usuário escolher.
    var rememberChoice by remember { mutableStateOf(false) }
    // Botões ativos só depois de um instante: um pedido no meio de toques rápidos não vira "Permitir" sem querer.
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(700)
        armed = true
    }
    val site = displayHost(request.origin)
    AlertDialog(
        onDismissRequest = { onDecision(false, false) },
        icon = { Icon(GabIcons.Shield, contentDescription = null) },
        title = { Text("Permitir acesso?") },
        text = {
            Column {
                Text(
                    text = "$site quer usar ${describePermissions(request.permissions)} do celular.",
                    style = MaterialTheme.typography.bodyLarge,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Só permita se você está usando o site para isso (uma chamada de vídeo, um mapa). " +
                        "Você pode mudar depois no GabShield.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (canRemember) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.clickable { rememberChoice = !rememberChoice },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = rememberChoice, onCheckedChange = { rememberChoice = it })
                        Spacer(Modifier.width(4.dp))
                        Text("Lembrar para este site", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = armed, onClick = { onDecision(true, rememberChoice) }) { Text("Permitir") } },
        dismissButton = { TextButton(enabled = armed, onClick = { onDecision(false, rememberChoice) }) { Text("Bloquear") } },
    )
}
