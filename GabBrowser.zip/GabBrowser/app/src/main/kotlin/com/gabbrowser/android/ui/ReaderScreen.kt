package com.gabbrowser.android.ui

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.data.reader.BlockType
import com.gabbrowser.core.data.reader.ReaderArticle
import com.gabbrowser.core.data.reader.ReaderStore
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

private val NightBackground = Color(0xFF101827)
private val NightText = Color(0xFFE3E7EE)
private val DayBackground = Color(0xFFFFFDF8)
private val DayText = Color(0xFF1C2230)

/** GabReader: artigo aberto ou, sem artigo, a lista de artigos salvos para ler offline. */
@Composable
fun ReaderScreen(
    article: ReaderArticle?,
    store: ReaderStore,
    /** Falso para artigos vindos de aba anônima: salvar deixaria rastro no aparelho. */
    canSave: Boolean,
    onOpenSaved: (ReaderArticle) -> Unit,
    onOpenOriginal: (String) -> Unit,
    notify: (String) -> Unit,
) {
    if (article == null) {
        SavedArticles(store, onOpenSaved)
    } else {
        ArticleView(article, store, canSave, onOpenOriginal, notify)
    }
}

@Composable
private fun SavedArticles(store: ReaderStore, onOpen: (ReaderArticle) -> Unit) {
    val saved by store.saved.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { store.refresh() }

    ScreenColumn(title = "GabReader") {
        Note(
            "Para ler uma página sem anúncios e distrações, abra um artigo e toque em ⋮ > Modo leitura. " +
                "Artigos salvos ficam aqui e podem ser lidos sem internet.",
        )
        GroupTitle("Salvos para ler offline")
        if (saved.isEmpty()) Note("Nenhum artigo salvo.")
        saved.forEach { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { scope.launch { store.load(item.id)?.let(onOpen) } }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = item.title.ifBlank { displayHost(item.url) },
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = "${displayHost(item.url)} · salvo em " +
                            DateFormat.getDateInstance(DateFormat.SHORT).format(Date(item.savedAt)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                TextButton(onClick = { scope.launch { store.delete(item.id) } }) { Text("Apagar") }
            }
        }
    }
}

@Composable
private fun ArticleView(
    article: ReaderArticle,
    store: ReaderStore,
    canSave: Boolean,
    onOpenOriginal: (String) -> Unit,
    notify: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var fontSize by remember { mutableFloatStateOf(18f) }
    var lineSpacing by remember { mutableFloatStateOf(1.5f) }
    var night by remember { mutableStateOf(false) }
    var serif by remember { mutableStateOf(true) }
    var speaking by remember { mutableStateOf(false) }
    var ttsReady by remember { mutableStateOf(false) }

    // Leitura em voz alta com o motor de voz do próprio Android (nada sai do aparelho).
    val tts = remember { TextToSpeech(context) { status -> ttsReady = status == TextToSpeech.SUCCESS } }
    DisposableEffect(tts) {
        onDispose {
            tts.stop()
            tts.shutdown()
        }
    }

    val background = if (night) NightBackground else DayBackground
    val textColor = if (night) NightText else DayText
    val family = if (serif) FontFamily.Serif else FontFamily.SansSerif
    val minutes = (article.wordCount / 200).coerceAtLeast(1)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(background),
    ) {
        Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ReaderButton("A−") { fontSize = (fontSize - 2f).coerceAtLeast(14f) }
                ReaderButton("A+") { fontSize = (fontSize + 2f).coerceAtMost(28f) }
                ReaderButton(if (lineSpacing < 1.7f) "≡ +" else "≡ −") {
                    lineSpacing = if (lineSpacing < 1.7f) 1.9f else 1.5f
                }
                ReaderButton(if (serif) "Aa" else "Aa·") { serif = !serif }
                ReaderButton(if (night) "Dia" else "Noite") { night = !night }
                ReaderButton(if (speaking) "Parar" else "Ouvir") {
                    if (speaking) {
                        tts.stop()
                        speaking = false
                    } else if (ttsReady) {
                        speak(tts, article)
                        speaking = true
                    } else {
                        notify("A voz do Android não está disponível. Instale ou ative um mecanismo de voz nas configurações.")
                    }
                }
                if (canSave) {
                    ReaderButton("Salvar") {
                        scope.launch {
                            store.save(article)
                            notify("Artigo salvo para ler offline.")
                        }
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 20.dp),
        ) {
            Text(
                text = displayHost(article.url) + " · $minutes min de leitura",
                style = MaterialTheme.typography.labelMedium,
                color = textColor.copy(alpha = 0.65f),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = article.title,
                fontSize = (fontSize + 8f).sp,
                lineHeight = ((fontSize + 8f) * 1.25f).sp,
                fontWeight = FontWeight.Bold,
                fontFamily = family,
                color = textColor,
            )
            if (article.byline.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(article.byline, fontSize = (fontSize - 3f).sp, color = textColor.copy(alpha = 0.7f))
            }
            Spacer(Modifier.height(16.dp))
            article.blocks.forEach { block ->
                when (block.type) {
                    BlockType.HEADING -> Text(
                        text = block.text,
                        modifier = Modifier.padding(top = 12.dp, bottom = 6.dp),
                        fontSize = (fontSize + 3f).sp,
                        lineHeight = ((fontSize + 3f) * 1.3f).sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = family,
                        color = textColor,
                    )

                    BlockType.QUOTE -> Text(
                        text = block.text,
                        modifier = Modifier.padding(start = 14.dp, top = 4.dp, bottom = 12.dp),
                        fontSize = fontSize.sp,
                        lineHeight = (fontSize * lineSpacing).sp,
                        fontStyle = FontStyle.Italic,
                        fontFamily = family,
                        color = textColor.copy(alpha = 0.85f),
                    )

                    BlockType.LIST_ITEM -> Text(
                        text = "•  " + block.text,
                        modifier = Modifier.padding(start = 6.dp, bottom = 8.dp),
                        fontSize = fontSize.sp,
                        lineHeight = (fontSize * lineSpacing).sp,
                        fontFamily = family,
                        color = textColor,
                    )

                    BlockType.PARAGRAPH -> Text(
                        text = block.text,
                        modifier = Modifier.padding(bottom = 14.dp),
                        fontSize = fontSize.sp,
                        lineHeight = (fontSize * lineSpacing).sp,
                        fontFamily = family,
                        color = textColor,
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = { onOpenOriginal(article.url) }) { Text("Abrir a página original") }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ReaderButton(label: String, onClick: () -> Unit) {
    Text(
        text = label,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
    )
}

/** O motor de voz aceita textos curtos; o artigo vai em partes, uma fila só. */
private fun speak(tts: TextToSpeech, article: ReaderArticle) {
    val limit = (TextToSpeech.getMaxSpeechInputLength() - 100).coerceAtLeast(500)
    val parts = mutableListOf<String>()
    (listOf(article.title) + article.blocks.map { it.text }).forEach { text ->
        var rest = text
        while (rest.length > limit) {
            val cut = rest.lastIndexOf(' ', limit).takeIf { it > 0 } ?: limit
            parts += rest.substring(0, cut)
            rest = rest.substring(cut)
        }
        if (rest.isNotBlank()) parts += rest
    }
    tts.stop()
    parts.forEachIndexed { index, part ->
        tts.speak(part, if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "gab-$index")
    }
}
