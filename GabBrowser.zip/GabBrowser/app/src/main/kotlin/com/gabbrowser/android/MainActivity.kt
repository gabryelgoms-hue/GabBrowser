package com.gabbrowser.android

import android.app.SearchManager
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.gabbrowser.android.ui.GabApp

/** FragmentActivity (que já é uma ComponentActivity) porque a tela de digital/PIN do Android exige. */
class MainActivity : FragmentActivity() {

    private lateinit var tabManager: TabManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as GabApplication
        tabManager = TabManager(this, app.sites, app.gabClean, app.gabShield, app.sessionStore, app.appScope)

        if (savedInstanceState == null) handleExternal(intent)

        setContent {
            GabApp(
                tabManager = tabManager,
                settingsRepository = app.settings,
                sites = app.sites,
                gabClean = app.gabClean,
                shield = app.gabShield,
                downloads = app.downloads,
                ai = app.ai,
                vault = app.vault,
                reader = app.reader,
                rxBytesAtStart = app.rxBytesAtStart,
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleExternal(intent)
    }

    /**
     * Link aberto em outro app (ou texto compartilhado). É tratado como entrada não confiável: passa pela mesma
     * barra de endereço, política de esquemas e alerta de golpes que o usuário digitando.
     */
    private fun handleExternal(intent: Intent?) {
        // Extras malformados de outro app não podem derrubar o navegador.
        val text = try {
            when (intent?.action) {
                Intent.ACTION_VIEW -> intent.data?.takeIf { it.scheme == "https" || it.scheme == "http" }?.toString()
                Intent.ACTION_SEND -> intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                Intent.ACTION_WEB_SEARCH -> intent.getCharSequenceExtra(SearchManager.QUERY)?.toString()
                else -> null
            }
        } catch (e: RuntimeException) {
            null
        }
        if (!text.isNullOrBlank()) tabManager.receiveExternal(text.trim())
    }

    override fun onResume() {
        super.onResume()
        tabManager.onResume()
    }

    override fun onPause() {
        tabManager.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        tabManager.destroy()
        super.onDestroy()
    }
}
