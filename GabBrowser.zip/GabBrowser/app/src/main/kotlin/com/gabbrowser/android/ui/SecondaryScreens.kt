package com.gabbrowser.android.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gabbrowser.core.common.SearchEngine
import com.gabbrowser.core.data.SettingsRepository
import com.gabbrowser.core.data.ThemeMode
import com.gabbrowser.core.data.UserSettings
import com.gabbrowser.core.engine.WebViewSession
import kotlinx.coroutines.launch

@Composable
internal fun ScreenColumn(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.height(16.dp))
        content()
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
internal fun Note(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
internal fun GroupTitle(text: String) {
    Text(
        text = text,
        modifier = Modifier.padding(top = 20.dp, bottom = 6.dp),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
    )
}

// ---------------------------------------------------------------- Ferramentas

/** [screen] = null: ainda não disponível, entra na etapa indicada em [stage]. */
private data class ToolStatus(
    val name: String,
    val description: String,
    val stage: String,
    val screen: Screen? = null,
) {
    val available: Boolean get() = screen != null
}

private val TOOLS = listOf(
    ToolStatus("GabShield", "Central de segurança: golpes, conexões, permissões e relatório.", "Ativo", Screen.GABSHIELD),
    ToolStatus("GabClean", "Bloqueio de anúncios, rastreadores e anúncios do YouTube.", "Ativo", Screen.GABCLEAN),
    ToolStatus("GabDownload", "Downloads com progresso, abrir e apagar arquivos.", "Ativo", Screen.DOWNLOADS),
    ToolStatus("Favoritos", "Favoritos com pastas, edição e busca.", "Ativo", Screen.BOOKMARKS),
    ToolStatus("Histórico", "Busca, exclusão de páginas e limpeza completa.", "Ativo", Screen.HISTORY),
    ToolStatus("GabAI", "Resume, explica e traduz páginas com a sua chave de IA.", "Ativo", Screen.GABAI),
    ToolStatus("GabOne", "Limpeza de dados com um toque.", "Ativo", Screen.GABONE),
    ToolStatus("GabFlow", "Grupos de abas: Trabalho, Estudos, Pessoal... Na tela de abas.", "Ativo", Screen.TABS),
    ToolStatus("GabSaver", "Economia de dados, memória e bateria, com relatório.", "Ativo", Screen.GABSAVER),
    ToolStatus("GabReader", "Modo leitura, leitura em voz alta e artigos offline.", "Ativo", Screen.READER),
    ToolStatus("GabScan", "Leitor de QR Code que verifica o destino antes de abrir.", "Ativo", Screen.SCAN),
    ToolStatus("Senhas", "Senhas cifradas, preenchidas com digital ou PIN.", "Ativo", Screen.PASSWORDS),
)

@Composable
fun ToolsScreen(onNavigate: (Screen) -> Unit) {
    ScreenColumn(title = "Ferramentas") {
        Note("Todas as ferramentas do GabBrowser.")
        Spacer(Modifier.height(8.dp))
        TOOLS.forEach { tool ->
            val target = tool.screen
            val rowModifier = if (target != null) {
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClickLabel = "Abrir ${tool.name}") { onNavigate(target) }
            } else {
                Modifier
            }
            Row(
                modifier = rowModifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = tool.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = tool.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.width(12.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (tool.available) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    },
                ) {
                    Text(
                        text = tool.stage,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (tool.available) {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Configurações

@Composable
fun SettingsScreen(settings: UserSettings, settingsRepository: SettingsRepository) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val appVersion = remember {
        runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull() ?: "desconhecida"
    }
    val engine = remember { WebViewSession.engineDescription(context) ?: "não identificado" }

    ScreenColumn(title = "Configurações") {
        GroupTitle("Mecanismo de pesquisa")
        SearchEngine.entries.forEach { option ->
            RadioRow(
                label = option.displayName,
                selected = settings.searchEngine == option,
                onSelect = { scope.launch { settingsRepository.setSearchEngine(option) } },
            )
        }

        GroupTitle("Tema")
        ThemeMode.entries.forEach { option ->
            RadioRow(
                label = option.displayName,
                selected = settings.themeMode == option,
                onSelect = { scope.launch { settingsRepository.setThemeMode(option) } },
            )
        }

        GroupTitle("Privacidade")
        Note(
            "Histórico e favoritos ficam somente neste aparelho. O GabBrowser não tem " +
                "analytics nem envia dados de uso. Os sites que você visita e o mecanismo de " +
                "pesquisa escolhido continuam vendo seus acessos.",
        )

        GroupTitle("Sobre")
        Note("GabBrowser $appVersion")
        Note("Motor: Android System WebView ($engine)")
    }
}

@Composable
internal fun RadioRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .selectable(selected = selected, role = Role.RadioButton, onClick = onSelect)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground,
        )
    }
}
