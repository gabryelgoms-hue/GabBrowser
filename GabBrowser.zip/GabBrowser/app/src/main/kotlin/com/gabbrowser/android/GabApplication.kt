package com.gabbrowser.android

import android.app.Application
import com.gabbrowser.core.data.GabData
import com.gabbrowser.core.data.SessionStore
import com.gabbrowser.core.data.SettingsRepository
import com.gabbrowser.core.data.SiteRepository
import com.gabbrowser.core.data.ai.GabAiRepository
import com.gabbrowser.core.data.passwords.PasswordVault
import com.gabbrowser.core.data.reader.ReaderStore
import com.gabbrowser.core.data.downloads.GabDownloads
import com.gabbrowser.core.data.gabclean.GabCleanRepository
import com.gabbrowser.core.data.gabshield.GabShieldRepository
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Dependências do app, criadas sob demanda. Sem analytics e sem SDKs de terceiros. */
class GabApplication : Application() {

    /** Bytes recebidos pelo app quando ele abriu, para o relatório do GabSaver. */
    var rxBytesAtStart: Long = -1L
        private set

    override fun onCreate() {
        super.onCreate()
        rxBytesAtStart = android.net.TrafficStats.getUidRxBytes(android.os.Process.myUid())
    }

    /**
     * Falhas em tarefas de fundo (gravação de estatísticas, preferências) não podem derrubar o app:
     * o erro é descartado e a tarefa seguinte tenta de novo.
     */
    val appScope: CoroutineScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default + CoroutineExceptionHandler { _, _ -> },
    )

    val settings: SettingsRepository by lazy { SettingsRepository(this) }

    val sites: SiteRepository by lazy { GabData.siteRepository(this) }

    val gabClean: GabCleanRepository by lazy { GabCleanRepository(this, appScope) }

    val gabShield: GabShieldRepository by lazy { GabShieldRepository(this, gabClean, appScope) }

    val sessionStore: SessionStore by lazy { SessionStore(this) }

    val downloads: GabDownloads by lazy { GabDownloads(this) }

    val ai: GabAiRepository by lazy { GabAiRepository(this) }

    val vault: PasswordVault by lazy { PasswordVault(this) }

    val reader: ReaderStore by lazy { ReaderStore(this) }
}
