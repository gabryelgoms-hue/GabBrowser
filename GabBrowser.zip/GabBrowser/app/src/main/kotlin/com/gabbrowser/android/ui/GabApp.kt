package com.gabbrowser.android.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.view.WindowManager
import android.webkit.WebChromeClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.android.TabManager
import com.gabbrowser.core.common.UrlInputClassifier
import com.gabbrowser.core.data.SettingsRepository
import com.gabbrowser.core.data.SiteRepository
import com.gabbrowser.core.data.ThemeMode
import com.gabbrowser.core.data.UserSettings
import com.gabbrowser.core.data.ai.GabAiRepository
import com.gabbrowser.core.data.passwords.PasswordVault
import com.gabbrowser.core.data.passwords.SaveCheck
import com.gabbrowser.core.data.passwords.VaultSettings
import com.gabbrowser.core.data.reader.ReaderArticle
import com.gabbrowser.core.data.reader.ReaderStore
import com.gabbrowser.core.data.downloads.DownloadRequest
import com.gabbrowser.core.data.downloads.EnqueueResult
import com.gabbrowser.core.data.downloads.GabDownloads
import com.gabbrowser.core.data.gabclean.GabCleanRepository
import com.gabbrowser.core.data.gabshield.GabShieldRepository
import com.gabbrowser.core.designsystem.GabTheme
import com.gabbrowser.core.engine.EngineEvent
import com.gabbrowser.core.engine.PageState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

enum class Screen { HOME, BROWSER, TABS, TOOLS, GABSHIELD, GABCLEAN, GABAI, GABONE, GABSAVER, READER, SCAN, PASSWORDS, SETTINGS, DOWNLOADS, BOOKMARKS, HISTORY }

private val EMPTY_PAGE: StateFlow<PageState> = MutableStateFlow(PageState())

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GabApp(
    tabManager: TabManager,
    settingsRepository: SettingsRepository,
    sites: SiteRepository,
    gabClean: GabCleanRepository,
    shield: GabShieldRepository,
    downloads: GabDownloads,
    ai: GabAiRepository,
    vault: PasswordVault,
    reader: ReaderStore,
    rxBytesAtStart: Long,
) {
    val settings by settingsRepository.settings.collectAsStateWithLifecycle(initialValue = UserSettings())
    val tab = tabManager.selected
    val isPrivate = tab?.isPrivate == true
    // Abas anônimas sempre no tema escuro, para ficar claro em que modo se está.
    val darkTheme = isPrivate || when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    SystemBarsAppearance(darkTheme)

    GabTheme(darkTheme = darkTheme) {
        var stack by remember { mutableStateOf(listOf(Screen.HOME)) }
        val screen = stack.last()
        // Sem print também na tela de abas, que mostra miniaturas das abas anônimas.
        PrivateWindowGuard(
            isPrivate || screen == Screen.PASSWORDS || (screen == Screen.TABS && tabManager.count(private = true) > 0),
        )
        var focusRequested by remember { mutableStateOf(false) }
        var pendingDownload by remember { mutableStateOf<DownloadRequest?>(null) }
        val snackbar = remember { SnackbarHostState() }
        val scope = rememberCoroutineScope()

        val session = tab?.session
        val page by remember(session) { session?.state ?: EMPTY_PAGE }.collectAsStateWithLifecycle()
        val context = LocalContext.current
        var permissionPrompt by remember { mutableStateOf<EngineEvent.PermissionRequested?>(null) }
        var fullscreen by remember { mutableStateOf<EngineEvent.EnterFullscreen?>(null) }
        var pendingFileChooser by remember { mutableStateOf<EngineEvent.FileChooserRequested?>(null) }
        var permissionPromptPrivate by remember { mutableStateOf(false) }
        var awaitingAndroid by remember { mutableStateOf<EngineEvent.PermissionRequested?>(null) }

        /** Vai para a tela; se ela já está na pilha, volta até ela em vez de empilhar de novo. */
        fun navigate(target: Screen) {
            val index = stack.indexOf(target)
            stack = if (index >= 0) stack.subList(0, index + 1).toList() else stack + target
        }

        fun notify(message: String) {
            scope.launch { snackbar.showSnackbar(message) }
        }

        // Depois que o usuário permite no GabBrowser, o Android também precisa permitir ao app.
        val androidPermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions(),
        ) {
            val request = awaitingAndroid ?: return@rememberLauncherForActivityResult
            awaitingAndroid = null
            val granted = request.permissions.all { hasAndroidPermission(context, it) }
            request.respond(granted)
            if (!granted) {
                notify("O Android não liberou o acesso. Ajuste em Configurações > Apps > GabBrowser > Permissões.")
            }
        }

        val fileChooserLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
        ) { result ->
            val request = pendingFileChooser ?: return@rememberLauncherForActivityResult
            pendingFileChooser = null
            val data = result.data
            val clip = data?.clipData
            // Vários arquivos chegam em clipData; parseResult só lê o primeiro.
            val uris = if (result.resultCode == Activity.RESULT_OK && clip != null && clip.itemCount > 0) {
                Array(clip.itemCount) { clip.getItemAt(it).uri }
            } else {
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
            }
            request.onResult(uris)
        }

        fun grantSitePermission(request: EngineEvent.PermissionRequested) {
            val missing = request.permissions.filterNot { hasAndroidPermission(context, it) }
            if (missing.isEmpty()) {
                request.respond(true)
            } else {
                awaitingAndroid = request
                androidPermissionLauncher.launch(missing.flatMap { androidPermissionsFor(it) }.toTypedArray())
            }
        }

        permissionPrompt?.let { request ->
            SitePermissionDialog(
                request = request,
                canRemember = !permissionPromptPrivate,
                onDecision = { allow, rememberChoice ->
                    permissionPrompt = null
                    if (rememberChoice && !permissionPromptPrivate) {
                        scope.launch { shield.remember(request.origin, request.permissions, allow) }
                    }
                    if (allow) grantSitePermission(request) else request.respond(false)
                },
            )
        }

        val vaultSettings by vault.settings.collectAsStateWithLifecycle(initialValue = VaultSettings())
        var readerArticle by remember { mutableStateOf<ReaderArticle?>(null) }
        var readerFromPrivate by remember { mutableStateOf(false) }
        var savePrompt by remember { mutableStateOf<EngineEvent.CredentialSubmitted?>(null) }
        var savePromptUpdate by remember { mutableStateOf(false) }

        // Artigo lido em aba anônima some quando a sessão anônima acaba ou quando se volta para uma aba normal.
        val privateTabs = tabManager.count(private = true)
        LaunchedEffect(isPrivate, privateTabs) {
            if (readerFromPrivate && (!isPrivate || privateTabs == 0)) {
                readerArticle = null
                readerFromPrivate = false
            }
        }

        LaunchedEffect(vaultSettings.offerToSave) {
            tabManager.applyPasswordCapture(vaultSettings.offerToSave && BiometricGate.isAvailable(context))
        }

        savePrompt?.let { credential ->
            SavePasswordDialog(
                host = displayHost(credential.origin),
                username = credential.username,
                isUpdate = savePromptUpdate,
                onSave = {
                    savePrompt = null
                    scope.launch {
                        val ok = vault.save(credential.origin, credential.username, credential.password)
                        notify(if (ok) "Senha salva." else "O Android não conseguiu proteger a senha; ela não foi salva.")
                    }
                },
                onNever = {
                    savePrompt = null
                    scope.launch { vault.neverSaveFor(credential.origin) }
                },
                onDismiss = { savePrompt = null },
            )
        }

        // GabSaver: aplica economia de imagens e de memória a todas as abas.
        LaunchedEffect(settings.saverNoImages, settings.saverLowMemory) {
            tabManager.applySaver(noImages = settings.saverNoImages, lowMemory = settings.saverLowMemory)
        }

        // Uma conversa do GabAI por aba; some quando a aba fecha.
        val aiConversations = remember { mutableMapOf<Long, AiConversation>() }
        aiConversations.keys.retainAll(tabManager.tabs.map { it.id }.toSet())

        // Link ou texto vindo de outro app: abre em aba nova, pelo mesmo caminho da barra de endereço.
        LaunchedEffect(tabManager.pendingExternal) {
            val text = tabManager.consumeExternal() ?: return@LaunchedEffect
            // Com o app recém-aberto, as preferências podem ainda não ter carregado: lê direto.
            val engine = settingsRepository.settings.first().searchEngine
            val target = UrlInputClassifier.classify(text, engine) ?: return@LaunchedEffect
            tabManager.openInNewTab(target.url)
            navigate(Screen.BROWSER)
        }

        // Abas da última sessão: reabre direto a página que estava aberta.
        LaunchedEffect(tabManager.restored) {
            val restoredTab = tabManager.selected
            if (tabManager.restored && stack == listOf(Screen.HOME) && restoredTab != null && !restoredTab.isBlank) {
                tabManager.select(restoredTab)
                navigate(Screen.BROWSER)
            }
        }

        LaunchedEffect(session) {
            // Tela cheia de outra aba (talvez anônima) não pode continuar por cima depois da troca de aba.
            fullscreen?.exit?.invoke()
            fullscreen = null
            // Pedido de permissão de outra aba não pode ficar aberto depois da troca de aba.
            permissionPrompt?.respond?.invoke(false)
            permissionPrompt = null
            val current = session ?: return@LaunchedEffect
            current.events.collect { event ->
                when (event) {
                    is EngineEvent.NavigationBlocked ->
                        notify("Link do tipo \"${event.scheme}:\" bloqueado por segurança.")

                    is EngineEvent.DownloadRequested -> {
                        val request = downloads.prepare(
                            url = event.url,
                            userAgent = event.userAgent,
                            contentDisposition = event.contentDisposition,
                            mimeType = event.mimeType,
                            contentLength = event.contentLength,
                            // Aba anônima: sem cookies, para nada da sessão anônima ir parar no
                            // registro do gerenciador de downloads do Android.
                            cookies = if (current.isPrivate) null else current.cookiesFor(event.url),
                            isPrivate = current.isPrivate,
                        )
                        if (request == null) {
                            notify("Este arquivo é gerado pela própria página e o GabBrowser ainda não consegue baixá-lo.")
                        } else {
                            pendingDownload = request
                        }
                    }

                    is EngineEvent.CredentialSubmitted -> {
                        if (!current.isPrivate) {
                            val check = try {
                                vault.check(event.origin, event.username, event.password, vault.settings.first())
                            } catch (e: RuntimeException) {
                                null // Keystore com defeito: não oferece salvar, mas o app segue.
                            }
                            if (check is SaveCheck.Ask) {
                                savePromptUpdate = check.isUpdate
                                savePrompt = event
                            }
                        }
                    }

                    is EngineEvent.PermissionCanceled -> {
                        if (permissionPrompt?.origin == event.origin) permissionPrompt = null
                    }

                    is EngineEvent.EnterFullscreen -> {
                        fullscreen?.exit?.invoke()
                        fullscreen = event
                    }

                    is EngineEvent.ExitFullscreen -> fullscreen = null

                    is EngineEvent.FileChooserRequested -> {
                        pendingFileChooser?.onResult?.invoke(null)
                        pendingFileChooser = event
                        try {
                            fileChooserLauncher.launch(event.intent)
                        } catch (e: ActivityNotFoundException) {
                            pendingFileChooser = null
                            event.onResult(null)
                            notify("Nenhum app para escolher arquivos foi encontrado.")
                        }
                    }

                    is EngineEvent.PermissionRequested -> {
                        // Abas anônimas não usam nem gravam decisões: perguntam sempre.
                        val stored = if (current.isPrivate) {
                            emptyList()
                        } else {
                            event.permissions.map { shield.decisionFor(event.origin, it) }
                        }
                        when {
                            stored.isNotEmpty() && stored.all { it == true } -> grantSitePermission(event)
                            stored.any { it == false } -> event.respond(false)
                            else -> {
                                permissionPrompt?.respond?.invoke(false)
                                permissionPromptPrivate = current.isPrivate
                                permissionPrompt = event
                            }
                        }
                    }
                }
            }
        }

        val open: (String) -> Unit = { input ->
            val target = UrlInputClassifier.classify(input, settings.searchEngine)
            if (target != null) {
                tabManager.open(target.url)
                navigate(Screen.BROWSER)
            }
        }
        val openUrl: (String) -> Unit = { url ->
            tabManager.open(url)
            navigate(Screen.BROWSER)
        }
        val newTab: (Boolean) -> Unit = { private ->
            if (tabManager.newTab(private) == null) {
                notify("O WebView deste aparelho não consegue isolar abas anônimas. Atualize o \"Android System WebView\" na Play Store.")
            } else {
                navigate(Screen.HOME)
            }
        }

        pendingDownload?.let { request ->
            DownloadConfirmDialog(
                request = request,
                onConfirm = {
                    pendingDownload = null
                    scope.launch {
                        when (val result = downloads.enqueue(request)) {
                            is EnqueueResult.Started -> {
                                val answer = snackbar.showSnackbar(
                                    message = "Baixando ${result.fileName}",
                                    actionLabel = if (request.isPrivate) null else "Ver",
                                )
                                if (answer == SnackbarResult.ActionPerformed) navigate(Screen.DOWNLOADS)
                            }

                            is EnqueueResult.Failed -> snackbar.showSnackbar("Não foi possível baixar: ${result.reason}.")
                        }
                    }
                },
                onDismiss = { pendingDownload = null },
            )
        }

        val pageCanGoBack = screen == Screen.BROWSER && page.canGoBack && page.error == null
        BackHandler(enabled = pageCanGoBack || stack.size > 1) {
            if (pageCanGoBack) session?.goBack() else stack = stack.dropLast(1)
        }

        // Vídeo em tela cheia: "voltar" sai da tela cheia (registrado depois, tem prioridade).
        fullscreen?.let { video ->
            BackHandler {
                video.exit()
                fullscreen = null
            }
        }

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                GabBottomBar(
                    current = screen,
                    tabCount = tabManager.count(private = isPrivate),
                    onHome = { navigate(Screen.HOME) },
                    onSearch = {
                        if (screen != Screen.BROWSER || session == null) navigate(Screen.HOME)
                        focusRequested = true
                    },
                    onTabs = {
                        tabManager.captureSelectedThumbnail()
                        navigate(Screen.TABS)
                    },
                    onTools = { navigate(Screen.TOOLS) },
                    onSettings = { navigate(Screen.SETTINGS) },
                )
            },
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .consumeWindowInsets(padding)
                    .imePadding(),
            ) {
                val home: @Composable () -> Unit = {
                    HomeScreen(
                        sites = sites,
                        isPrivate = isPrivate,
                        focusRequested = focusRequested,
                        onFocusConsumed = { focusRequested = false },
                        onOpen = open,
                        onNavigate = { navigate(it) },
                        onNewPrivateTab = { newTab(true) },
                    )
                }
                when (screen) {
                    Screen.HOME -> home()

                    Screen.BROWSER -> if (tab != null && session != null) {
                        BrowserScreen(
                            session = session,
                            page = page,
                            sites = sites,
                            gabClean = gabClean,
                            shield = shield,
                            focusRequested = focusRequested,
                            onFocusConsumed = { focusRequested = false },
                            onSubmit = open,
                            onNewTab = newTab,
                            onNavigate = { navigate(it) },
                            onHome = { navigate(Screen.HOME) },
                            onRecover = { tabManager.recover(tab) },
                            ai = ai,
                            aiConversation = aiConversations.getOrPut(tab.id) { AiConversation() },
                            vault = vault,
                            reader = reader,
                            onReader = { article ->
                                readerArticle = article
                                readerFromPrivate = tab.isPrivate
                                navigate(Screen.READER)
                            },
                            notify = { notify(it) },
                        )
                    } else {
                        home()
                    }

                    Screen.TABS -> TabsScreen(
                        tabManager = tabManager,
                        startPrivate = isPrivate,
                        onOpenTab = { chosen ->
                            tabManager.select(chosen)
                            navigate(if (chosen.isBlank) Screen.HOME else Screen.BROWSER)
                        },
                        onNewTab = newTab,
                    )

                    Screen.TOOLS -> ToolsScreen(onNavigate = { navigate(it) })

                    Screen.GABCLEAN -> GabCleanScreen(gabClean = gabClean)

                    Screen.GABSHIELD -> GabShieldScreen(
                        shield = shield,
                        gabClean = gabClean,
                        onNavigate = { navigate(it) },
                    )

                    Screen.SETTINGS -> SettingsScreen(
                        settings = settings,
                        settingsRepository = settingsRepository,
                    )

                    Screen.DOWNLOADS -> DownloadsScreen(downloads = downloads)

                    Screen.GABAI -> GabAiScreen(ai = ai)

                    Screen.READER -> ReaderScreen(
                        article = readerArticle,
                        store = reader,
                        canSave = !readerFromPrivate,
                        onOpenSaved = {
                            readerArticle = it
                            readerFromPrivate = false
                        },
                        onOpenOriginal = openUrl,
                        notify = { notify(it) },
                    )

                    Screen.SCAN -> GabScanScreen(shield = shield, onOpen = openUrl)

                    Screen.PASSWORDS -> PasswordsScreen(vault = vault)

                    Screen.GABONE -> GabOneScreen(
                        settings = settings,
                        settingsRepository = settingsRepository,
                        tabManager = tabManager,
                        sites = sites,
                        gabClean = gabClean,
                        onDone = { summary ->
                            notify(summary)
                            navigate(Screen.HOME)
                        },
                    )

                    Screen.GABSAVER -> GabSaverScreen(
                        settings = settings,
                        settingsRepository = settingsRepository,
                        gabClean = gabClean,
                        rxBytesAtStart = rxBytesAtStart,
                    )

                    Screen.BOOKMARKS -> BookmarksScreen(sites = sites, onOpen = openUrl)

                    Screen.HISTORY -> HistoryScreen(sites = sites, onOpen = openUrl)
                }
            }
        }

        // Por cima de tudo, sem tirar a página da tela (o WebView continua ligado para o vídeo seguir tocando).
        fullscreen?.let { video -> FullscreenVideo(video.view) }
    }
}

@Composable
private fun GabBottomBar(
    current: Screen,
    tabCount: Int,
    onHome: () -> Unit,
    onSearch: () -> Unit,
    onTabs: () -> Unit,
    onTools: () -> Unit,
    onSettings: () -> Unit,
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
    ) {
        NavigationBarItem(
            selected = current == Screen.HOME,
            onClick = onHome,
            icon = { Icon(Icons.Filled.Home, contentDescription = null) },
            label = { BarLabel("Início") },
        )
        NavigationBarItem(
            selected = false,
            onClick = onSearch,
            icon = { Icon(Icons.Filled.Search, contentDescription = null) },
            label = { BarLabel("Pesquisa") },
        )
        NavigationBarItem(
            selected = current == Screen.TABS,
            onClick = onTabs,
            icon = { TabCountIcon(count = tabCount) },
            label = { BarLabel("Abas") },
        )
        NavigationBarItem(
            selected = current in TOOL_SCREENS,
            onClick = onTools,
            icon = { Icon(Icons.Filled.Build, contentDescription = null) },
            label = { BarLabel("Ferramentas") },
        )
        NavigationBarItem(
            selected = current == Screen.SETTINGS,
            onClick = onSettings,
            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
            label = { BarLabel("Ajustes") },
        )
    }
}

private val TOOL_SCREENS = setOf(
    Screen.TOOLS, Screen.GABSHIELD, Screen.GABCLEAN, Screen.GABAI, Screen.GABONE, Screen.GABSAVER,
    Screen.READER, Screen.SCAN, Screen.PASSWORDS, Screen.DOWNLOADS, Screen.BOOKMARKS, Screen.HISTORY)

/** Rótulo da barra inferior em uma linha só, mesmo em telas estreitas. */
@Composable
private fun BarLabel(text: String) {
    Text(
        text = text,
        fontSize = 11.sp,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Ellipsis,
    )
}

/** Quadradinho com o número de abas abertas, como nos navegadores móveis. */
@Composable
private fun TabCountIcon(count: Int) {
    val color = LocalContentColor.current
    Surface(
        modifier = Modifier.size(22.dp),
        shape = RoundedCornerShape(6.dp),
        color = Color.Transparent,
        contentColor = color,
        border = BorderStroke(2.dp, color),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = if (count > 99) ":D" else count.toString(),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun FullscreenVideo(view: android.view.View) {
    val host = LocalView.current
    DisposableEffect(view) {
        val window = (host.context as Activity).window
        val controller = WindowCompat.getInsetsController(window, host)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller.show(WindowInsetsCompat.Type.systemBars()) }
    }
    AndroidView(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        factory = { view.also { (it.parent as? android.view.ViewGroup)?.removeView(it) } },
    )
}

/** Ícones da barra de status e de navegação acompanham o tema escolhido no app. */
@Composable
private fun SystemBarsAppearance(darkTheme: Boolean) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !darkTheme
            controller.isAppearanceLightNavigationBars = !darkTheme
        }
    }
}

/** Em aba anônima, o Android não tira print nem mostra a página na tela de apps recentes. */
@Composable
private fun PrivateWindowGuard(active: Boolean) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            if (active) {
                window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
        }
    }
}
