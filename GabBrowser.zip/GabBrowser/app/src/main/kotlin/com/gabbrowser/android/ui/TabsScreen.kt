package com.gabbrowser.android.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gabbrowser.android.BrowserTab
import com.gabbrowser.android.TabManager
import com.gabbrowser.core.designsystem.GabIcons
import com.gabbrowser.core.designsystem.GabLogo

@Composable
fun TabsScreen(
    tabManager: TabManager,
    startPrivate: Boolean,
    onOpenTab: (BrowserTab) -> Unit,
    onNewTab: (Boolean) -> Unit,
) {
    var showPrivate by remember { mutableStateOf(startPrivate) }
    var query by remember { mutableStateOf("") }
    var confirmCloseAll by remember { mutableStateOf(false) }
    var groupFilter by remember { mutableStateOf<String?>(null) }
    var groupingTab by remember { mutableStateOf<BrowserTab?>(null) }

    val groups = tabManager.groups(private = showPrivate)
    val currentFilter = groupFilter
    if (currentFilter != null && currentFilter !in groups) groupFilter = null
    val ofKind = tabManager.tabs.filter { it.isPrivate == showPrivate && (groupFilter == null || it.group == groupFilter) }

    groupingTab?.let { tab ->
        GroupPickerDialog(
            current = tab.group,
            existing = groups,
            onPick = { group ->
                groupingTab = null
                tabManager.setGroup(tab, group)
            },
            onDismiss = { groupingTab = null },
        )
    }
    val visible = if (query.isBlank()) {
        ofKind
    } else {
        val q = query.trim().lowercase()
        ofKind.filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) }
    }

    if (confirmCloseAll) {
        AlertDialog(
            onDismissRequest = { confirmCloseAll = false },
            title = { Text(if (showPrivate) "Fechar abas anônimas?" else "Fechar todas as abas?") },
            text = {
                Text(
                    if (showPrivate) {
                        "Todas as abas anônimas serão fechadas e os dados delas apagados."
                    } else {
                        "As ${ofKind.size} abas normais serão fechadas. Histórico e favoritos continuam salvos."
                    },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmCloseAll = false
                    tabManager.closeAll(private = showPrivate)
                }) { Text("Fechar") }
            },
            dismissButton = { TextButton(onClick = { confirmCloseAll = false }) { Text("Cancelar") } },
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 8.dp, top = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Abas",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
            )
            if (ofKind.isNotEmpty()) {
                TextButton(onClick = { confirmCloseAll = true }) { Text("Fechar todas") }
            }
        }

        Row(
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(4.dp),
        ) {
            Segment(
                label = "Normais (${tabManager.count(private = false)})",
                selected = !showPrivate,
                modifier = Modifier.weight(1f),
            ) { showPrivate = false }
            Segment(
                label = "Anônimas (${tabManager.count(private = true)})",
                selected = showPrivate,
                modifier = Modifier.weight(1f),
            ) { showPrivate = true }
        }

        if (groups.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                GroupChip("Todas", groupFilter == null) { groupFilter = null }
                groups.forEach { group ->
                    GroupChip(group, groupFilter == group) { groupFilter = group }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        if (ofKind.size > 3) {
            TabSearchField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.padding(horizontal = 20.dp),
            )
            Spacer(Modifier.height(8.dp))
        }

        Box(Modifier.weight(1f)) {
            when {
                showPrivate && !tabManager.privateTabsSupported -> EmptyTabs(
                    "O WebView deste aparelho não consegue isolar abas anônimas. " +
                        "Atualize o \"Android System WebView\" na Play Store para usar este modo.",
                )

                ofKind.isEmpty() -> EmptyTabs(
                    if (showPrivate) {
                        "Nenhuma aba anônima aberta. Nada destas abas fica salvo depois de fechadas."
                    } else {
                        "Nenhuma aba aberta."
                    },
                )

                visible.isEmpty() -> EmptyTabs("Nenhuma aba encontrada para \"$query\".")

                else -> LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 88.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(visible, key = { it.id }) { tab ->
                        TabCard(
                            tab = tab,
                            selected = tab.id == tabManager.selectedId,
                            onOpen = { onOpenTab(tab) },
                            onClose = { tabManager.close(tab) },
                            onGroup = { groupingTab = tab },
                        )
                    }
                }
            }

            if (!showPrivate || tabManager.privateTabsSupported) {
                Button(
                    onClick = { onNewTab(showPrivate) },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp),
                ) {
                    Icon(
                        imageVector = if (showPrivate) GabIcons.Mask else Icons.Filled.Add,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(if (showPrivate) "Nova aba anônima" else "Nova aba")
                }
            }
        }
    }
}

@Composable
private fun Segment(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        color = if (selected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant,
        shadowElevation = if (selected) 1.dp else 0.dp,
    ) {
        Text(
            text = label,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun TabSearchField(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (value.isEmpty()) {
                            Text(
                                text = "Pesquisar nas abas",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        inner()
                    }
                },
            )
        }
    }
}

@Composable
private fun TabCard(
    tab: BrowserTab,
    selected: Boolean,
    onOpen: () -> Unit,
    onClose: () -> Unit,
    onGroup: () -> Unit,
) {
    val name = if (tab.isBlank) "Página inicial" else tab.title.ifBlank { displayHost(tab.url) }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClickLabel = "Abrir aba $name", onClick = onOpen),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
    ) {
        Column {
            Row(
                modifier = Modifier.padding(start = 12.dp, end = 2.dp, top = 4.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = name,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                IconButton(onClick = onGroup, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = GabIcons.Layers,
                        contentDescription = "Mover $name para um grupo",
                        tint = if (tab.group != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp),
                    )
                }
                IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Fechar aba $name",
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.8f)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                val thumbnail = tab.thumbnail
                when {
                    thumbnail != null && !tab.isBlank -> Image(
                        bitmap = thumbnail,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alignment = Alignment.TopCenter,
                    )

                    tab.isBlank -> GabLogo(logoSize = 48.dp)

                    else -> Text(
                        text = displayHost(tab.url).take(1).uppercase(),
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                tab.group?.let { group ->
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primary,
                    ) {
                        Text(
                            text = group,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                            maxLines = 1,
                        )
                    }
                }
                if (tab.isPrivate) {
                    Icon(
                        imageVector = GabIcons.Mask,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .size(20.dp),
                    )
                }
            }
        }
    }
}

/** Categorias sugeridas do GabFlow; o usuário pode criar outras. */
private val SUGGESTED_GROUPS = listOf("Trabalho", "Estudos", "Pessoal", "Entretenimento", "Compras")

@Composable
private fun GroupChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun GroupPickerDialog(
    current: String?,
    existing: List<String>,
    onPick: (String?) -> Unit,
    onDismiss: () -> Unit,
) {
    var custom by remember { mutableStateOf("") }
    val options = (SUGGESTED_GROUPS + existing).distinct()
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(GabIcons.Layers, contentDescription = null) },
        title = { Text("Grupo da aba") },
        text = {
            Column {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    GroupChip("Sem grupo", current == null) { onPick(null) }
                }
                Spacer(Modifier.height(8.dp))
                options.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { option -> GroupChip(option, current == option) { onPick(option) } }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(
                    value = custom,
                    onValueChange = { custom = it.take(30) },
                    singleLine = true,
                    label = { Text("Novo grupo") },
                )
            }
        },
        confirmButton = {
            TextButton(enabled = custom.isNotBlank(), onClick = { onPick(custom) }) { Text("Criar e mover") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
private fun EmptyTabs(text: String) {
    Text(
        text = text,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 48.dp),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
    )
}
