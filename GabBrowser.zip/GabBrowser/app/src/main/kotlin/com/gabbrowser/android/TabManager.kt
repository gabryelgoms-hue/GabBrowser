package com.gabbrowser.android

import android.app.Activity
import android.os.Bundle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.gabbrowser.core.data.SavedSession
import com.gabbrowser.core.data.SavedTab
import com.gabbrowser.core.data.SessionStore
import com.gabbrowser.core.data.SiteRepository
import com.gabbrowser.core.data.gabclean.GabCleanRepository
import com.gabbrowser.core.data.gabshield.GabShieldRepository
import com.gabbrowser.core.engine.EngineSession
import com.gabbrowser.core.engine.PageError
import com.gabbrowser.core.engine.VisitListener
import com.gabbrowser.core.engine.WebViewSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Uma aba. Pode existir sem sessão viva (suspensa ou restaurada): o motor só é criado quando ela é aberta. */
class BrowserTab internal constructor(
    val id: Long,
    val isPrivate: Boolean,
    url: String,
    title: String,
) {
    var url by mutableStateOf(url)
        internal set
    var title by mutableStateOf(title)
        internal set
    var session: EngineSession? by mutableStateOf(null)
        internal set
    var thumbnail: ImageBitmap? by mutableStateOf(null)
        internal set

    /** GabFlow: grupo da aba ("Trabalho", "Estudos"...), ou null. */
    var group: String? by mutableStateOf(null)
        internal set

    /** Página inicial (nenhum endereço aberto ainda). */
    val isBlank: Boolean get() = url.isEmpty()

    internal var savedState: Bundle? = null
    internal var lastUsed: Long = 0L
    internal var stateJob: Job? = null
}

/**
 * Abas normais e anônimas.
 *
 * Memória: no máximo [MAX_LIVE_SESSIONS] abas mantêm o motor carregado. As demais são suspensas:
 * o histórico de voltar/avançar fica guardado em memória e a página é recarregada quando a aba volta.
 * Downloads não são afetados, porque correm no gerenciador de downloads do Android.
 *
 * Abas anônimas usam um perfil separado do WebView; quando a última é fechada, o perfil é apagado.
 */
class TabManager(
    private val activity: Activity,
    private val sites: SiteRepository,
    private val gabClean: GabCleanRepository,
    private val shield: GabShieldRepository,
    private val sessionStore: SessionStore,
    private val ioScope: CoroutineScope,
) {
    private val mainScope = MainScope()
    private var loadImages = true
    private var passwordCapture = false
    private var maxLiveSessions = DEFAULT_LIVE_SESSIONS
    private var nextId = 1L
    private var persistJob: Job? = null

    val tabs = mutableStateListOf<BrowserTab>()

    var selectedId by mutableStateOf<Long?>(null)
        private set

    val selected: BrowserTab? get() = tabs.firstOrNull { it.id == selectedId }

    /** true depois que as abas da última sessão foram recolocadas. */
    var restored by mutableStateOf(false)
        private set

    /** Texto ou link recebido de outro app, esperando a tela aplicar o mecanismo de pesquisa. */
    var pendingExternal by mutableStateOf<String?>(null)
        private set

    fun receiveExternal(text: String) {
        pendingExternal = text.take(4_000)
    }

    fun consumeExternal(): String? = pendingExternal.also { pendingExternal = null }

    /** Abre em aba nova, normal (links de outros apps nunca caem numa aba anônima aberta). */
    fun openInNewTab(url: String) {
        val tab = newTab(private = false) ?: return
        ensureSession(tab).loadUrl(url)
    }

    val privateTabsSupported: Boolean by lazy { WebViewSession.supportsIsolatedPrivateTabs() }

    private val visitListener = VisitListener { url, title ->
        ioScope.launch { sites.recordVisit(url, title) }
    }

    init {
        mainScope.launch {
            // Restos de uma sessão anônima interrompida (app encerrado à força) são apagados primeiro.
            WebViewSession.wipePrivateProfile()
            val saved = sessionStore.load()
            if (saved.tabs.isNotEmpty()) {
                val restoredTabs = saved.tabs.map { savedTab ->
                    BrowserTab(id = nextId++, isPrivate = false, url = savedTab.url, title = savedTab.title)
                        .also { it.group = savedTab.group }
                }
                tabs.addAll(0, restoredTabs)
                if (selectedId == null) selectedId = restoredTabs[saved.selectedIndex].id
            }
            restored = true
        }
        mainScope.launch {
            gabClean.scriptConfig.collect { config ->
                tabs.forEach { it.session?.applyContentScripts(config) }
            }
        }
    }

    fun count(private: Boolean): Int = tabs.count { it.isPrivate == private }

    /** GabFlow: coloca a aba num grupo (null = sem grupo). */
    fun setGroup(tab: BrowserTab, group: String?) {
        tab.group = group?.trim()?.takeIf { it.isNotEmpty() }?.take(30)
        persistSoon()
    }

    /** Grupos em uso nas abas do tipo indicado, em ordem alfabética. */
    fun groups(private: Boolean): List<String> =
        tabs.filter { it.isPrivate == private }.mapNotNull { it.group }.distinct().sorted()

    /** Senhas: liga ou desliga a oferta de salvar em todas as abas (as anônimas ignoram). */
    fun applyPasswordCapture(enabled: Boolean) {
        passwordCapture = enabled
        tabs.forEach { it.session?.setPasswordCapture(enabled) }
    }

    /** GabSaver: aplica as escolhas de economia a todas as abas abertas e às próximas. */
    fun applySaver(noImages: Boolean, lowMemory: Boolean) {
        loadImages = !noImages
        maxLiveSessions = if (lowMemory) 2 else DEFAULT_LIVE_SESSIONS
        tabs.forEach { it.session?.setLoadImages(loadImages) }
        selected?.let { trimLiveSessions(keep = it) }
    }

    /** Cria uma aba em branco e a seleciona. Devolve null se o aparelho não isola abas anônimas. */
    fun newTab(private: Boolean = false): BrowserTab? {
        if (private && !privateTabsSupported) return null
        val tab = BrowserTab(id = nextId++, isPrivate = private, url = "", title = "")
        tabs += tab
        select(tab)
        return tab
    }

    fun select(tab: BrowserTab) {
        val previous = selected
        if (previous != null && previous.id != tab.id) {
            captureThumbnail(previous)
            previous.session?.onPause()
        }
        selectedId = tab.id
        tab.lastUsed = System.nanoTime()
        if (!tab.isBlank) ensureSession(tab).onResume()
        persistSoon()
    }

    /** Abre um endereço na aba atual; sem aba, cria uma normal. */
    fun open(url: String) {
        val tab = selected ?: newTab(private = false) ?: return
        // Aba com renderizador caído não aceita comandos: recria antes de abrir o endereço.
        if (ensureSession(tab).state.value.error is PageError.RendererCrashed) recover(tab)
        ensureSession(tab).loadUrl(url)
    }

    fun sessionOf(tab: BrowserTab): EngineSession = ensureSession(tab)

    fun close(tab: BrowserTab) {
        val index = tabs.indexOfFirst { it.id == tab.id }
        if (index < 0) return
        release(tab)
        tabs.removeAt(index)
        if (selectedId == tab.id) {
            selectedId = null
            val next = tabs.lastOrNull { it.isPrivate == tab.isPrivate } ?: tabs.lastOrNull()
            if (next != null) select(next)
        }
        if (tab.isPrivate && tabs.none { it.isPrivate }) wipePrivateDataSoon()
        persistSoon()
    }

    fun closeAll(private: Boolean) {
        tabs.filter { it.isPrivate == private }.forEach { close(it) }
    }

    /** Recria o motor da aba depois que o processo de renderização caiu. */
    fun recover(tab: BrowserTab) {
        val url = tab.url
        tab.stateJob?.cancel()
        tab.session?.destroy()
        tab.session = null
        tab.savedState = null
        if (url.isNotEmpty()) ensureSession(tab).loadUrl(url)
    }

    /** Grava a lista de abas imediatamente (usado pelo GabOne). */
    fun saveSessionNow() {
        persistJob?.cancel()
        persistNow()
    }

    fun captureSelectedThumbnail() {
        selected?.let { captureThumbnail(it) }
    }

    fun onResume() {
        selected?.session?.onResume()
    }

    fun onPause() {
        tabs.forEach { it.session?.onPause() }
        gabClean.flushSoon()
        persistJob?.cancel()
        persistNow()
    }

    fun destroy() {
        tabs.forEach { release(it) }
        mainScope.cancel()
    }

    // ------------------------------------------------------------------ Interno

    private fun ensureSession(tab: BrowserTab): EngineSession {
        tab.session?.let { return it }
        val session = WebViewSession(
            context = activity,
            blocker = gabClean,
            guard = shield,
            privateProfile = if (tab.isPrivate) WebViewSession.PRIVATE_PROFILE else null,
            savedState = tab.savedState,
        )
        WebViewSession.installServiceWorkerFilter(gabClean)
        tab.savedState = null
        if (!tab.isPrivate) session.visitListener = visitListener
        session.applyContentScripts(gabClean.currentScriptConfig())
        session.setLoadImages(loadImages)
        session.setPasswordCapture(passwordCapture)
        // Aba restaurada do disco: não há histórico salvo em memória, então abre o último endereço.
        if (session.state.value.url.isEmpty() && tab.url.isNotEmpty()) session.loadUrl(tab.url)
        tab.session = session
        tab.stateJob = mainScope.launch {
            session.state.collect { page ->
                if (page.url.isNotEmpty() && (page.url != tab.url || page.title != tab.title)) {
                    tab.url = page.url
                    tab.title = page.title
                    persistSoon()
                }
            }
        }
        trimLiveSessions(keep = tab)
        return session
    }

    private fun trimLiveSessions(keep: BrowserTab) {
        val liveCount = tabs.count { it.session != null }
        val excess = liveCount - maxLiveSessions
        if (excess <= 0) return
        tabs.filter { it.session != null && it.id != keep.id && it.id != selectedId }
            .sortedBy { it.lastUsed }
            .take(excess)
            .forEach { suspendTab(it) }
    }

    private fun suspendTab(tab: BrowserTab) {
        val session = tab.session ?: return
        captureThumbnail(tab)
        tab.savedState = session.saveState()
        tab.stateJob?.cancel()
        tab.stateJob = null
        session.destroy()
        tab.session = null
    }

    private fun release(tab: BrowserTab) {
        tab.stateJob?.cancel()
        tab.stateJob = null
        tab.session?.destroy()
        tab.session = null
        tab.savedState = null
        tab.thumbnail = null
    }

    private fun captureThumbnail(tab: BrowserTab) {
        val bitmap = tab.session?.captureThumbnail(THUMBNAIL_WIDTH) ?: return
        tab.thumbnail = bitmap.asImageBitmap()
    }

    /** O WebView libera o perfil de forma assíncrona; tenta algumas vezes antes de desistir. */
    private fun wipePrivateDataSoon() {
        shield.clearPrivateSession()
        mainScope.launch {
            repeat(3) {
                delay(500)
                if (tabs.any { it.isPrivate }) return@launch
                if (WebViewSession.wipePrivateProfile()) return@launch
            }
        }
    }

    private fun persistSoon() {
        if (!restored) return
        persistJob?.cancel()
        persistJob = mainScope.launch {
            delay(800)
            persistNow()
        }
    }

    private fun persistNow() {
        if (!restored) return
        val normal = tabs.filter { !it.isPrivate && it.url.startsWith("https://") }
        val snapshot = SavedSession(
            tabs = normal.map { SavedTab(url = it.url, title = it.title, group = it.group) },
            selectedIndex = normal.indexOfFirst { it.id == selectedId }.coerceAtLeast(0),
        )
        ioScope.launch { sessionStore.save(snapshot) }
    }

    private companion object {
        const val DEFAULT_LIVE_SESSIONS = 4
        const val THUMBNAIL_WIDTH = 360
    }
}
