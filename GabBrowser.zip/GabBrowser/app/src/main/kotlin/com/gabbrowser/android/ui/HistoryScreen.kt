package com.gabbrowser.android.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.data.HistoryItem
import com.gabbrowser.core.data.SiteRepository
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

@Composable
fun HistoryScreen(sites: SiteRepository, onOpen: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    val items by remember(query) { sites.searchHistory(query) }
        .collectAsStateWithLifecycle(initialValue = emptyList())

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Limpar todo o histórico?") },
            text = { Text("Todas as páginas visitadas serão apagadas, incluindo \"Mais acessados\". Favoritos e senhas não mudam.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    scope.launch { sites.clearHistory() }
                }) { Text("Limpar") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancelar") } },
        )
    }

    ScreenColumn(title = "Histórico") {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Pesquisar no histórico") },
        )
        Spacer(Modifier.height(8.dp))
        if (items.isNotEmpty() && query.isBlank()) {
            TextButton(onClick = { confirmClear = true }) { Text("Limpar todo o histórico") }
        }
        if (items.isEmpty()) {
            Note(if (query.isBlank()) "Nenhuma página visitada ainda." else "Nada encontrado para \"$query\".")
        }

        var lastDay = ""
        items.forEach { item ->
            val day = dayLabel(item.visitedAt)
            if (day != lastDay) {
                lastDay = day
                Text(
                    text = day,
                    modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            HistoryEntryRow(
                item = item,
                onOpen = { onOpen(item.url) },
                onDelete = { scope.launch { sites.deleteHistoryEntry(item.id) } },
            )
        }
        if (items.size >= 500) {
            Note("Mostrando as 500 visitas mais recentes. Use a busca para achar as mais antigas.")
        }
    }
}

@Composable
private fun HistoryEntryRow(item: HistoryItem, onOpen: () -> Unit, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onOpen)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = item.title.ifBlank { displayHost(item.url) },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = "${timeLabel(item.visitedAt)} · ${displayHost(item.url)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Filled.Close, contentDescription = "Apagar do histórico")
        }
    }
}

private fun dayLabel(time: Long): String {
    val day = Calendar.getInstance().apply { timeInMillis = time }
    val today = Calendar.getInstance()
    val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    fun sameDay(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    return when {
        sameDay(day, today) -> "Hoje"
        sameDay(day, yesterday) -> "Ontem"
        else -> DateFormat.getDateInstance(DateFormat.LONG).format(Date(time))
    }
}

private fun timeLabel(time: Long): String = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(time))
