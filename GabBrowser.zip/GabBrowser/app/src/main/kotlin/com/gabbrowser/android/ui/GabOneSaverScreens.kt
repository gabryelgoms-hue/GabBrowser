package com.gabbrowser.android.ui

import android.content.Context
import android.net.TrafficStats
import android.os.Process
import android.text.format.Formatter
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.android.TabManager
import com.gabbrowser.core.data.CleanAction
import com.gabbrowser.core.data.SettingsRepository
import com.gabbrowser.core.data.SiteRepository
import com.gabbrowser.core.data.UserSettings
import com.gabbrowser.core.data.gabclean.GabCleanRepository
import com.gabbrowser.core.data.gabclean.GabCleanStats
import com.gabbrowser.core.designsystem.GabIcons
import com.gabbrowser.core.engine.WebViewSession
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

// ---------------------------------------------------------------- GabOne

/** Executa as ações escolhidas. Favoritos, senhas e downloads nunca são tocados. */
suspend fun runGabOne(
    actions: Set<CleanAction>,
    context: Context,
    tabManager: TabManager,
    sites: SiteRepository,
    gabClean: GabCleanRepository,
): String {
    val done = mutableListOf<String>()
    if (CleanAction.CLOSE_TABS in actions) {
        tabManager.closeAll(private = true)
        tabManager.closeAll(private = false)
        // Grava a sessão vazia já, para as abas não voltarem se o app for fechado em seguida.
        tabManager.saveSessionNow()
        done += "abas fechadas"
    }
    suspendCancellableCoroutine<Unit> { continuation ->
        WebViewSession.clearBrowsingData(
            context = context,
            cookies = CleanAction.COOKIES in actions,
            siteData = CleanAction.SITE_DATA in actions,
            cache = CleanAction.CACHE in actions,
        ) { if (continuation.isActive) continuation.resume(Unit) }
    }
    if (CleanAction.COOKIES in actions) done += "cookies"
    if (CleanAction.SITE_DATA in actions) done += "dados de sites"
    if (CleanAction.CACHE in actions) done += "cache"
    if (CleanAction.HISTORY in actions) {
        sites.clearHistory()
        gabClean.clearProtectedSites()
        done += "histórico"
    }
    if (CleanAction.OPEN_PRIVATE in actions) tabManager.newTab(private = true)
    return if (done.isEmpty()) "Nada para limpar." else "Limpo: " + done.joinToString(", ") + "."
}

@Composable
fun GabOneScreen(
    settings: UserSettings,
    settingsRepository: SettingsRepository,
    tabManager: TabManager,
    sites: SiteRepository,
    gabClean: GabCleanRepository,
    onDone: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val actions = settings.cleanActions

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            icon = { Icon(GabIcons.Sweep, contentDescription = null) },
            title = { Text("Limpar agora?") },
            text = {
                Column {
                    Text("Será apagado:", style = MaterialTheme.typography.bodyMedium)
                    actions.filter { it != CleanAction.OPEN_PRIVATE }.forEach {
                        Text("• ${it.label}", style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Favoritos, senhas e arquivos baixados não são apagados.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    scope.launch { onDone(runGabOne(actions, context, tabManager, sites, gabClean)) }
                }) { Text("Limpar") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } },
        )
    }

    ScreenColumn(title = "GabOne") {
        Note("Privacidade com um toque: escolha o que limpar e use o botão sempre que quiser.")
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Surface(
                modifier = Modifier
                    .size(132.dp)
                    .clip(CircleShape)
                    .clickable(enabled = actions.any { it != CleanAction.OPEN_PRIVATE }) { confirm = true },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
                shadowElevation = 6.dp,
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Icon(
                        imageVector = GabIcons.Sweep,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(44.dp),
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Limpar",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        GroupTitle("O que o botão faz")
        CleanAction.entries.forEach { action ->
            val checked = action in actions
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        scope.launch {
                            settingsRepository.setCleanActions(if (checked) actions - action else actions + action)
                        }
                    }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Checkbox(checked = checked, onCheckedChange = null)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(action.label, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onBackground)
                    Text(action.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Note(
            "Favoritos, senhas salvas e arquivos baixados nunca são apagados pelo GabOne. Também ficam: " +
                "artigos salvos no GabReader e as escolhas do GabShield (permissões de sites e sites liberados " +
                "sem HTTPS), que podem ser revistas nas telas deles. Conversas do GabAI somem com as abas.",
        )
    }
}

// ---------------------------------------------------------------- GabSaver

@Composable
fun GabSaverScreen(
    settings: UserSettings,
    settingsRepository: SettingsRepository,
    gabClean: GabCleanRepository,
    rxBytesAtStart: Long,
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val stats by gabClean.stats.collectAsStateWithLifecycle(initialValue = GabCleanStats())
    val received = remember(stats) {
        val now = TrafficStats.getUidRxBytes(Process.myUid())
        if (now < 0 || rxBytesAtStart < 0) null else (now - rxBytesAtStart).coerceAtLeast(0)
    }

    ScreenColumn(title = "GabSaver") {
        Note("Menos dados móveis, memória e bateria, principalmente em celulares intermediários.")

        GroupTitle("Economia")
        SaverToggle(
            title = "Não carregar imagens",
            subtitle = "As páginas abrem só com texto. Ótimo para planos de dados pequenos.",
            checked = settings.saverNoImages,
        ) { scope.launch { settingsRepository.setSaverNoImages(it) } }
        SaverToggle(
            title = "Modo leve de abas",
            subtitle = "Mantém só 2 abas carregadas (o normal são 4). As outras recarregam ao voltar a elas.",
            checked = settings.saverLowMemory,
        ) { scope.launch { settingsRepository.setSaverLowMemory(it) } }
        Note(
            "Sempre ativo: vídeos não tocam sozinhos, abas em segundo plano ficam pausadas, " +
                "e o GabClean impede o download de anúncios e rastreadores.",
        )

        GroupTitle("Relatório de consumo")
        Text(
            text = if (received != null) {
                Formatter.formatShortFileSize(context, received)
            } else {
                "Indisponível neste aparelho"
            },
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
        )
        Note("Dados recebidos pelo GabBrowser desde que o app foi aberto (medido pelo Android).")
        Spacer(Modifier.height(12.dp))
        Text(
            text = Formatter.formatShortFileSize(context, stats.requests * 20L * 1024),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
        )
        Note(
            "Economia estimada pelo GabClean desde a instalação: ${stats.requests} requisições de anúncio e " +
                "rastreamento não baixadas × 20 KB (média). É uma estimativa.",
        )
    }
}

@Composable
private fun SaverToggle(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onBackground)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
