package com.gabbrowser.android.ui

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.PersistableBundle
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.data.passwords.CredentialInfo
import com.gabbrowser.core.data.passwords.PasswordVault
import com.gabbrowser.core.data.passwords.VaultSettings
import com.gabbrowser.core.data.security.VaultDecrypt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Autenticação para ver ou preencher senhas: digital, rosto ou o PIN/padrão/senha do próprio aparelho.
 * Sem bloqueio de tela configurado, o cofre não abre (e não oferece salvar).
 */
object BiometricGate {

    /**
     * Android 11+: digital/rosto de classe forte ou o PIN do aparelho. Antes disso o Android não aceita essa
     * combinação na tela de autenticação; usa-se a fraca, e o PIN continua valendo. Nos dois casos a chave do
     * cofre exige a autenticação dentro do próprio Keystore.
     */
    private val AUTHENTICATORS: Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        }

    fun isAvailable(context: Context): Boolean =
        BiometricManager.from(context).canAuthenticate(AUTHENTICATORS) == BiometricManager.BIOMETRIC_SUCCESS

    fun authenticate(
        activity: FragmentActivity,
        title: String,
        subtitle: String,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit,
    ) {
        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    val cancelled = errorCode == BiometricPrompt.ERROR_USER_CANCELED ||
                        errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON ||
                        errorCode == BiometricPrompt.ERROR_CANCELED
                    if (!cancelled) onFailure(errString.toString())
                }
            },
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(AUTHENTICATORS)
            .build()
        prompt.authenticate(info)
    }

    const val NO_LOCK_MESSAGE =
        "Para proteger suas senhas, configure um bloqueio de tela (PIN, padrão, senha ou digital) no Android."
}

/**
 * Copia marcando o conteúdo como sensível (o Android 13+ não mostra a senha na prévia) e limpa a área de
 * transferência depois de 45 s, se ninguém tiver copiado outra coisa.
 */
internal fun copySensitive(context: Context, label: String, value: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, value)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        clip.description.extras = PersistableBundle().apply { putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true) }
    }
    clipboard.setPrimaryClip(clip)
    // Em segundo plano o app não consegue ler a área de transferência (Android 10+), então limpa sem conferir.
    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                clipboard.clearPrimaryClip()
            } else {
                clipboard.setPrimaryClip(ClipData.newPlainText("", ""))
            }
        } catch (e: RuntimeException) {
            // Serviço indisponível: nada a fazer.
        }
    }, 45_000)
}

/** Lê a senha do cofre logo depois da autenticação. */
internal suspend fun revealAfterAuth(vault: PasswordVault, id: Long): String? =
    when (val result = vault.reveal(id)) {
        is VaultDecrypt.Success -> result.value
        else -> null
    }

@Composable
internal fun SavePasswordDialog(
    host: String,
    username: String,
    isUpdate: Boolean,
    onSave: () -> Unit,
    onNever: () -> Unit,
    onDismiss: () -> Unit,
) {
    // Botões ativos só depois de um instante: a página não consegue fazer o usuário tocar sem querer.
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(700)
        armed = true
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Lock, contentDescription = null) },
        title = { Text(if (isUpdate) "Atualizar a senha salva?" else "Salvar senha?") },
        text = {
            Column {
                Text(
                    text = "Site: $host" + if (username.isNotEmpty()) "\nUsuário: $username" else "",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "A senha fica cifrada só neste celular e só aparece ou é preenchida depois da sua digital ou PIN.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = { TextButton(enabled = armed, onClick = onSave) { Text(if (isUpdate) "Atualizar" else "Salvar") } },
        dismissButton = {
            Row {
                TextButton(enabled = armed, onClick = onNever) { Text("Nunca neste site") }
                TextButton(onClick = onDismiss) { Text("Agora não") }
            }
        },
    )
}

@Composable
fun PasswordsScreen(vault: PasswordVault) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val scope = rememberCoroutineScope()
    val credentials by vault.credentials.collectAsStateWithLifecycle(initialValue = emptyList())
    val settings by vault.settings.collectAsStateWithLifecycle(initialValue = VaultSettings())
    var revealed by remember { mutableStateOf<Pair<Long, String>?>(null) }
    var deleting by remember { mutableStateOf<CredentialInfo?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    val lockAvailable = remember { BiometricGate.isAvailable(context) }

    // A senha mostrada some sozinha depois de 30 segundos.
    LaunchedEffect(revealed) {
        if (revealed != null) {
            delay(30_000)
            revealed = null
        }
    }

    deleting?.let { item ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Excluir senha?") },
            text = { Text("${displayHost(item.origin)} · ${item.username.ifEmpty { "(sem usuário)" }}") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch { vault.delete(item.id) }
                }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar") } },
        )
    }

    ScreenColumn(title = "Senhas") {
        if (!lockAvailable) {
            Note(BiometricGate.NO_LOCK_MESSAGE)
            Spacer(Modifier.height(8.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Oferecer para salvar senhas", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onBackground)
                Text(
                    "Pergunta depois de cada login. Nunca em abas anônimas.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = settings.offerToSave, onCheckedChange = { scope.launch { vault.setOfferToSave(it) } })
        }
        message?.let {
            Spacer(Modifier.height(6.dp))
            Note(it)
        }

        GroupTitle("Senhas salvas")
        if (credentials.isEmpty()) Note("Nenhuma senha salva.")
        credentials.forEach { item ->
            val shown = revealed?.takeIf { it.first == item.id }?.second
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        if (activity == null || !lockAvailable) {
                            message = BiometricGate.NO_LOCK_MESSAGE
                            return@clickable
                        }
                        BiometricGate.authenticate(
                            activity = activity,
                            title = "Ver senha",
                            subtitle = displayHost(item.origin),
                            onSuccess = {
                                scope.launch {
                                    val password = revealAfterAuth(vault, item.id)
                                    if (password == null) message = "Não foi possível abrir esta senha." else revealed = item.id to password
                                }
                            },
                            onFailure = { message = it },
                        )
                    }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = displayHost(item.origin),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = item.username.ifEmpty { "(sem usuário)" },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = shown ?: "••••••••  (toque para ver)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }
                if (shown != null) {
                    TextButton(onClick = {
                        copySensitive(context, "Senha", shown)
                        message = "Senha copiada."
                    }) { Text("Copiar") }
                }
                TextButton(onClick = { deleting = item }) { Text("Excluir") }
            }
        }

        if (settings.neverSaveOrigins.isNotEmpty()) {
            GroupTitle("Sites em que nunca salvar")
            settings.neverSaveOrigins.sorted().forEach { origin ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = displayHost(origin),
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    TextButton(onClick = { scope.launch { vault.allowSavingFor(origin) } }) { Text("Remover") }
                }
            }
        }

        GroupTitle("Segurança")
        Note(
            "As senhas ficam cifradas com uma chave guardada no Android Keystore, que não sai do aparelho. " +
                "Ver ou preencher pede sua digital, rosto ou o PIN do celular. O preenchimento só acontece no " +
                "mesmo site em que a senha foi salva, o que protege contra páginas falsas. Não há sincronização: " +
                "se o app for desinstalado, as senhas somem junto.",
        )
        Spacer(Modifier.width(1.dp))
    }
}
