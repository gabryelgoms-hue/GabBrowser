package com.gabbrowser.android.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.common.blocking.BlockCategory
import com.gabbrowser.core.common.blocking.BlockLevel
import com.gabbrowser.core.data.gabclean.GabCleanRepository
import com.gabbrowser.core.data.gabclean.GabCleanSettings
import com.gabbrowser.core.data.gabclean.GabCleanStats
import com.gabbrowser.core.data.gabclean.ListUpdateResult
import com.gabbrowser.core.designsystem.GabIcons
import com.gabbrowser.core.engine.WebViewSession
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.text.NumberFormat
import java.util.Date

@Composable
fun GabCleanScreen(gabClean: GabCleanRepository) {
    val settings by gabClean.settings.collectAsStateWithLifecycle(initialValue = GabCleanSettings())
    val stats by gabClean.stats.collectAsStateWithLifecycle(initialValue = GabCleanStats())
    val scope = rememberCoroutineScope()
    val youtubeFull = remember { WebViewSession.supportsFullYoutubeBlocking() }

    var updatingList by remember { mutableStateOf(false) }
    var listMessage by remember { mutableStateOf<String?>(null) }
    var confirmReset by remember { mutableStateOf(false) }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Zerar estatísticas?") },
            text = { Text("Os contadores voltam a zero. Configurações e exceções não mudam.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    scope.launch { gabClean.resetStats() }
                }) { Text("Zerar") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Cancelar") }
            },
        )
    }

    ScreenColumn(title = "GabClean") {
        StatusCard(
            enabled = settings.enabled,
            onToggle = { scope.launch { gabClean.setEnabled(it) } },
        )

        GroupTitle("Bloqueios desde a instalação")
        StatsBlock(stats)
        if (stats.topHosts.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Mais bloqueados",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            stats.topHosts.forEach { item ->
                StatLine(label = "${item.host} · ${categoryLabel(item.category)}", value = item.count)
            }
        }
        if (stats.requests > 0 || stats.youtube > 0) {
            TextButton(onClick = { confirmReset = true }) { Text("Zerar estatísticas") }
        }

        GroupTitle("Nível de bloqueio")
        RadioRow(
            label = "Padrão",
            selected = settings.level == BlockLevel.STANDARD,
            onSelect = { scope.launch { gabClean.setLevel(BlockLevel.STANDARD) } },
        )
        Note("Redes de anúncio e rastreadores conhecidos. Raramente atrapalha os sites.")
        RadioRow(
            label = "Rigoroso",
            selected = settings.level == BlockLevel.STRICT,
            onSelect = { scope.launch { gabClean.setLevel(BlockLevel.STRICT) } },
        )
        Note(
            "Também bloqueia Google Tag Manager, o SDK do Facebook e o SDK de anúncios em vídeo. " +
                "Pode atrapalhar \"Entrar com Facebook\" e alguns players de sites de notícia.",
        )

        GroupTitle("YouTube")
        SwitchRow(
            label = "Remover e pular anúncios do YouTube",
            checked = settings.youtube,
            enabled = settings.enabled,
            onChange = { scope.launch { gabClean.setYoutube(it) } },
        )
        Note(
            if (youtubeFull) {
                "Os anúncios são retirados antes do vídeo começar. Se algum passar, ele é silenciado e pulado."
            } else {
                "O WebView deste aparelho não permite agir antes da página carregar. " +
                    "Os anúncios que tocarem serão silenciados e pulados. Atualizar o \"Android System WebView\" " +
                    "na Play Store pode liberar o modo completo."
            },
        )
        Note(
            "O YouTube muda o site com frequência para driblar bloqueadores. Se os anúncios voltarem, " +
                "o GabClean precisará de uma atualização.",
        )

        GroupTitle("Lista ampliada")
        ExtendedListSection(
            settings = settings,
            updating = updatingList,
            message = listMessage,
            onUpdate = {
                updatingList = true
                listMessage = null
                scope.launch {
                    listMessage = when (val result = gabClean.updateExtendedList()) {
                        is ListUpdateResult.Success ->
                            "Lista atualizada: ${formatNumber(result.rules.toLong())} domínios."
                        is ListUpdateResult.Failure -> "Não foi possível atualizar: ${result.reason}."
                    }
                    updatingList = false
                }
            },
            onToggle = { scope.launch { gabClean.setExtendedEnabled(it) } },
            onRemove = {
                listMessage = null
                scope.launch { gabClean.removeExtendedList() }
            },
        )

        GroupTitle("Sites sem bloqueio")
        if (settings.exceptions.isEmpty()) {
            Note("Nenhum. Para desligar o bloqueio em um site, toque no escudo ao lado do endereço.")
        } else {
            settings.exceptions.sorted().forEach { host ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = host,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    TextButton(onClick = { scope.launch { gabClean.removeException(host) } }) {
                        Text("Bloquear de novo")
                    }
                }
            }
        }

        GroupTitle("Como funciona")
        Note(
            "O GabClean impede que o navegador baixe arquivos de domínios de anúncio e rastreamento, " +
                "e esconde os espaços vazios que sobram. Os números acima são contados no aparelho, " +
                "a cada bloqueio real, e não são enviados a ninguém. Nenhum bloqueador pega tudo: " +
                "anúncios servidos pelo próprio site, como posts patrocinados, podem continuar aparecendo.",
        )
    }
}

@Composable
private fun StatusCard(enabled: Boolean, onToggle: (Boolean) -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = if (enabled) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = GabIcons.Shield,
                contentDescription = null,
                tint = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(36.dp),
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = if (enabled) "Bloqueio ativo" else "Bloqueio desligado",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (enabled) {
                        MaterialTheme.colorScheme.onPrimaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
                Text(
                    text = if (enabled) "Anúncios e rastreadores estão sendo bloqueados." else "Os sites carregam tudo.",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (enabled) {
                        MaterialTheme.colorScheme.onPrimaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }
            Switch(checked = enabled, onCheckedChange = onToggle)
        }
    }
}

@Composable
private fun StatsBlock(stats: GabCleanStats) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                text = formatNumber(stats.requests),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
            Text(
                text = "requisições bloqueadas",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(8.dp))
            StatLine(label = "De anúncios", value = stats.ads)
            StatLine(label = "De rastreadores", value = stats.trackers)
            StatLine(label = "Pela lista ampliada", value = stats.extended)
            StatLine(label = "Anúncios do YouTube removidos ou pulados", value = stats.youtube)
        }
    }
}

@Composable
private fun StatLine(label: String, value: Long) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.width(12.dp))
        Text(
            text = formatNumber(value),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground,
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, enabled = enabled, onCheckedChange = onChange)
    }
}

@Composable
private fun ExtendedListSection(
    settings: GabCleanSettings,
    updating: Boolean,
    message: String?,
    onUpdate: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onRemove: () -> Unit,
) {
    val downloaded = settings.extendedRuleCount > 0
    Note(
        "Lista pública mantida pela AdGuard (${GabCleanRepository.EXTENDED_LIST_NAME}), com dezenas de milhares " +
            "de domínios de anúncio e rastreamento. A primeira vez é baixada só quando você pedir, direto do site da " +
            "AdGuard; depois, o app busca a versão nova sozinho uma vez por semana.",
    )
    Spacer(Modifier.height(8.dp))
    if (downloaded) {
        val date = DateFormat.getDateInstance(DateFormat.SHORT).format(Date(settings.extendedUpdatedAt))
        Text(
            text = "${formatNumber(settings.extendedRuleCount.toLong())} domínios · atualizada em $date",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        SwitchRow(
            label = "Usar lista ampliada",
            checked = settings.extendedEnabled,
            enabled = settings.enabled,
            onChange = onToggle,
        )
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Button(onClick = onUpdate, enabled = !updating) {
            Text(if (downloaded) "Atualizar lista" else "Baixar lista")
        }
        if (downloaded) {
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = onRemove, enabled = !updating) { Text("Remover") }
        }
        if (updating) {
            Spacer(Modifier.width(12.dp))
            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
        }
    }
    if (message != null) {
        Spacer(Modifier.height(6.dp))
        Note(message)
    }
}

private fun categoryLabel(category: BlockCategory): String = when (category) {
    BlockCategory.AD -> "anúncio"
    BlockCategory.TRACKER -> "rastreador"
    BlockCategory.EXTENDED_LIST -> "lista ampliada"
    BlockCategory.YOUTUBE_AD -> "YouTube"
}

private fun formatNumber(value: Long): String = NumberFormat.getIntegerInstance().format(value)
