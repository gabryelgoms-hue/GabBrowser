package com.gabbrowser.android.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.data.Bookmark
import com.gabbrowser.core.data.BookmarkFolder
import com.gabbrowser.core.data.SiteRepository
import kotlinx.coroutines.launch

/** Filtro da lista: todos, sem pasta, ou uma pasta. */
private sealed interface FolderFilter {
    data object All : FolderFilter

    data object NoFolder : FolderFilter

    data class Folder(val id: Long) : FolderFilter
}

@Composable
fun BookmarksScreen(sites: SiteRepository, onOpen: (String) -> Unit) {
    val bookmarks by sites.bookmarkEntries.collectAsStateWithLifecycle(initialValue = emptyList())
    val folders by sites.folders.collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()

    var filter by remember { mutableStateOf<FolderFilter>(FolderFilter.All) }
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Bookmark?>(null) }
    var folderDialog by remember { mutableStateOf<BookmarkFolder?>(null) }
    var creatingFolder by remember { mutableStateOf(false) }

    val visible = bookmarks
        .filter {
            when (val f = filter) {
                FolderFilter.All -> true
                FolderFilter.NoFolder -> it.folderId == null
                is FolderFilter.Folder -> it.folderId == f.id
            }
        }
        .filter {
            query.isBlank() ||
                it.title.contains(query.trim(), ignoreCase = true) ||
                it.url.contains(query.trim(), ignoreCase = true)
        }

    editing?.let { bookmark ->
        EditBookmarkDialog(
            bookmark = bookmark,
            folders = folders,
            onSave = { title, folderId ->
                editing = null
                scope.launch { sites.updateBookmark(bookmark.id, title.ifBlank { bookmark.title }, folderId) }
            },
            onDismiss = { editing = null },
        )
    }

    if (creatingFolder) {
        NameDialog(
            title = "Nova pasta",
            initial = "",
            onSave = { name ->
                creatingFolder = false
                if (name.isNotBlank()) scope.launch { sites.createFolder(name) }
            },
            onDismiss = { creatingFolder = false },
        )
    }

    folderDialog?.let { folder ->
        FolderOptionsDialog(
            folder = folder,
            onRename = { name ->
                folderDialog = null
                if (name.isNotBlank()) scope.launch { sites.renameFolder(folder.id, name) }
            },
            onDelete = {
                folderDialog = null
                filter = FolderFilter.All
                scope.launch { sites.deleteFolder(folder.id) }
            },
            onDismiss = { folderDialog = null },
        )
    }

    ScreenColumn(title = "Favoritos") {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Pesquisar nos favoritos") },
        )
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FolderChip("Todos", filter == FolderFilter.All, onClick = { filter = FolderFilter.All })
            FolderChip("Sem pasta", filter == FolderFilter.NoFolder, onClick = { filter = FolderFilter.NoFolder })
            folders.forEach { folder ->
                val selected = filter == FolderFilter.Folder(folder.id)
                FolderChip(
                    label = folder.name,
                    selected = selected,
                    onClick = {
                        if (selected) folderDialog = folder else filter = FolderFilter.Folder(folder.id)
                    },
                )
            }
            OutlinedButton(onClick = { creatingFolder = true }) { Text("+ Pasta") }
        }
        if (filter is FolderFilter.Folder) {
            Spacer(Modifier.height(4.dp))
            Note("Toque de novo na pasta selecionada para renomear ou excluir.")
        }
        Spacer(Modifier.height(8.dp))

        if (visible.isEmpty()) {
            Note(
                if (bookmarks.isEmpty()) {
                    "Nenhum favorito ainda. Abra um site e use o menu ⋮ para adicionar."
                } else {
                    "Nenhum favorito aqui."
                },
            )
        }
        visible.forEach { bookmark ->
            BookmarkRow(
                bookmark = bookmark,
                folderName = folders.firstOrNull { it.id == bookmark.folderId }?.name,
                onOpen = { onOpen(bookmark.url) },
                onEdit = { editing = bookmark },
                onDelete = { scope.launch { sites.deleteBookmark(bookmark.id) } },
            )
        }
    }
}

@Composable
private fun FolderChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun BookmarkRow(
    bookmark: Bookmark,
    folderName: String?,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onOpen)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = bookmark.title.ifBlank { displayHost(bookmark.url) },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = listOfNotNull(displayHost(bookmark.url), folderName).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        IconButton(onClick = { menuOpen = true }) {
            Icon(Icons.Filled.MoreVert, contentDescription = "Opções do favorito")
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(
                text = { Text("Editar") },
                onClick = {
                    menuOpen = false
                    onEdit()
                },
            )
            DropdownMenuItem(
                text = { Text("Excluir") },
                onClick = {
                    menuOpen = false
                    onDelete()
                },
            )
        }
    }
}

@Composable
private fun EditBookmarkDialog(
    bookmark: Bookmark,
    folders: List<BookmarkFolder>,
    onSave: (String, Long?) -> Unit,
    onDismiss: () -> Unit,
) {
    var title by remember { mutableStateOf(bookmark.title) }
    var folderId by remember { mutableStateOf(bookmark.folderId) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar favorito") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Nome") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
                Text("Pasta", style = MaterialTheme.typography.labelLarge)
                FolderOption("Sem pasta", folderId == null) { folderId = null }
                folders.forEach { folder ->
                    FolderOption(folder.name, folderId == folder.id) { folderId = folder.id }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(title, folderId) }) { Text("Salvar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
private fun FolderOption(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onSelect)
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
internal fun NameDialog(
    title: String,
    initial: String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(40) },
                singleLine = true,
                label = { Text("Nome") },
            )
        },
        confirmButton = { TextButton(onClick = { onSave(name) }) { Text("Salvar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
private fun FolderOptionsDialog(
    folder: BookmarkFolder,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(folder.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pasta") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    singleLine = true,
                    label = { Text("Nome") },
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Excluir a pasta não apaga os favoritos: eles ficam sem pasta.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = { TextButton(onClick = { onRename(name) }) { Text("Salvar") } },
        dismissButton = {
            Row {
                TextButton(onClick = onDelete) { Text("Excluir pasta", color = MaterialTheme.colorScheme.error) }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        },
    )
}
