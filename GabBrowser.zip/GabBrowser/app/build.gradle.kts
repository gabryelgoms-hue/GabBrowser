import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.gabbrowser.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gabbrowser.android"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "1.0.0"
    }

    // Assinatura de release: a chave vem de variáveis de ambiente (segredos do GitHub Actions),
    // nunca do repositório. Sem as variáveis, só o APK de depuração é gerado.
    val releaseKeystore = System.getenv("GAB_KEYSTORE_FILE")
    signingConfigs {
        if (releaseKeystore != null) {
            create("release") {
                storeFile = file(releaseKeystore)
                storePassword = System.getenv("GAB_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("GAB_KEY_ALIAS") ?: "gabbrowser"
                keyPassword = System.getenv("GAB_KEY_PASSWORD") ?: System.getenv("GAB_KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.findByName("release")
            // Sem ofuscação/encolhimento nesta versão: não há como testar o resultado do R8 antes da entrega,
            // e ofuscar não acrescenta segurança real a um app de código aberto.
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation(project(":core:common"))
    implementation(project(":core:designsystem"))
    implementation(project(":core:data"))
    implementation(project(":core:engine"))

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.core)

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.kotlinx.coroutines.android)

    // Senhas: digital, rosto ou PIN do aparelho
    implementation(libs.androidx.biometric)
    implementation(libs.androidx.fragment.ktx)

    // GabScan: câmera e leitura de QR Code (sem serviços do Google)
    implementation(libs.androidx.camera.camera2)
    implementation(libs.androidx.camera.lifecycle)
    implementation(libs.androidx.camera.view)
    implementation(libs.zxing.core)
}
