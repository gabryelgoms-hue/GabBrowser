package com.gabbrowser.core.designsystem

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/** Ícones próprios do GabBrowser que não existem no pacote básico do Material. A cor vem do tint do Icon. */
object GabIcons {

    /** Escudo do GabClean/GabShield. */
    val Shield: ImageVector by lazy {
        icon("GabShield") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f)
                lineTo(4f, 5f)
                verticalLineTo(11f)
                curveTo(4f, 16.5f, 7.4f, 21.3f, 12f, 22f)
                curveTo(16.6f, 21.3f, 20f, 16.5f, 20f, 11f)
                verticalLineTo(5f)
                close()
            }
        }
    }

    /** Máscara das abas anônimas. */
    val Mask: ImageVector by lazy {
        icon("GabMask") {
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                // Contorno da máscara
                moveTo(2f, 9f)
                curveTo(2f, 7f, 3.6f, 6f, 6f, 6f)
                lineTo(18f, 6f)
                curveTo(20.4f, 6f, 22f, 7f, 22f, 9f)
                lineTo(22f, 12f)
                curveTo(22f, 15f, 20f, 17f, 17f, 17f)
                curveTo(15f, 17f, 13.5f, 15.6f, 12f, 14f)
                curveTo(10.5f, 15.6f, 9f, 17f, 7f, 17f)
                curveTo(4f, 17f, 2f, 15f, 2f, 12f)
                close()
                // Olhos (vazados)
                moveTo(5f, 11f)
                arcTo(2f, 1.5f, 0f, isMoreThanHalf = true, isPositiveArc = false, x1 = 9f, y1 = 11f)
                arcTo(2f, 1.5f, 0f, isMoreThanHalf = true, isPositiveArc = false, x1 = 5f, y1 = 11f)
                close()
                moveTo(15f, 11f)
                arcTo(2f, 1.5f, 0f, isMoreThanHalf = true, isPositiveArc = false, x1 = 19f, y1 = 11f)
                arcTo(2f, 1.5f, 0f, isMoreThanHalf = true, isPositiveArc = false, x1 = 15f, y1 = 11f)
                close()
            }
        }
    }

    /** Seta para baixo sobre a bandeja, do GabDownload. */
    val Download: ImageVector by lazy {
        icon("GabDownload") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(12f, 4f)
                verticalLineTo(15f)
                moveTo(7f, 10f)
                lineTo(12f, 15f)
                lineTo(17f, 10f)
                moveTo(5f, 19.5f)
                horizontalLineTo(19f)
            }
        }
    }

    /** Brilho de quatro pontas do GabAI. */
    val Spark: ImageVector by lazy {
        icon("GabSpark") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f)
                curveTo(12.6f, 7.4f, 16.6f, 11.4f, 22f, 12f)
                curveTo(16.6f, 12.6f, 12.6f, 16.6f, 12f, 22f)
                curveTo(11.4f, 16.6f, 7.4f, 12.6f, 2f, 12f)
                curveTo(7.4f, 11.4f, 11.4f, 7.4f, 12f, 2f)
                close()
            }
            path(fill = SolidColor(Color.Black)) {
                moveTo(19f, 2f)
                curveTo(19.2f, 3.6f, 20.4f, 4.8f, 22f, 5f)
                curveTo(20.4f, 5.2f, 19.2f, 6.4f, 19f, 8f)
                curveTo(18.8f, 6.4f, 17.6f, 5.2f, 16f, 5f)
                curveTo(17.6f, 4.8f, 18.8f, 3.6f, 19f, 2f)
                close()
            }
        }
    }

    /** Vassoura/brilho do GabOne: limpeza com um toque. */
    val Sweep: ImageVector by lazy {
        icon("GabOne") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                // Cabo
                moveTo(19f, 3f)
                lineTo(12f, 10f)
                // Cerdas
                moveTo(9f, 11f)
                lineTo(13f, 15f)
                moveTo(9f, 11f)
                curveTo(6f, 12f, 4f, 15f, 3f, 21f)
                curveTo(9f, 20f, 12f, 18f, 13f, 15f)
                moveTo(7f, 17f)
                lineTo(5.5f, 18.5f)
            }
        }
    }

    /** Folha do GabSaver: economia de dados. */
    val Leaf: ImageVector by lazy {
        icon("GabSaver") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(5f, 19f)
                curveTo(5f, 10f, 10f, 4f, 20f, 4f)
                curveTo(20f, 14f, 14f, 19f, 5f, 19f)
                close()
                moveTo(5f, 19f)
                lineTo(13f, 11f)
            }
        }
    }

    /** Pilha de cartões do GabFlow: grupos de abas. */
    val Layers: ImageVector by lazy {
        icon("GabFlow") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(12f, 3f)
                lineTo(21f, 8f)
                lineTo(12f, 13f)
                lineTo(3f, 8f)
                close()
                moveTo(3f, 12.5f)
                lineTo(12f, 17.5f)
                lineTo(21f, 12.5f)
                moveTo(3f, 16.5f)
                lineTo(12f, 21.5f)
                lineTo(21f, 16.5f)
            }
        }
    }

    /** Livro aberto do GabReader. */
    val Book: ImageVector by lazy {
        icon("GabReader") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(12f, 6f)
                curveTo(10f, 4.5f, 6.5f, 4f, 3f, 4.5f)
                verticalLineTo(18.5f)
                curveTo(6.5f, 18f, 10f, 18.5f, 12f, 20f)
                curveTo(14f, 18.5f, 17.5f, 18f, 21f, 18.5f)
                verticalLineTo(4.5f)
                curveTo(17.5f, 4f, 14f, 4.5f, 12f, 6f)
                close()
                moveTo(12f, 6f)
                verticalLineTo(20f)
            }
        }
    }

    /** QR Code do GabScan. */
    val Qr: ImageVector by lazy {
        icon("GabScan") {
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                // Três quadrados de canto, vazados
                for ((x, y) in listOf(3f to 3f, 14f to 3f, 3f to 14f)) {
                    moveTo(x, y)
                    horizontalLineTo(x + 7f)
                    verticalLineTo(y + 7f)
                    horizontalLineTo(x)
                    close()
                    moveTo(x + 2f, y + 2f)
                    horizontalLineTo(x + 5f)
                    verticalLineTo(y + 5f)
                    horizontalLineTo(x + 2f)
                    close()
                }
                // Módulos
                for ((x, y) in listOf(14f to 14f, 18f to 14f, 16f to 16f, 14f to 18f, 18f to 18f)) {
                    moveTo(x, y)
                    horizontalLineTo(x + 2.5f)
                    verticalLineTo(y + 2.5f)
                    horizontalLineTo(x)
                    close()
                }
            }
        }
    }

    private fun icon(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply(block).build()
}
