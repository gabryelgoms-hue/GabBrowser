package com.gabbrowser.core.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Paleta oficial do GabBrowser. */
object GabColors {
    val Blue = Color(0xFF1769E8)
    val Navy = Color(0xFF101827)
    val White = Color(0xFFFFFFFF)
    val Gray = Color(0xFF8994A5)

    val BlueLight = Color(0xFF5C9BFF)
    val Danger = Color(0xFFD92D20)
    val DangerLight = Color(0xFFFF7A6E)
}

private val LightColors = lightColorScheme(
    primary = GabColors.Blue,
    onPrimary = GabColors.White,
    primaryContainer = Color(0xFFDCE8FD),
    onPrimaryContainer = GabColors.Navy,
    secondary = GabColors.Blue,
    onSecondary = GabColors.White,
    secondaryContainer = Color(0xFFDCE8FD),
    onSecondaryContainer = GabColors.Navy,
    background = Color(0xFFF6F8FC),
    onBackground = GabColors.Navy,
    surface = GabColors.White,
    onSurface = GabColors.Navy,
    surfaceVariant = Color(0xFFEDF1F7),
    onSurfaceVariant = Color(0xFF566173),
    surfaceContainerLowest = GabColors.White,
    surfaceContainerLow = Color(0xFFF6F8FC),
    surfaceContainer = GabColors.White,
    surfaceContainerHigh = Color(0xFFEDF1F7),
    surfaceContainerHighest = Color(0xFFE4E9F1),
    outline = GabColors.Gray,
    outlineVariant = Color(0xFFD5DBE5),
    error = GabColors.Danger,
    onError = GabColors.White,
)

private val DarkColors = darkColorScheme(
    primary = GabColors.BlueLight,
    onPrimary = GabColors.Navy,
    primaryContainer = Color(0xFF173A7A),
    onPrimaryContainer = GabColors.White,
    secondary = GabColors.BlueLight,
    onSecondary = GabColors.Navy,
    secondaryContainer = Color(0xFF173A7A),
    onSecondaryContainer = GabColors.White,
    background = GabColors.Navy,
    onBackground = GabColors.White,
    surface = Color(0xFF162033),
    onSurface = GabColors.White,
    surfaceVariant = Color(0xFF1F2B42),
    onSurfaceVariant = Color(0xFFAEB8C8),
    surfaceContainerLowest = Color(0xFF0C121E),
    surfaceContainerLow = GabColors.Navy,
    surfaceContainer = Color(0xFF162033),
    surfaceContainerHigh = Color(0xFF1F2B42),
    surfaceContainerHighest = Color(0xFF283650),
    outline = GabColors.Gray,
    outlineVariant = Color(0xFF2C3950),
    error = GabColors.DangerLight,
    onError = GabColors.Navy,
)

@Composable
fun GabTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content,
    )
}
