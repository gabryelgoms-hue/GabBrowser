package com.gabbrowser.core.designsystem

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Símbolo do GabBrowser: G em anel aberto com o B integrado no centro.
 * Desenhado em vetor (grade de 52 unidades), então escala sem perder nitidez.
 */
@Composable
fun GabLogo(
    modifier: Modifier = Modifier,
    logoSize: Dp = 72.dp,
    ringColor: Color = MaterialTheme.colorScheme.primary,
    letterColor: Color = MaterialTheme.colorScheme.onBackground,
) {
    Canvas(
        modifier = modifier
            .size(logoSize)
            .semantics { contentDescription = "Logotipo GabBrowser" },
    ) {
        val u = this.size.minDimension / 52f
        val radius = 22f * u
        val center = Offset(26f * u, 26f * u)

        // Anel do G: começa no alto à direita e dá a volta até o meio da direita.
        drawArc(
            color = ringColor,
            startAngle = -40f,
            sweepAngle = -320f,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2f, radius * 2f),
            style = Stroke(width = 8f * u),
        )
        // Barra horizontal do G.
        drawLine(
            color = ringColor,
            start = Offset(52f * u, center.y),
            end = Offset(38f * u, center.y),
            strokeWidth = 8f * u,
        )

        // B geométrico no centro.
        val b = Path().apply {
            moveTo(19f * u, 16f * u)
            lineTo(26f * u, 16f * u)
            arcTo(Rect(21f * u, 16f * u, 31f * u, 26f * u), -90f, 180f, false)
            lineTo(19f * u, 26f * u)
            moveTo(26f * u, 26f * u)
            lineTo(27f * u, 26f * u)
            arcTo(Rect(22f * u, 26f * u, 32f * u, 36f * u), -90f, 180f, false)
            lineTo(19f * u, 36f * u)
            moveTo(19f * u, 16f * u)
            lineTo(19f * u, 36f * u)
        }
        drawPath(
            path = b,
            color = letterColor,
            style = Stroke(width = 4.5f * u, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }
}

/** Nome "GabBrowser" em duas cores, como na marca. */
@Composable
fun GabWordmark(
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 30.sp,
) {
    val gabColor = MaterialTheme.colorScheme.onBackground
    val browserColor = MaterialTheme.colorScheme.primary
    Text(
        text = buildAnnotatedString {
            withStyle(SpanStyle(color = gabColor)) { append("Gab") }
            withStyle(SpanStyle(color = browserColor)) { append("Browser") }
        },
        modifier = modifier,
        fontSize = fontSize,
        fontWeight = FontWeight.Bold,
    )
}
