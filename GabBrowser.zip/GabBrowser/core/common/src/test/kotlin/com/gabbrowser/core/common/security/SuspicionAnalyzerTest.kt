package com.gabbrowser.core.common.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.IDN

class SuspicionAnalyzerTest {

    private fun level(host: String) = SuspicionAnalyzer.analyze(host).level

    @Test
    fun sitesOficiaisSaoSeguros() {
        listOf(
            "www.google.com", "accounts.google.com", "nubank.com.br", "app.nubank.com.br", "www.gov.br",
            "servicos.receita.fazenda.gov.br", "www.service.gov.uk", "ge.globo.com", "receitas.globo.com",
            "www.amazon.com.br", "s3.amazonaws.com", "lh3.googleusercontent.com", "m.youtube.com",
            "www.caixa.gov.br", "wikipedia.org", "pt.wikipedia.org", "192.168.0.1", "localhost",
        ).forEach { assertEquals(it, RiskLevel.NONE, level(it)) }
    }

    @Test
    fun marcaComPalavraDeLoginEhAltoRisco() {
        assertEquals(RiskLevel.HIGH, level("nubank-seguranca.com"))
        assertEquals(RiskLevel.HIGH, level("gov-br-consulta.com"))
        assertEquals(RiskLevel.HIGH, level("itau-desbloqueio.online"))
    }

    @Test
    fun marcaNoSubdominioDeOutroSite() {
        assertEquals(RiskLevel.HIGH, level("paypal.com.login-verificar.xyz"))
        assertEquals(RiskLevel.HIGH, level("www.netflix.com.conta-atualizada.net"))
    }

    @Test
    fun trocaDeLetrasPorNumeros() {
        assertEquals(RiskLevel.HIGH, level("g00gle.com"))
        assertEquals(RiskLevel.HIGH, level("paypa1.com"))
        assertEquals(RiskLevel.HIGH, level("arnazon.com"))
    }

    @Test
    fun alfabetoMisturadoOuImitado() {
        // "а" cirílico no lugar do "a" latino.
        assertEquals(RiskLevel.HIGH, level(IDN.toASCII("аpple.com", IDN.ALLOW_UNASSIGNED)))
        // Tudo em cirílico, mas com a mesma aparência de "apple".
        assertEquals(RiskLevel.HIGH, level(IDN.toASCII("аррӏе.com", IDN.ALLOW_UNASSIGNED)))
        // O mesmo endereço chegando em Unicode, sem punycode.
        assertEquals(RiskLevel.HIGH, level("аpple.com"))
        assertEquals(RiskLevel.HIGH, level("раураl.com"))
        // Domínio internacional legítimo, todo em um alfabeto e sem imitar marca.
        assertEquals(RiskLevel.NONE, level(IDN.toASCII("пример.рф", IDN.ALLOW_UNASSIGNED)))
    }

    @Test
    fun sinaisFracos() {
        assertEquals(RiskLevel.LOW, level("8.8.8.8"))
        assertEquals(RiskLevel.LOW, level("promocoes.xyz"))
        assertEquals(RiskLevel.LOW, level("caixa-ferramentas.com"))
    }

    @Test
    fun umaLetraDeDiferenca() {
        assertTrue(SuspicionAnalyzer.isOneEditAway("nubamk", "nubank"))
        assertTrue(SuspicionAnalyzer.isOneEditAway("gogle", "google"))
        assertTrue(SuspicionAnalyzer.isOneEditAway("googel", "google"))
        assertFalse(SuspicionAnalyzer.isOneEditAway("google", "google"))
        assertFalse(SuspicionAnalyzer.isOneEditAway("goggles", "google"))
        assertEquals(RiskLevel.HIGH, level("nubamk-app.com"))
    }

    @Test
    fun motivosSaoInformados() {
        val report = SuspicionAnalyzer.analyze("nubank-seguranca.com")
        assertTrue(report.reasons.isNotEmpty())
    }
}
