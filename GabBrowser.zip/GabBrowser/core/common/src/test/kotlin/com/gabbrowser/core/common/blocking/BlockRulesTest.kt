package com.gabbrowser.core.common.blocking

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BlockRulesTest {

    private val on = BlockerSnapshot()

    private fun decide(
        url: String,
        top: String? = "noticias.com.br",
        snapshot: BlockerSnapshot = on,
    ): BlockCategory? {
        val host = url.substringAfter("://").substringBefore('/').substringBefore('?')
        return BlockRules.decide(snapshot, url, host, top)
    }

    @Test
    fun anunciosConhecidosSaoBloqueados() {
        assertEquals(BlockCategory.AD, decide("https://securepubads.g.doubleclick.net/tag/js/gpt.js"))
        assertEquals(BlockCategory.AD, decide("https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"))
        assertEquals(BlockCategory.AD, decide("https://cdn.taboola.com/libtrc/site/loader.js"))
    }

    @Test
    fun rastreadoresConhecidosSaoBloqueados() {
        assertEquals(BlockCategory.TRACKER, decide("https://www.google-analytics.com/analytics.js"))
        assertEquals(BlockCategory.TRACKER, decide("https://static.hotjar.com/c/hotjar.js"))
        assertEquals(BlockCategory.TRACKER, decide("https://bat.bing.com/bat.js"))
    }

    @Test
    fun dominiosComunsPassam() {
        assertNull(decide("https://fonts.googleapis.com/css2?family=Inter"))
        assertNull(decide("https://cdn.jsdelivr.net/npm/x.js"))
        assertNull(decide("https://www.bing.com/search?q=x"))
        assertNull(decide("https://i.ytimg.com/vi/abc/hq.jpg", top = "m.youtube.com"))
    }

    @Test
    fun sufixoNaoCasaPorPedacoDeNome() {
        // "notdoubleclick.net" não é subdomínio de "doubleclick.net".
        assertNull(decide("https://notdoubleclick.net/x.js"))
    }

    @Test
    fun mesmoSiteNaoEhBloqueadoPelasListas() {
        assertNull(decide("https://analytics.google.com/x.js", top = "analytics.google.com"))
        assertNull(decide("https://ads.globo.com/x.js", top = "ge.globo.com"))
    }

    @Test
    fun rigorosoIncluiListaExtra() {
        val gtm = "https://www.googletagmanager.com/gtm.js?id=GTM-X"
        assertNull(decide(gtm))
        assertEquals(BlockCategory.TRACKER, decide(gtm, snapshot = on.copy(level = BlockLevel.STRICT)))
    }

    @Test
    fun desligadoOuExcecaoNaoBloqueiam() {
        val ad = "https://securepubads.g.doubleclick.net/tag/js/gpt.js"
        assertNull(decide(ad, snapshot = on.copy(enabled = false)))
        val withException = on.copy(exceptions = setOf("noticias.com.br"))
        assertNull(decide(ad, top = "www.noticias.com.br", snapshot = withException))
        assertEquals(BlockCategory.AD, decide(ad, top = "outro.com", snapshot = withException))
    }

    @Test
    fun caminhosDeAnuncioDoYoutube() {
        val top = "m.youtube.com"
        assertEquals(BlockCategory.AD, decide("https://m.youtube.com/pagead/viewthroughconversion/1", top))
        assertEquals(BlockCategory.AD, decide("https://www.youtube.com/api/stats/ads?ver=2", top))
        assertEquals(BlockCategory.AD, decide("https://www.youtube.com/youtubei/v1/player/ad_break?k=1", top))
        assertNull(decide("https://m.youtube.com/youtubei/v1/player?key=1", top))
        assertNull(decide("https://www.youtube.com/api/stats/qoe?x=1", top))
        assertNull(
            decide("https://www.youtube.com/api/stats/ads", top, snapshot = on.copy(youtube = false)),
        )
    }

    @Test
    fun listaAmpliadaComExcecoes() {
        val list = FilterListParser.parse("||rastreio-ampliado.com^\n@@||ok.rastreio-ampliado.com^\n")
        val snapshot = on.copy(extended = list)
        assertEquals(BlockCategory.EXTENDED_LIST, decide("https://x.rastreio-ampliado.com/a.js", snapshot = snapshot))
        assertNull(decide("https://ok.rastreio-ampliado.com/a.js", snapshot = snapshot))
        assertNull(decide("https://x.rastreio-ampliado.com/a.js"))
    }

    @Test
    fun siteDoHost() {
        assertEquals("globo.com", BlockRules.siteOf("ge.globo.com"))
        assertEquals("uol.com.br", BlockRules.siteOf("www.uol.com.br"))
        assertEquals("bbc.co.uk", BlockRules.siteOf("news.bbc.co.uk"))
        assertEquals("exemplo.com", BlockRules.siteOf("exemplo.com"))
        assertTrue(BlockRules.isSameSite("a.uol.com.br", "b.uol.com.br"))
        assertFalse(BlockRules.isSameSite("uol.com.br", "globo.com.br"))
        // IP não pode ser reduzido aos dois últimos números.
        assertEquals("1.2.3.4", BlockRules.siteOf("1.2.3.4"))
        assertFalse(BlockRules.isSameSite("5.6.3.4", "1.2.3.4"))
    }

    @Test
    fun caminhoDaUrl() {
        assertEquals("/a/b", BlockRules.pathOf("https://x.com/a/b?c=1#d"))
        assertEquals("/", BlockRules.pathOf("https://x.com"))
        assertEquals("/p", BlockRules.pathOf("https://x.com/p#frag"))
    }
}
