package com.gabbrowser.core.common.blocking

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FilterListParserTest {

    @Test
    fun leFormatoAdblockDeDominios() {
        val text = """
            ! Title: lista de teste
            [Adblock Plus 2.0]
            ||ads.exemplo.com^
            ||Tracker.Exemplo.NET^${'$'}important
            @@||cdn.exemplo.com^
            ||com-modificador.com^${'$'}third-party
            ||com-caminho.com/banner^
            ||*.curinga.com^
            /regex/
            ##.banner
        """.trimIndent()
        val list = FilterListParser.parse(text)
        assertEquals(setOf("ads.exemplo.com", "tracker.exemplo.net"), list.blocked)
        assertEquals(setOf("cdn.exemplo.com"), list.allowed)
    }

    @Test
    fun leFormatoHosts() {
        val text = """
            # comentário
            127.0.0.1 localhost
            0.0.0.0 ads.hosts.com
            0.0.0.0   tracker.hosts.com  # comentário no fim
            192.168.0.1 roteador.local
        """.trimIndent()
        assertEquals(setOf("ads.hosts.com", "tracker.hosts.com"), FilterListParser.parse(text).blocked)
    }

    @Test
    fun excecaoVenceBloqueio() {
        val list = FilterListParser.parse("||exemplo.com^\n@@||bom.exemplo.com^")
        assertTrue(list.blocks("ruim.exemplo.com"))
        assertFalse(list.blocks("bom.exemplo.com"))
        assertFalse(list.blocks("api.bom.exemplo.com"))
    }

    @Test
    fun gravarELerDeNovoDaOMesmoResultado() {
        val original = FilterListParser.parse("||a.com^\n||b.net^\n@@||ok.a.com^")
        val reloaded = FilterListParser.parse(original.toFilterText())
        assertEquals(original.blocked, reloaded.blocked)
        assertEquals(original.allowed, reloaded.allowed)
    }

    @Test
    fun scriptsNaoUsamCifrao() {
        // "$" dentro de string Kotlin multilinha vira template; os scripts não devem conter nenhum.
        assertFalse(ContentScripts.YOUTUBE.contains('$'))
        assertFalse(ContentScripts.COSMETIC.contains('$'))
        assertTrue(ContentScripts.YOUTUBE.contains("ytInitialPlayerResponse"))
    }
}
