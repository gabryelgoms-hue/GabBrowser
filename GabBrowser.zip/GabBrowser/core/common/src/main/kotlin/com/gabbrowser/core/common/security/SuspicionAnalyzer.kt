package com.gabbrowser.core.common.security

import com.gabbrowser.core.common.blocking.BlockRules
import java.net.IDN

enum class RiskLevel { NONE, LOW, HIGH }

data class SuspicionReport(
    val level: RiskLevel,
    val reasons: List<String>,
) {
    companion object {
        val SAFE = SuspicionReport(RiskLevel.NONE, emptyList())
    }
}

/**
 * Análise local do endereço, feita antes de abrir a página, sem enviar nada para fora.
 * Complementa a Navegação Segura do WebView (lista de sites maliciosos conhecidos), que só pega
 * sites já denunciados: aqui o alvo são golpes novos que imitam marcas conhecidas.
 *
 * É uma heurística: pode errar para os dois lados. Por isso o aviso sempre permite continuar.
 */
object SuspicionAnalyzer {

    /** Marca → domínios oficiais (o domínio e seus subdomínios). */
    private val BRANDS: Map<String, List<String>> = mapOf(
        "google" to listOf("google.com", "google.com.br"),
        "youtube" to listOf("youtube.com", "youtu.be"),
        "facebook" to listOf("facebook.com", "fb.com", "fb.me"),
        "instagram" to listOf("instagram.com"),
        "whatsapp" to listOf("whatsapp.com", "whatsapp.net", "wa.me"),
        "apple" to listOf("apple.com", "icloud.com"),
        "icloud" to listOf("icloud.com", "apple.com"),
        "microsoft" to listOf("microsoft.com", "live.com", "office.com", "microsoftonline.com", "msn.com"),
        "outlook" to listOf("outlook.com", "live.com", "office.com", "microsoft.com"),
        "hotmail" to listOf("hotmail.com", "live.com", "outlook.com"),
        "paypal" to listOf("paypal.com"),
        "netflix" to listOf("netflix.com"),
        "amazon" to listOf("amazon.com", "amazon.com.br"),
        "mercadolivre" to listOf("mercadolivre.com.br", "mercadolibre.com"),
        "mercadopago" to listOf("mercadopago.com.br", "mercadopago.com", "mercadolivre.com.br"),
        "nubank" to listOf("nubank.com.br"),
        "itau" to listOf("itau.com.br", "itau.com"),
        "bradesco" to listOf("bradesco.com.br"),
        "santander" to listOf("santander.com.br"),
        "caixa" to listOf("caixa.gov.br"),
        "bancodobrasil" to listOf("bb.com.br"),
        "picpay" to listOf("picpay.com"),
        "correios" to listOf("correios.com.br"),
        "receitafederal" to listOf("gov.br"),
        "serasa" to listOf("serasa.com.br", "serasaexperian.com.br"),
        "shopee" to listOf("shopee.com.br", "shopee.com"),
        "ifood" to listOf("ifood.com.br"),
        "magalu" to listOf("magazineluiza.com.br", "magalu.com"),
        "netshoes" to listOf("netshoes.com.br"),
        "tiktok" to listOf("tiktok.com"),
        "binance" to listOf("binance.com"),
        "gov" to emptyList(), // tratado à parte: qualquer .gov ou .gov.xx é oficial
    )

    private val SENSITIVE_WORDS = setOf(
        "login", "logon", "signin", "entrar", "acesso", "acessar", "conta", "senha", "seguranca", "seguro",
        "verificar", "verificacao", "verify", "validar", "atualizar", "atualizacao", "update", "account",
        "secure", "suporte", "support", "cliente", "bloqueio", "desbloqueio", "desbloquear", "pix", "token",
        "consulta", "regularizar", "cpf", "restituicao", "boleto", "fatura", "premio", "resgate", "beneficio",
        "app", "online", "oficial", "recuperar", "confirmar", "cadastro",
    )

    private val SUSPICIOUS_TLDS = setOf(
        "zip", "mov", "top", "xyz", "click", "country", "gq", "tk", "ml", "cf", "ga", "work", "rest",
        "cam", "icu", "buzz", "monster", "quest", "cyou", "sbs", "cfd",
    )

    /** Letras de outros alfabetos que parecem letras latinas. */
    private val CONFUSABLES: Map<Char, Char> = mapOf(
        'а' to 'a', 'е' to 'e', 'о' to 'o', 'р' to 'p', 'с' to 'c', 'у' to 'y', 'х' to 'x', 'і' to 'i',
        'ј' to 'j', 'ӏ' to 'l', 'ԁ' to 'd', 'ѕ' to 's', 'һ' to 'h', 'ԛ' to 'q', 'ԝ' to 'w', 'ь' to 'b',
        'ο' to 'o', 'α' to 'a', 'ν' to 'v', 'ρ' to 'p', 'ι' to 'i', 'κ' to 'k', 'τ' to 't', 'χ' to 'x',
        'υ' to 'u', 'ε' to 'e', 'ı' to 'i', 'ɡ' to 'g', 'ⅼ' to 'l',
    )

    private val DIGIT_SWAPS: Map<Char, Char> = mapOf('0' to 'o', '1' to 'l', '3' to 'e', '4' to 'a', '5' to 's', '7' to 't')

    private val IPV4 = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$")
    private val GOV_SUFFIX = Regex("(^|\\.)gov(\\.[a-z]{2})?$")

    fun analyze(rawHost: String): SuspicionReport {
        // Endereço que chega em Unicode ("раураl.com") é convertido para punycode, para a análise
        // de alfabetos valer igual para endereços digitados, colados ou vindos de links.
        val ascii = try {
            IDN.toASCII(rawHost.trim(), IDN.ALLOW_UNASSIGNED)
        } catch (e: IllegalArgumentException) {
            rawHost
        }
        val host = ascii.lowercase().trimEnd('.')
        if (host.isEmpty() || host == "localhost") return SuspicionReport.SAFE

        IPV4.find(host)?.let { match ->
            val octets = match.groupValues.drop(1).map { it.toInt() }
            return if (isPrivateIp(octets)) {
                SuspicionReport.SAFE
            } else {
                SuspicionReport(RiskLevel.LOW, listOf("O endereço é um número (IP), sem nome de site."))
            }
        }

        val high = mutableListOf<String>()
        val low = mutableListOf<String>()
        val unicode = try {
            IDN.toUnicode(host, IDN.ALLOW_UNASSIGNED)
        } catch (e: IllegalArgumentException) {
            host
        }
        val labels = unicode.split('.')
        val site = BlockRules.siteOf(host)
        val siteLabelCount = site.count { it == '.' } + 1
        val subdomainLabels = labels.dropLast(siteLabelCount)
        val siteName = labels.getOrNull(labels.size - siteLabelCount).orEmpty()

        // 1. Letras de outros alfabetos imitando letras comuns.
        if (host.contains("xn--")) {
            val mixed = labels.any { hasMixedScripts(it) }
            val skeleton = labels.joinToString(".") { label -> label.map { CONFUSABLES[it] ?: it }.joinToString("") }
            val imitated = BRANDS.keys.firstOrNull { brand -> skeleton.split('.', '-').contains(brand) }
            when {
                imitated != null -> high += "Usa letras de outro alfabeto para imitar \"$imitated\"."
                mixed -> high += "Mistura letras de alfabetos diferentes, um truque para imitar outro endereço."
                else -> Unit
            }
        }

        // 2. Nome de marca fora do site oficial dela.
        val tokens = labels.flatMap { it.split('-') }
        val hasSensitiveWord = tokens.any { it in SENSITIVE_WORDS }
        val subdomainTokens = subdomainLabels.flatMap { it.split('-') }.toSet()
        for (brand in BRANDS.keys) {
            if (brand !in tokens || isOfficial(brand, host)) continue
            when {
                brand in subdomainTokens ->
                    high += "Coloca \"$brand\" no começo do endereço, mas o site de verdade é $site."
                hasSensitiveWord ->
                    high += "Usa o nome \"$brand\" com palavras de login ou pagamento, mas não é um site oficial."
                else -> low += "Contém o nome \"$brand\", mas não é um endereço oficial dessa marca."
            }
        }

        // 3. Nome do site parecido com uma marca (troca de letras ou números), em cada parte do nome.
        for (part in siteName.split('-').filter { it.isNotEmpty() }) {
            val normalized = normalizeLookalike(part)
            for (brand in BRANDS.keys) {
                if (brand.length < 5 || part == brand || isOfficial(brand, host)) continue
                if (normalized == brand) {
                    high += "\"$part\" imita \"$brand\" trocando letras por números ou letras parecidas."
                } else if (brand.length >= 6 && isOneEditAway(part, brand)) {
                    val message = "\"$part\" difere de \"$brand\" por uma letra."
                    if (hasSensitiveWord || tld(host) in SUSPICIOUS_TLDS) high += message else low += message
                }
            }
        }

        // 4. Sinais fracos.
        if (tld(host) in SUSPICIOUS_TLDS) low += "Termina em .${tld(host)}, extensão muito usada em golpes."
        if (subdomainLabels.size >= 4) low += "Tem muitos níveis de subdomínio."
        if (host.length > 50) low += "Endereço muito longo."

        val level = when {
            high.isNotEmpty() -> RiskLevel.HIGH
            low.size >= 3 -> RiskLevel.HIGH
            low.isNotEmpty() -> RiskLevel.LOW
            else -> RiskLevel.NONE
        }
        return SuspicionReport(level, (high + low).distinct())
    }

    private fun isOfficial(brand: String, host: String): Boolean {
        if (brand == "gov") return GOV_SUFFIX.containsMatchIn(host)
        return BRANDS[brand].orEmpty().any { host == it || host.endsWith(".$it") }
    }

    private fun tld(host: String): String = host.substringAfterLast('.')

    private fun isPrivateIp(o: List<Int>): Boolean =
        o[0] == 10 || o[0] == 127 || (o[0] == 192 && o[1] == 168) || (o[0] == 172 && o[1] in 16..31) ||
            (o[0] == 169 && o[1] == 254)

    private fun hasMixedScripts(label: String): Boolean {
        val scripts = label.filter { it.isLetter() }
            .map { Character.UnicodeScript.of(it.code) }
            .toSet()
        return scripts.size > 1 && Character.UnicodeScript.LATIN in scripts
    }

    internal fun normalizeLookalike(name: String): String =
        name.map { DIGIT_SWAPS[it] ?: CONFUSABLES[it] ?: it }.joinToString("")
            .replace("rn", "m")
            .replace("vv", "w")

    /** Distância de edição (com troca de letras vizinhas) igual a 1. */
    internal fun isOneEditAway(a: String, b: String): Boolean {
        if (a == b) return false
        if (kotlin.math.abs(a.length - b.length) > 1) return false
        if (a.length == b.length) {
            val diffs = a.indices.filter { a[it] != b[it] }
            if (diffs.size == 1) return true
            return diffs.size == 2 && diffs[1] == diffs[0] + 1 &&
                a[diffs[0]] == b[diffs[1]] && a[diffs[1]] == b[diffs[0]]
        }
        val (shorter, longer) = if (a.length < b.length) a to b else b to a
        var i = 0
        while (i < shorter.length && shorter[i] == longer[i]) i++
        return shorter.substring(i) == longer.substring(i + 1)
    }
}
