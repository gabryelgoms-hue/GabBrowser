package com.gabbrowser.core.common.security

/** Recursos do aparelho que uma página pode pedir. O id é gravado nas decisões do usuário. */
enum class SitePermission(val id: String, val label: String) {
    CAMERA("camera", "câmera"),
    MICROPHONE("microphone", "microfone"),
    LOCATION("location", "localização");

    companion object {
        fun fromId(id: String): SitePermission? = entries.firstOrNull { it.id == id }
    }
}

/**
 * Ponte entre o motor e o GabShield, consultada antes de cada navegação principal.
 * Implementações precisam ser thread-safe.
 */
interface NavigationGuard {
    /**
     * Análise do site, já considerando os sites em que o usuário decidiu continuar.
     * [private] = pergunta vinda de aba anônima (decisões anônimas só valem para abas anônimas).
     * Pode ser chamada em threads de rede.
     */
    fun inspect(host: String, private: Boolean): SuspicionReport

    /** Sites em que o usuário aceitou abrir sem HTTPS. Pode ser chamada em threads de rede. */
    fun isHttpAllowed(host: String, private: Boolean): Boolean

    fun onWarningShown(host: String)

    fun onSafeBrowsingHit(host: String)
}
