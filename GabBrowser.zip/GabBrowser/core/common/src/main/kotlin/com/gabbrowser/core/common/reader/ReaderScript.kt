package com.gabbrowser.core.common.reader

/**
 * GabReader: script que lê o artigo principal da página e devolve só título e texto, em JSON:
 * {"title": "...", "byline": "...", "blocks": [{"t": "h|p|li|q", "x": "texto"}]}
 *
 * Escolhe o bloco com mais parágrafos (article, main ou o próprio body) e ignora menus,
 * rodapés, comentários, anúncios e formulários. Não altera a página.
 */
object ReaderScript {

    val EXTRACT: String = """
(function () {
  try {
    var SKIP = /(comment|share|social|related|recommend|promo|advert|banner|sidebar|footer|header|nav|menu|newsletter|cookie|popup|modal|subscribe)/i;
    function skipped(el) {
      for (var n = el; n && n !== document.body; n = n.parentElement) {
        var tag = n.tagName ? n.tagName.toLowerCase() : '';
        if (tag === 'nav' || tag === 'aside' || tag === 'footer' || tag === 'form' || tag === 'header' && n !== el) return true;
        var label = (n.id || '') + ' ' + (typeof n.className === 'string' ? n.className : '');
        if (label.length > 1 && SKIP.test(label)) return true;
      }
      return false;
    }
    function score(root) {
      if (!root) return 0;
      var total = 0;
      var ps = root.querySelectorAll('p');
      for (var i = 0; i < ps.length; i++) total += (ps[i].innerText || '').length;
      return total;
    }
    var candidates = [document.querySelector('article'), document.querySelector('main'),
      document.querySelector('[role=main]'), document.body];
    var root = document.body;
    var best = -1;
    for (var c = 0; c < candidates.length; c++) {
      var s = score(candidates[c]);
      if (candidates[c] && s > best * 1.2) { best = s; root = candidates[c]; }
    }
    var blocks = [];
    var nodes = root.querySelectorAll('h1,h2,h3,p,li,blockquote');
    for (var j = 0; j < nodes.length && blocks.length < 400; j++) {
      var el = nodes[j];
      if (skipped(el)) continue;
      var text = (el.innerText || '').replace(/\s+/g, ' ').trim();
      var tag = el.tagName.toLowerCase();
      var type = tag.charAt(0) === 'h' ? 'h' : (tag === 'li' ? 'li' : (tag === 'blockquote' ? 'q' : 'p'));
      if (type === 'p' && text.length < 40) continue;
      if (type === 'li' && text.length < 20) continue;
      if (type === 'h' && text.length < 3) continue;
      if (el.closest && el.closest('blockquote') && type !== 'q') continue;
      blocks.push({ t: type, x: text.slice(0, 4000) });
    }
    var heading = document.querySelector('h1');
    var meta = document.querySelector('meta[name=author]');
    return JSON.stringify({
      title: (heading && heading.innerText.trim()) || document.title || '',
      byline: meta ? (meta.getAttribute('content') || '') : '',
      blocks: blocks
    });
  } catch (e) {
    return JSON.stringify({ title: document.title || '', byline: '', blocks: [] });
  }
})();
""".trimIndent()
}
