package com.gabbrowser.core.common.blocking

object HostMatch {

    /** Valor associado ao host ou a um domínio pai dele ("a.b.exemplo.com" casa com "exemplo.com"). */
    fun <T> lookup(map: Map<String, T>, host: String): T? {
        if (map.isEmpty()) return null
        var candidate = host
        while (true) {
            map[candidate]?.let { return it }
            val dot = candidate.indexOf('.')
            if (dot < 0) return null
            candidate = candidate.substring(dot + 1)
            // Nunca casar só com a extensão ("com", "br").
            if (!candidate.contains('.')) return null
        }
    }

    fun matches(set: Set<String>, host: String): Boolean {
        if (set.isEmpty()) return false
        var candidate = host
        while (true) {
            if (candidate in set) return true
            val dot = candidate.indexOf('.')
            if (dot < 0) return false
            candidate = candidate.substring(dot + 1)
            if (!candidate.contains('.')) return false
        }
    }
}

/** Lista de domínios baixada (lista ampliada), com bloqueios e exceções. */
class DomainList(
    val blocked: Set<String>,
    val allowed: Set<String>,
) {
    fun blocks(host: String): Boolean =
        HostMatch.matches(blocked, host) && !HostMatch.matches(allowed, host)

    /** Mesmo formato que o [FilterListParser] lê, para gravar a lista no aparelho. */
    fun toFilterText(): String = buildString {
        blocked.forEach { append("||").append(it).append("^\n") }
        allowed.forEach { append("@@||").append(it).append("^\n") }
    }
}

/**
 * Lê listas no formato Adblock de domínios (||dominio^, @@||dominio^) e no formato hosts
 * (0.0.0.0 dominio). Regras com outros modificadores, curingas ou caminhos são ignoradas:
 * o GabClean só aplica bloqueio por domínio a partir de listas externas.
 */
object FilterListParser {

    const val MAX_RULES = 300_000

    private val DOMAIN = Regex("^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")
    private val WHITESPACE = Regex("\\s+")
    private val HOSTS_SINKS = setOf("0.0.0.0", "127.0.0.1", "::", "::1")
    private val HOSTS_IGNORED = setOf("localhost", "localhost.localdomain", "local", "broadcasthost", "ip6-localhost")

    fun parse(text: String): DomainList {
        val blocked = HashSet<String>()
        val allowed = HashSet<String>()
        for (raw in text.lineSequence()) {
            if (blocked.size >= MAX_RULES) break
            val line = raw.trim()
            if (line.isEmpty() || line[0] == '!' || line[0] == '#' || line[0] == '[') continue
            when {
                line.startsWith("@@||") -> networkDomain(line.substring(4))?.let { allowed.add(it) }
                line.startsWith("||") -> networkDomain(line.substring(2))?.let { blocked.add(it) }
                else -> hostsDomain(line)?.let { blocked.add(it) }
            }
        }
        return DomainList(blocked, allowed)
    }

    private fun networkDomain(rest: String): String? {
        val caret = rest.indexOf('^')
        if (caret <= 0) return null
        val modifiers = rest.substring(caret + 1)
        if (modifiers.isNotEmpty() && modifiers != "\$important" && modifiers != "|") return null
        val domain = rest.substring(0, caret).lowercase()
        return domain.takeIf { DOMAIN.matches(it) }
    }

    private fun hostsDomain(line: String): String? {
        val parts = line.substringBefore('#').trim().split(WHITESPACE)
        if (parts.size < 2 || parts[0] !in HOSTS_SINKS) return null
        val domain = parts[1].lowercase()
        if (domain in HOSTS_IGNORED) return null
        return domain.takeIf { DOMAIN.matches(it) }
    }
}
