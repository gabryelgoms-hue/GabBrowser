package com.gabbrowser.core.common.blocking

/** Estado do GabClean usado em cada requisição. Imutável, para ser lido de várias threads. */
data class BlockerSnapshot(
    val enabled: Boolean = true,
    val level: BlockLevel = BlockLevel.STANDARD,
    val youtube: Boolean = true,
    val exceptions: Set<String> = emptySet(),
    val extended: DomainList? = null,
) {
    /** Exceção para "globo.com" vale também para "ge.globo.com" e "www.globo.com". */
    fun isException(topHost: String?): Boolean {
        if (topHost.isNullOrEmpty() || exceptions.isEmpty()) return false
        val host = topHost.lowercase()
        return exceptions.any { host == it || host.endsWith(".$it") }
    }
}

object BlockRules {

    /** Sufixos de dois níveis mais comuns, para não tratar "uol.com.br" e "globo.com.br" como o mesmo site. */
    private val COMPOUND_SUFFIXES = setOf(
        "com.br", "net.br", "org.br", "gov.br", "edu.br", "art.br", "blog.br", "app.br", "jus.br", "leg.br",
        "co.uk", "org.uk", "ac.uk", "gov.uk",
        "com.au", "net.au", "org.au",
        "co.jp", "ne.jp", "or.jp",
        "com.ar", "com.mx", "com.co", "com.pe", "com.uy", "com.py", "com.pt",
        "com.cn", "com.tw", "com.hk", "co.in", "co.kr", "com.tr", "co.za",
    )

    private val YOUTUBE_AD_PATHS = listOf("/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll_info")

    /**
     * Decide se uma requisição de subrecurso deve ser bloqueada.
     * A página principal nunca passa por aqui: o que o usuário abriu sempre abre.
     */
    fun decide(snapshot: BlockerSnapshot, url: String, host: String, topHost: String?): BlockCategory? {
        if (!snapshot.enabled || snapshot.isException(topHost)) return null
        val requestHost = host.lowercase()

        if (snapshot.youtube && isYoutubeHost(requestHost) && isYoutubeAdPath(pathOf(url))) {
            return BlockCategory.AD
        }

        // Requisições do próprio site não são bloqueadas pelas listas, para não quebrar a página.
        if (!topHost.isNullOrEmpty() && isSameSite(requestHost, topHost)) return null

        BuiltInLists.categoryOf(requestHost, snapshot.level)?.let { return it }
        if (snapshot.extended?.blocks(requestHost) == true) return BlockCategory.EXTENDED_LIST
        return null
    }

    private val IPV4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")

    fun siteOf(host: String): String {
        // Endereço IP é o próprio "site": "1.2.3.4" não pode virar "3.4".
        if (IPV4.matches(host)) return host
        val labels = host.lowercase().trimEnd('.').split('.')
        if (labels.size <= 2) return labels.joinToString(".")
        val lastTwo = labels.takeLast(2).joinToString(".")
        val keep = if (lastTwo in COMPOUND_SUFFIXES) 3 else 2
        return labels.takeLast(keep).joinToString(".")
    }

    fun isSameSite(a: String, b: String): Boolean = siteOf(a) == siteOf(b)

    fun isYoutubeHost(host: String): Boolean = host == "youtube.com" || host.endsWith(".youtube.com")

    fun isYoutubeAdPath(path: String): Boolean =
        YOUTUBE_AD_PATHS.any { path.startsWith(it) } || path.contains("/ad_break")

    internal fun pathOf(url: String): String {
        val schemeEnd = url.indexOf("://")
        if (schemeEnd < 0) return ""
        val start = url.indexOf('/', schemeEnd + 3)
        if (start < 0) return "/"
        val end = url.indexOfAny(charArrayOf('?', '#'), start).let { if (it < 0) url.length else it }
        return url.substring(start, end)
    }
}
