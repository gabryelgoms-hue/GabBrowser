package com.gabbrowser.core.common.blocking

/**
 * Domínios bloqueados sem precisar baixar nada. Cada entrada também cobre os subdomínios.
 *
 * Critério do nível padrão: domínios que servem apenas anúncios ou rastreamento, cujo bloqueio
 * não costuma quebrar sites. Domínios que às vezes carregam funções do site (login social,
 * gerenciadores de tags, players de vídeo de anúncio) ficam no nível rigoroso.
 */
object BuiltInLists {

    val STANDARD_ADS: Set<String> = setOf(
        // Google
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "googletagservices.com",
        "adservice.google.com",
        "adservice.google.com.br",
        "2mdn.net",
        // Trocas e redes de anúncio
        "adnxs.com",
        "amazon-adsystem.com",
        "criteo.com",
        "criteo.net",
        "rubiconproject.com",
        "pubmatic.com",
        "openx.net",
        "casalemedia.com",
        "indexww.com",
        "adsrvr.org",
        "advertising.com",
        "smartadserver.com",
        "sascdn.com",
        "teads.tv",
        "yieldmo.com",
        "33across.com",
        "sharethrough.com",
        "triplelift.com",
        "3lift.com",
        "bidswitch.net",
        "sovrn.com",
        "lijit.com",
        "gumgum.com",
        "media.net",
        "contextweb.com",
        "adform.net",
        "adition.com",
        "yieldlab.net",
        "smaato.net",
        "inmobi.com",
        "serving-sys.com",
        "flashtalking.com",
        "spotxchange.com",
        "spotx.tv",
        "springserve.com",
        "tremorhub.com",
        "zedo.com",
        "ads.yahoo.com",
        // Recomendação patrocinada
        "taboola.com",
        "taboolasyndication.com",
        "outbrain.com",
        "outbrainimg.com",
        "mgid.com",
        "revcontent.com",
        // Pop-ups e redirecionamentos de anúncio
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "adcash.com",
        "exoclick.com",
        "juicyads.com",
        "trafficjunky.net",
        "adsterra.com",
        "hilltopads.net",
        // Anúncios em apps
        "applovin.com",
        "adcolony.com",
        "vungle.com",
        "chartboost.com",
        "unityads.unity3d.com",
    )

    val STANDARD_TRACKERS: Set<String> = setOf(
        "google-analytics.com",
        "analytics.google.com",
        "scorecardresearch.com",
        "quantserve.com",
        "quantcount.com",
        "moatads.com",
        "doubleverify.com",
        "adsafeprotected.com",
        "bluekai.com",
        "krxd.net",
        "exelator.com",
        "rlcdn.com",
        "tapad.com",
        "agkn.com",
        "rfihub.com",
        "mathtag.com",
        "everesttech.net",
        "eyeota.net",
        "crwdcntrl.net",
        "id5-sync.com",
        "liadm.com",
        "hotjar.com",
        "hotjar.io",
        "clarity.ms",
        "mixpanel.com",
        "mxpnl.com",
        "amplitude.com",
        "heapanalytics.com",
        "fullstory.com",
        "mouseflow.com",
        "crazyegg.com",
        "chartbeat.com",
        "chartbeat.net",
        "bat.bing.com",
        "ads-twitter.com",
        "analytics.twitter.com",
        "analytics.tiktok.com",
        "ads.linkedin.com",
        "snap.licdn.com",
        "tr.snapchat.com",
        "mc.yandex.ru",
        "appsflyer.com",
        "adjust.com",
        "kochava.com",
        // Brasil
        "navdmp.com",
        "navegg.com",
        "tailtarget.com",
    )

    val STRICT_ADS: Set<String> = setOf(
        // SDK de anúncios em vídeo; alguns players de sites de notícia dependem dele.
        "imasdk.googleapis.com",
    )

    val STRICT_TRACKERS: Set<String> = setOf(
        "googletagmanager.com",
        "connect.facebook.net",
        "demdex.net",
        "omtrdc.net",
        "sc-static.net",
        "optimizely.com",
        "pendo.io",
        // Fingerprinting (FingerprintJS)
        "fpjs.io",
        "fpcdn.io",
    )

    private val standard: Map<String, BlockCategory> = categorize(STANDARD_ADS, STANDARD_TRACKERS)

    private val strict: Map<String, BlockCategory> = standard + categorize(STRICT_ADS, STRICT_TRACKERS)

    fun categoryOf(host: String, level: BlockLevel): BlockCategory? =
        HostMatch.lookup(if (level == BlockLevel.STRICT) strict else standard, host)

    private fun categorize(ads: Set<String>, trackers: Set<String>): Map<String, BlockCategory> =
        ads.associateWith { BlockCategory.AD } + trackers.associateWith { BlockCategory.TRACKER }
}
