package com.gabbrowser.core.common.blocking

/**
 * Scripts que o GabClean injeta nas páginas.
 *
 * Eles não recebem nenhuma interface nativa. O único canal de volta é o objeto [MESSAGE_CHANNEL],
 * criado pelo motor só para as origens do YouTube, que aceita apenas as mensagens
 * "pruned" (anúncio removido antes de tocar) e "skipped" (anúncio pulado durante a exibição).
 */
object ContentScripts {

    const val MESSAGE_CHANNEL = "gabClean"

    val YOUTUBE_ORIGINS: Set<String> = setOf(
        "https://youtube.com",
        "https://*.youtube.com",
        "https://www.youtube-nocookie.com",
    )

    /** Esconde espaços de anúncio que ficam vazios depois do bloqueio de rede. Seletores específicos, para não esconder conteúdo. */
    val COSMETIC: String = """
(function () {
  try {
    if (document.getElementById('gab-clean-style')) return;
    var style = document.createElement('style');
    style.id = 'gab-clean-style';
    style.textContent = 'ins.adsbygoogle,div[id^="google_ads_iframe"],iframe[id^="google_ads_iframe"],' +
      'div[id^="div-gpt-ad"],amp-ad,amp-embed[type="taboola"],amp-embed[type="outbrain"],' +
      '.trc_rbox_container,.OUTBRAIN{display:none!important}';
    (document.head || document.documentElement).appendChild(style);
  } catch (e) {}
})();
""".trimIndent()

    /**
     * Anúncios do YouTube, em três camadas:
     * 1. remove adPlacements/adSlots/playerAds das respostas do player antes de o site lê-las;
     * 2. se um anúncio chegar a tocar, deixa mudo, avança até o fim e toca em "Pular";
     * 3. esconde blocos patrocinados do feed.
     */
    val YOUTUBE: String = """
(function () {
  'use strict';
  if (window.__gabCleanYoutube) return;
  window.__gabCleanYoutube = true;

  var AD_KEYS = ['adPlacements', 'adSlots', 'playerAds'];

  function report(kind) {
    try {
      if (window.gabClean && typeof window.gabClean.postMessage === 'function') {
        window.gabClean.postMessage(kind);
      }
    } catch (e) {}
  }

  function prune(obj, depth) {
    if (!obj || typeof obj !== 'object' || depth > 3) return false;
    var removed = false;
    try {
      if (Array.isArray(obj)) {
        for (var j = 0; j < obj.length && j < 10; j++) {
          if (prune(obj[j], depth + 1)) removed = true;
        }
        return removed;
      }
      for (var i = 0; i < AD_KEYS.length; i++) {
        var key = AD_KEYS[i];
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          var value = obj[key];
          if (value && (!Array.isArray(value) || value.length > 0)) removed = true;
          delete obj[key];
        }
      }
      if (prune(obj.playerResponse, depth + 1)) removed = true;
    } catch (e) {}
    return removed;
  }

  function handle(result) {
    if (prune(result, 0)) report('pruned');
    return result;
  }

  try {
    var originalParse = JSON.parse;
    JSON.parse = function () {
      return handle(originalParse.apply(this, arguments));
    };
  } catch (e) {}

  try {
    if (window.Response && Response.prototype.json) {
      var originalJson = Response.prototype.json;
      Response.prototype.json = function () {
        return originalJson.apply(this, arguments).then(handle);
      };
    }
  } catch (e) {}

  try {
    var initialResponse;
    Object.defineProperty(window, 'ytInitialPlayerResponse', {
      configurable: true,
      get: function () { return initialResponse; },
      set: function (value) { initialResponse = handle(value); }
    });
  } catch (e) {}

  var adActive = false;
  var mutedBeforeAd = false;
  function tick() {
    try {
      var player = document.querySelector('.html5-video-player');
      var video = player ? player.querySelector('video') : null;
      var showing = !!(player && player.classList.contains('ad-showing'));
      if (showing && video) {
        if (!adActive) {
          adActive = true;
          mutedBeforeAd = video.muted;
          report('skipped');
        }
        video.muted = true;
        if (isFinite(video.duration) && video.duration > 0 && video.currentTime < video.duration - 0.1) {
          video.currentTime = video.duration;
        }
        var button = document.querySelector(
          '.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-slot button');
        if (button) button.click();
      } else if (adActive) {
        adActive = false;
        if (video) video.muted = mutedBeforeAd;
      }
    } catch (e) {}
  }
  setInterval(tick, 250);

  var css = 'ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,' +
    'ytm-ad-slot-renderer,ad-slot-renderer,ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,' +
    'ytd-banner-promo-renderer,ytd-promoted-sparkles-web-renderer,#masthead-ad,#player-ads,' +
    '.ytp-ad-overlay-container{display:none!important}';
  function addStyle() {
    if (document.getElementById('gab-clean-youtube')) return true;
    var root = document.head || document.documentElement;
    if (!root) return false;
    var style = document.createElement('style');
    style.id = 'gab-clean-youtube';
    style.textContent = css;
    root.appendChild(style);
    return true;
  }
  if (!addStyle()) document.addEventListener('DOMContentLoaded', addStyle);
})();
""".trimIndent()
}
