package com.gabbrowser.core.common.blocking

/** Motivo de um bloqueio. O id é gravado nas estatísticas, então não deve mudar. */
enum class BlockCategory(val id: String) {
    AD("ad"),
    TRACKER("tracker"),
    EXTENDED_LIST("extended"),

    /** Anúncio do YouTube removido da resposta do player ou pulado durante a exibição. */
    YOUTUBE_AD("youtube");

    companion object {
        fun fromId(id: String): BlockCategory? = entries.firstOrNull { it.id == id }
    }
}

enum class BlockLevel(val id: String) {
    STANDARD("standard"),
    STRICT("strict");

    companion object {
        fun fromId(id: String?): BlockLevel = entries.firstOrNull { it.id == id } ?: STANDARD
    }
}

/** O que o motor deve injetar nas páginas. */
data class ContentScriptConfig(val youtube: Boolean)

/**
 * Ponte entre o motor de navegação e o GabClean.
 * [evaluate] é chamado em threads de rede do WebView, então a implementação precisa ser thread-safe.
 */
interface ContentBlocker {
    /** Devolve o motivo do bloqueio, ou null para deixar a requisição passar. */
    fun evaluate(url: String, host: String, topHost: String?): BlockCategory?

    fun shouldApplyCosmetics(topHost: String?): Boolean

    /** [topHost] = site em que o bloqueio aconteceu (null para service workers). */
    fun onBlocked(host: String, category: BlockCategory, topHost: String?)

    fun onYoutubeAdHandled()
}
