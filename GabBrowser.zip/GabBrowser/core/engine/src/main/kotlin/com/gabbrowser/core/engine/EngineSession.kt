package com.gabbrowser.core.engine

import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import com.gabbrowser.core.common.blocking.ContentScriptConfig
import com.gabbrowser.core.common.security.SitePermission
import com.gabbrowser.core.common.security.SuspicionReport
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/** NONE = ainda carregando/sem página; INSECURE = página aberta sem HTTPS por escolha do usuário. */
enum class ConnectionSecurity { NONE, SECURE, INSECURE, CERTIFICATE_ERROR }

sealed interface PageError {
    data class Network(val description: String) : PageError

    data class Certificate(val host: String, val reason: String) : PageError

    /** O site só funciona sem HTTPS. [httpUrl] permite abrir assim mesmo, se o usuário aceitar. */
    data class InsecureOnly(val host: String, val httpUrl: String) : PageError

    /** O GabShield segurou a navegação antes de abrir: o endereço parece golpe. */
    data class Suspicious(val host: String, val url: String, val reasons: List<String>) : PageError

    data object RendererCrashed : PageError
}

data class PageState(
    val url: String = "",
    val title: String = "",
    val progress: Int = 0,
    val isLoading: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val security: ConnectionSecurity = ConnectionSecurity.NONE,
    val error: PageError? = null,
    /** Requisições bloqueadas pelo GabClean desde que a página atual começou a carregar. */
    val blockedCount: Int = 0,
    /** Análise do GabShield para o site atual (risco baixo aparece no painel do escudo). */
    val suspicion: SuspicionReport = SuspicionReport.SAFE,
    /** A página tem campo de senha (para oferecer o preenchimento). */
    val hasPasswordField: Boolean = false,
)

sealed interface EngineEvent {
    data class NavigationBlocked(val scheme: String) : EngineEvent

    /** A página pediu para baixar um arquivo. O app decide se e como baixar. */
    data class DownloadRequested(
        val url: String,
        val userAgent: String,
        val contentDisposition: String?,
        val mimeType: String?,
        val contentLength: Long,
    ) : EngineEvent

    /**
     * A página pediu câmera, microfone ou localização. O app precisa chamar [respond] uma vez:
     * true concede, false nega. Sem resposta, o pedido fica pendente na página.
     */
    data class PermissionRequested(
        val origin: String,
        val permissions: Set<SitePermission>,
        val respond: (Boolean) -> Unit,
    ) : EngineEvent

    /** A página desistiu do pedido de permissão (fecha o diálogo, se ainda estiver aberto). */
    data class PermissionCanceled(val origin: String) : EngineEvent

    /** Vídeo pediu tela cheia: o app mostra [view] ocupando a tela; [exit] devolve o vídeo à página. */
    data class EnterFullscreen(val view: View, val exit: () -> Unit) : EngineEvent

    data object ExitFullscreen : EngineEvent

    /**
     * Formulário pediu um arquivo. O app abre o seletor do Android com [intent] e chama [onResult] uma vez,
     * com os arquivos escolhidos ou null se o usuário cancelar.
     */
    data class FileChooserRequested(
        val intent: android.content.Intent,
        val onResult: (Array<android.net.Uri>?) -> Unit,
    ) : EngineEvent

    /** Login enviado numa página https de aba normal. [origin] vem do WebView, não da página. */
    data class CredentialSubmitted(
        val origin: String,
        val username: String,
        val password: String,
    ) : EngineEvent
}

fun interface VisitListener {
    fun onVisit(url: String, title: String)
}

/**
 * Contrato do motor de navegação. O app só conversa com esta interface, então
 * trocar o motor (por exemplo, para GeckoView) não exige mexer nas telas.
 */
interface EngineSession {
    val state: StateFlow<PageState>
    val events: SharedFlow<EngineEvent>
    val view: View
    var visitListener: VisitListener?

    /** Sessão anônima: armazenamento isolado da navegação normal e apagado ao fechar. */
    val isPrivate: Boolean

    /** Liga ou desliga os scripts do GabClean. Vale a partir da próxima página carregada. */
    fun applyContentScripts(config: ContentScriptConfig)

    fun loadUrl(url: String)
    fun reload()
    fun stop()
    fun goBack()
    fun goForward()
    fun onResume()
    fun onPause()
    fun destroy()

    /** Histórico de voltar/avançar da aba, para recriar a sessão depois de suspensa. */
    fun saveState(): Bundle?

    /** Miniatura da parte visível da página, para os cartões de abas. */
    fun captureThumbnail(maxWidth: Int): Bitmap?

    /** Cookies do armazenamento desta sessão, para downloads que exigem login. */
    fun cookiesFor(url: String): String?

    /**
     * Lê o texto da página (ou só o trecho selecionado) para o GabAI e o GabReader.
     * [onResult] recebe "" se não houver texto. Só é chamada depois de o usuário pedir.
     */
    fun extractText(selectionOnly: Boolean, maxChars: Int, onResult: (String) -> Unit)

    /** Executa um script de leitura definido pelo app (nunca código vindo de sites) e devolve o resultado em JSON. */
    fun evaluateAppScript(script: String, onResult: (String?) -> Unit)

    /** GabSaver: carregar ou não as imagens das páginas. */
    fun setLoadImages(load: Boolean)

    /** Oferecer para salvar senhas (nunca em aba anônima). */
    fun setPasswordCapture(enabled: Boolean)

    /**
     * Preenche usuário e senha, só se a página atual ainda for da origem [origin].
     * Devolve false (e não preenche) se a página mudou de site.
     */
    fun fillCredentials(origin: String, username: String, password: String): Boolean
}
