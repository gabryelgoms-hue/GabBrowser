package com.gabbrowser.core.engine

import org.json.JSONObject

/**
 * Scripts do gerenciador de senhas. Rodam só no quadro principal de páginas https.
 *
 * Captura: ao enviar um formulário com senha preenchida, manda {u, p} pelo canal [CHANNEL]. O app usa a origem
 * informada pelo próprio WebView (não pela página) e só pergunta se o usuário quer salvar.
 * Preenchimento: só depois da autenticação do usuário e só na mesma origem em que a senha foi salva.
 */
internal object PasswordScripts {

    const val CHANNEL = "gabPass"

    /** Toda origem pode enviar; o app aceita só https, quadro principal e aba normal. */
    val ORIGINS: Set<String> = setOf("*")

    val CAPTURE: String = """
(function () {
  if (window.__gabPass) return;
  window.__gabPass = true;
  var last = '';
  function send(scope) {
    try {
      var root = scope || document;
      var pw = root.querySelector('input[type=password]');
      if (!pw || !pw.value) return;
      var inputs = Array.prototype.slice.call(root.querySelectorAll('input'));
      var user = '';
      for (var i = inputs.indexOf(pw) - 1; i >= 0; i--) {
        var t = (inputs[i].type || 'text').toLowerCase();
        if ((t === 'text' || t === 'email' || t === 'tel') && inputs[i].value) { user = inputs[i].value; break; }
      }
      var payload = JSON.stringify({ u: user, p: pw.value });
      if (payload === last) return;
      last = payload;
      if (window.gabPass && typeof window.gabPass.postMessage === 'function') window.gabPass.postMessage(payload);
    } catch (e) {}
  }
  document.addEventListener('submit', function (e) { send(e.target); }, true);
  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('button,input[type=submit]') : null;
    if (b) send(b.form);
  }, true);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && e.target && e.target.type === 'password') send(e.target.form);
  }, true);
})();
""".trimIndent()

    const val DETECT = "(function(){return !!document.querySelector('input[type=password]');})()"

    /**
     * Valores entram como literais JSON (escapados), nunca como código. O próprio documento confere a origem
     * antes de preencher: se a página trocou de site entre a autenticação e o preenchimento, nada é escrito.
     */
    fun fill(origin: String, username: String, password: String): String = """
(function (o, u, p) {
  if (window.top !== window || String(location.origin).toLowerCase() !== o) return false;
  var pw = document.querySelector('input[type=password]');
  if (!pw) return false;
  var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  function put(el, v) {
    setter.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  var inputs = Array.prototype.slice.call(document.querySelectorAll('input'));
  for (var i = inputs.indexOf(pw) - 1; i >= 0; i--) {
    var t = (inputs[i].type || 'text').toLowerCase();
    if (t === 'text' || t === 'email' || t === 'tel') { if (u) put(inputs[i], u); break; }
  }
  put(pw, p);
  return true;
})(${JSONObject.quote(origin.lowercase())}, ${JSONObject.quote(username)}, ${JSONObject.quote(password)});
""".trimIndent()
}
