package com.gabbrowser.core.engine

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.net.Uri
import android.net.http.SslError
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SafeBrowsingResponse
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.Profile
import androidx.webkit.ProfileStore
import androidx.webkit.ScriptHandler
import androidx.webkit.ServiceWorkerClientCompat
import androidx.webkit.ServiceWorkerControllerCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.gabbrowser.core.common.NavigationPolicy
import com.gabbrowser.core.common.blocking.BlockRules
import com.gabbrowser.core.common.blocking.ContentBlocker
import com.gabbrowser.core.common.blocking.ContentScriptConfig
import com.gabbrowser.core.common.blocking.ContentScripts
import com.gabbrowser.core.common.security.NavigationGuard
import com.gabbrowser.core.common.security.RiskLevel
import com.gabbrowser.core.common.security.SitePermission
import java.io.ByteArrayInputStream
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Sessão de navegação sobre o Android System WebView, com configuração endurecida:
 *
 * - erros de certificado nunca são ignorados (a carga é sempre cancelada);
 * - conteúdo misto (http dentro de https) é bloqueado;
 * - páginas não acessam arquivos locais nem content providers;
 * - nenhuma interface JavaScript nativa é exposta (sem addJavascriptInterface);
 * - cookies de terceiros desligados;
 * - pedidos de câmera, microfone e localização são negados (a tela de permissões chega na Etapa 3);
 * - Navegação Segura do WebView ligada.
 *
 * Com um [ContentBlocker], também aplica o GabClean: requisições de anúncio e rastreamento são
 * respondidas localmente com um corpo vazio, e os scripts de limpeza são injetados nas páginas.
 *
 * Deve ser criada com o contexto da Activity e usada somente na thread principal
 * (exceto o filtro de requisições, que o WebView chama em threads de rede).
 */
class WebViewSession(
    context: Context,
    private val blocker: ContentBlocker? = null,
    private val guard: NavigationGuard? = null,
    privateProfile: String? = null,
    savedState: Bundle? = null,
) : EngineSession {

    override val isPrivate: Boolean = privateProfile != null

    /** Perfil isolado das abas anônimas: cookies, cache e armazenamento separados. */
    private val profile: Profile? = privateProfile?.let { ProfileStore.getInstance().getOrCreateProfile(it) }


    private val _state = MutableStateFlow(PageState())
    override val state: StateFlow<PageState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<EngineEvent>(extraBufferCapacity = 8)
    override val events: SharedFlow<EngineEvent> = _events.asSharedFlow()

    override var visitListener: VisitListener? = null

    // O perfil precisa ser definido antes de qualquer outro uso do WebView.
    private val webView = WebView(context).also { view ->
        if (privateProfile != null) WebViewCompat.setProfile(view, privateProfile)
    }
    override val view: View get() = webView

    private val cookies: CookieManager = profile?.cookieManager ?: CookieManager.getInstance()

    /** Host da navegação principal em andamento, para reconhecer erros de certificado da página. */
    @Volatile
    private var pendingHost: String? = null

    /** URL cuja carga falhou; evita que eventos tardios da mesma carga apaguem o erro. */
    private var failedUrl: String? = null

    private var lastUpgradedUrl: String? = null
    private var lastRecordedUrl: String? = null
    private var destroyed = false

    /** O processo de renderização caiu: o WebView não pode mais ser desenhado nem salvo até ser recriado. */
    private var rendererGone = false

    /** Vídeo em tela cheia em andamento; é devolvido à página se a aba fechar ou cair. */
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null

    private fun endFullscreen() {
        val callback = fullscreenCallback ?: return
        fullscreenCallback = null
        try {
            callback.onCustomViewHidden()
        } catch (e: RuntimeException) {
            // WebView já encerrado.
        }
        _events.tryEmit(EngineEvent.ExitFullscreen)
    }

    /** Host da página exibida. Lido pelo filtro de requisições em outra thread. */
    @Volatile
    private var topHost: String? = null

    private var scriptConfig = ContentScriptConfig(youtube = false)
    private var passwordCapture = false

    /** Uma oferta de salvar senha por página carregada, para a página não abrir o diálogo quando quiser. */
    private var credentialOffered = false
    private var lastCredentialAt = 0L
    private var youtubeScript: ScriptHandler? = null

    init {
        configure()
        if (savedState != null) restore(savedState)
    }

    private fun restore(bundle: Bundle) {
        if (webView.restoreState(bundle) == null) return
        val url = webView.url ?: return
        topHost = hostOf(url)
        _state.update {
            it.copy(
                url = url,
                title = webView.title.orEmpty(),
                canGoBack = webView.canGoBack(),
                canGoForward = webView.canGoForward(),
            )
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    private fun configure() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true

            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false

            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true

            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            // Pedidos de localização chegam ao app, que pergunta ao usuário (GabShield).
            setGeolocationEnabled(true)
            mediaPlaybackRequiresUserGesture = true

            builtInZoomControls = true
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
        }

        cookies.apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, false)
        }

        webView.webViewClient = Client()
        webView.webChromeClient = Chrome()
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
            if (url != null) {
                _events.tryEmit(
                    EngineEvent.DownloadRequested(
                        url = url,
                        userAgent = userAgent.orEmpty(),
                        contentDisposition = contentDisposition,
                        mimeType = mimeType,
                        contentLength = contentLength,
                    ),
                )
            }
        }
        installYoutubeMessageChannel()
        installPasswordChannel()
    }

    /** Canal da captura de senhas: só aceita https, quadro principal e aba normal. */
    private fun installPasswordChannel() {
        if (isPrivate || !WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) return
        try {
            WebViewCompat.addWebMessageListener(webView, PasswordScripts.CHANNEL, PasswordScripts.ORIGINS) { _, message, sourceOrigin, isMainFrame, _ ->
                val origin = sourceOrigin.toString()
                val data = message.data
                if (!passwordCapture || !isMainFrame || !origin.startsWith("https://") || data == null || data.length > 4096) {
                    return@addWebMessageListener
                }
                val now = android.os.SystemClock.elapsedRealtime()
                if (credentialOffered || now - lastCredentialAt < 5_000) return@addWebMessageListener
                try {
                    val json = org.json.JSONObject(data)
                    val password = json.optString("p")
                    if (password.isNotEmpty() && password.length <= 512) {
                        credentialOffered = true
                        lastCredentialAt = now
                        _events.tryEmit(
                            EngineEvent.CredentialSubmitted(origin, json.optString("u").take(256), password),
                        )
                    }
                } catch (e: org.json.JSONException) {
                    // Mensagem fora do formato: ignorada.
                }
            }
        } catch (e: IllegalArgumentException) {
            // Regra de origem não aceita por este WebView: sem captura de senhas.
        }
    }

    override fun setPasswordCapture(enabled: Boolean) {
        passwordCapture = enabled && !isPrivate
    }

    override fun fillCredentials(origin: String, username: String, password: String): Boolean {
        if (destroyed || rendererGone) return false
        val current = Uri.parse(_state.value.url)
        val currentOrigin = "${current.scheme}://${current.host}" + if (current.port != -1 && current.port != 443) ":${current.port}" else ""
        if (!currentOrigin.equals(origin, ignoreCase = true) || current.scheme != "https") return false
        webView.evaluateJavascript(PasswordScripts.fill(origin, username, password), null)
        return true
    }

    private fun detectPasswordField() {
        val url = _state.value.url
        if (!url.startsWith("https://")) return
        webView.evaluateJavascript(PasswordScripts.DETECT) { raw ->
            if (!destroyed && _state.value.url == url) _state.update { it.copy(hasPasswordField = raw == "true") }
        }
    }

    /**
     * Canal pelo qual o script do YouTube avisa que removeu ou pulou um anúncio, para a contagem
     * ser real. Só existe nas origens do YouTube e só aceita duas mensagens fixas.
     */
    private fun installYoutubeMessageChannel() {
        val blocker = blocker ?: return
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) return
        try {
            WebViewCompat.addWebMessageListener(
                webView,
                ContentScripts.MESSAGE_CHANNEL,
                ContentScripts.YOUTUBE_ORIGINS,
            ) { _, message, _, isMainFrame, _ ->
                val kind = message.data
                // Aba anônima: não grava estatística (seria rastro de que o YouTube foi visitado).
                if (isMainFrame && !isPrivate && (kind == "pruned" || kind == "skipped")) {
                    blocker.onYoutubeAdHandled()
                }
            }
        } catch (e: IllegalArgumentException) {
            // Regra de origem não aceita por este WebView: segue sem contagem do YouTube.
        }
    }

    override fun applyContentScripts(config: ContentScriptConfig) {
        if (destroyed) return
        scriptConfig = config
        youtubeScript?.remove()
        youtubeScript = null
        if (config.youtube && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            youtubeScript = try {
                WebViewCompat.addDocumentStartJavaScript(
                    webView,
                    ContentScripts.YOUTUBE,
                    ContentScripts.YOUTUBE_ORIGINS,
                )
            } catch (e: IllegalArgumentException) {
                null
            }
        }
    }

    override fun loadUrl(url: String) {
        if (destroyed || rendererGone) return
        when (val decision = evaluate(url)) {
            is NavigationPolicy.Decision.Allow -> start(url.trim())
            is NavigationPolicy.Decision.UpgradeToHttps -> start(decision.url)
            is NavigationPolicy.Decision.Block -> _events.tryEmit(EngineEvent.NavigationBlocked(decision.scheme))
        }
    }

    /** Política de esquemas, com as exceções de HTTP que o usuário aceitou no GabShield. */
    private fun evaluate(url: String): NavigationPolicy.Decision {
        val decision = NavigationPolicy.evaluate(url)
        if (decision is NavigationPolicy.Decision.UpgradeToHttps) {
            val host = hostOf(url)
            if (host != null && guard?.isHttpAllowed(host, isPrivate) == true) return NavigationPolicy.Decision.Allow
        }
        return decision
    }

    /**
     * Consulta o GabShield antes de abrir um site. Devolve false (e mostra o aviso) quando o
     * endereço parece golpe; o usuário pode continuar pelo aviso.
     */
    private fun passesGuard(url: String): Boolean {
        val guard = guard ?: return true
        val host = hostOf(url) ?: return true
        val report = guard.inspect(host, isPrivate)
        _state.update { it.copy(suspicion = report) }
        if (report.level != RiskLevel.HIGH) return true
        guard.onWarningShown(host)
        _state.update { it.copy(url = url, title = "") }
        fail(PageError.Suspicious(host, url, report.reasons), url, ConnectionSecurity.NONE)
        return false
    }

    private fun start(url: String) {
        clearFailure()
        lastUpgradedUrl = null
        if (!passesGuard(url)) {
            webView.stopLoading()
            return
        }
        pendingHost = hostOf(url)
        topHost = pendingHost
        _state.update {
            it.copy(url = url, isLoading = true, progress = 0, security = ConnectionSecurity.NONE)
        }
        webView.loadUrl(url)
    }

    override fun reload() {
        if (destroyed || rendererGone) return
        val current = _state.value
        if (current.error != null && current.url.isNotEmpty()) {
            start(current.url)
        } else {
            clearFailure()
            webView.reload()
        }
    }

    override fun stop() {
        if (destroyed) return
        webView.stopLoading()
        _state.update { it.copy(isLoading = false) }
    }

    override fun goBack() {
        if (destroyed || rendererGone || !webView.canGoBack()) return
        clearFailure()
        webView.goBack()
    }

    override fun goForward() {
        if (destroyed || rendererGone || !webView.canGoForward()) return
        clearFailure()
        webView.goForward()
    }

    override fun onResume() {
        if (!destroyed) webView.onResume()
    }

    override fun onPause() {
        if (!destroyed) webView.onPause()
    }

    override fun destroy() {
        if (destroyed) return
        endFullscreen()
        destroyed = true
        visitListener = null
        youtubeScript?.remove()
        youtubeScript = null
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.stopLoading()
        webView.destroy()
    }

    override fun saveState(): Bundle? {
        if (destroyed || rendererGone) return null
        val bundle = Bundle()
        return if (webView.saveState(bundle) != null) bundle else null
    }

    override fun captureThumbnail(maxWidth: Int): Bitmap? {
        if (destroyed || rendererGone || webView.width <= 0 || webView.height <= 0) return null
        return try {
            val scale = (maxWidth.toFloat() / webView.width).coerceAtMost(1f)
            val visibleHeight = minOf(webView.height, (webView.width * 1.25f).toInt())
            val bitmap = Bitmap.createBitmap(
                (webView.width * scale).toInt().coerceAtLeast(1),
                (visibleHeight * scale).toInt().coerceAtLeast(1),
                Bitmap.Config.RGB_565,
            )
            val canvas = Canvas(bitmap)
            canvas.scale(scale, scale)
            canvas.translate(-webView.scrollX.toFloat(), -webView.scrollY.toFloat())
            webView.draw(canvas)
            bitmap
        } catch (e: RuntimeException) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    override fun cookiesFor(url: String): String? = cookies.getCookie(url)

    override fun extractText(selectionOnly: Boolean, maxChars: Int, onResult: (String) -> Unit) {
        if (destroyed || rendererGone) {
            onResult("")
            return
        }
        val source = if (selectionOnly) {
            "(window.getSelection ? String(window.getSelection()) : '')"
        } else {
            "(document.body ? document.body.innerText : '')"
        }
        val script = "(function(){try{return $source.replace(/\\n{3,}/g,'\\n\\n').slice(0,$maxChars);}catch(e){return '';}})()"
        webView.evaluateJavascript(script) { raw -> onResult(decodeJsString(raw)) }
    }

    override fun evaluateAppScript(script: String, onResult: (String?) -> Unit) {
        if (destroyed || rendererGone) {
            onResult(null)
            return
        }
        webView.evaluateJavascript(script) { raw -> onResult(raw?.takeIf { it != "null" }) }
    }

    override fun setLoadImages(load: Boolean) {
        if (destroyed) return
        webView.settings.blockNetworkImage = !load
        webView.settings.loadsImagesAutomatically = load
    }

    /** evaluateJavascript devolve o valor em JSON ("\"texto\""); converte para texto normal. */
    private fun decodeJsString(raw: String?): String {
        if (raw.isNullOrEmpty() || raw == "null") return ""
        return try {
            org.json.JSONArray("[$raw]").optString(0)
        } catch (e: org.json.JSONException) {
            ""
        }
    }

    private fun clearFailure() {
        failedUrl = null
        _state.update { it.copy(error = null) }
    }

    private fun fail(error: PageError, url: String?, security: ConnectionSecurity) {
        failedUrl = url
        _state.update { it.copy(error = error, isLoading = false, security = security) }
    }

    private fun hostOf(url: String?): String? = url?.let { Uri.parse(it).host }

    private fun securityOf(url: String?): ConnectionSecurity = when {
        url == null -> ConnectionSecurity.NONE
        url.startsWith("https://", ignoreCase = true) -> ConnectionSecurity.SECURE
        url.startsWith("http://", ignoreCase = true) -> ConnectionSecurity.INSECURE
        else -> ConnectionSecurity.NONE
    }

    private inner class Client : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            if (request == null) return true
            val target = request.url?.toString() ?: return true
            val decision = evaluate(target)

            if (!request.isForMainFrame) {
                return decision !is NavigationPolicy.Decision.Allow
            }

            return when (decision) {
                is NavigationPolicy.Decision.Allow -> {
                    clearFailure()
                    if (!passesGuard(target)) return true
                    pendingHost = hostOf(target)
                    topHost = pendingHost
                    false
                }

                is NavigationPolicy.Decision.UpgradeToHttps -> {
                    // Só é "site sem HTTPS" quando o próprio servidor redireciona de volta para http.
                    // Navegações repetidas feitas por script não podem disparar esse aviso.
                    val serverDowngrade = request.isRedirect && hostOf(target) == pendingHost
                    if (decision.url == lastUpgradedUrl && serverDowngrade) {
                        // O site devolve para http depois do upgrade: só funciona sem criptografia.
                        fail(
                            PageError.InsecureOnly(hostOf(target).orEmpty(), target),
                            decision.url,
                            ConnectionSecurity.NONE,
                        )
                    } else {
                        clearFailure()
                        if (!passesGuard(decision.url)) return true
                        lastUpgradedUrl = decision.url
                        pendingHost = hostOf(decision.url)
                        webView.loadUrl(decision.url)
                    }
                    true
                }

                is NavigationPolicy.Decision.Block -> {
                    _events.tryEmit(EngineEvent.NavigationBlocked(decision.scheme))
                    true
                }
            }
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            if (url == null) return
            credentialOffered = false
            if (url != failedUrl) clearFailure()
            topHost = hostOf(url)
            _state.update {
                it.copy(
                    url = url,
                    isLoading = true,
                    blockedCount = 0,
                    hasPasswordField = false,
                    security = if (it.error == null) ConnectionSecurity.NONE else it.security,
                )
            }
        }

        override fun shouldInterceptRequest(
            view: WebView?,
            request: WebResourceRequest?,
        ): WebResourceResponse? {
            if (request == null) return null
            if (request.isForMainFrame) return guardMainFrameRequest(request)
            val blocker = blocker ?: return null
            if (filterRequest(blocker, request, topHost, private = isPrivate) == null) return null
            _state.update { it.copy(blockedCount = it.blockedCount + 1) }
            return blockedResponse()
        }

        /**
         * Última barreira antes de a página principal sair para a rede. Navegações POST (envio de
         * formulário) não passam por shouldOverrideUrlLoading, então são checadas aqui, antes de qualquer
         * dado ser enviado: http sem exceção do usuário é barrado, e site de golpe recebe o aviso.
         * Roda em thread de rede: o aviso é mostrado pela thread principal.
         */
        private fun guardMainFrameRequest(request: WebResourceRequest): WebResourceResponse? {
            val uri = request.url ?: return null
            val url = uri.toString()
            val host = uri.host?.lowercase() ?: return null
            if (uri.scheme.equals("http", ignoreCase = true) && guard?.isHttpAllowed(host, isPrivate) != true) {
                webView.post {
                    if (!destroyed) {
                        fail(
                            PageError.Network("O GabBrowser não enviou dados para $host porque a conexão não tem HTTPS."),
                            url,
                            ConnectionSecurity.NONE,
                        )
                    }
                }
                return blockedResponse()
            }
            val guard = guard ?: return null
            if (host != pendingHost && guard.inspect(host, isPrivate).level == RiskLevel.HIGH) {
                webView.post { if (!destroyed) passesGuard(url) }
                return blockedResponse()
            }
            return null
        }

        override fun onPageCommitVisible(view: WebView?, url: String?) {
            if (url != null && url.startsWith("https://")) {
                if (passwordCapture) webView.evaluateJavascript(PasswordScripts.CAPTURE, null)
                detectPasswordField()
            }
            val blocker = blocker ?: return
            val host = topHost
            if (blocker.shouldApplyCosmetics(host)) {
                webView.evaluateJavascript(ContentScripts.COSMETIC, null)
            }
            // Sem suporte a script no início do documento: injeta agora. Pula anúncios que
            // chegarem a tocar, mas não consegue removê-los da primeira resposta do player.
            if (scriptConfig.youtube && youtubeScript == null && host != null && BlockRules.isYoutubeHost(host)) {
                webView.evaluateJavascript(ContentScripts.YOUTUBE, null)
            }
        }

        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
            if (url == null) return
            topHost = hostOf(url)
            _state.update {
                it.copy(
                    url = url,
                    canGoBack = webView.canGoBack(),
                    canGoForward = webView.canGoForward(),
                    security = if (it.error == null) securityOf(url) else it.security,
                )
            }
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            lastUpgradedUrl = null
            val title = webView.title.orEmpty()
            _state.update {
                it.copy(
                    title = title,
                    isLoading = false,
                    progress = 100,
                    canGoBack = webView.canGoBack(),
                    canGoForward = webView.canGoForward(),
                    security = if (it.error == null) securityOf(url) else it.security,
                )
            }

            val finished = url ?: return
            detectPasswordField()
            val isWebPage = finished.startsWith("https://", ignoreCase = true)
            if (_state.value.error == null && isWebPage && finished != lastRecordedUrl) {
                lastRecordedUrl = finished
                visitListener?.onVisit(finished, title)
            }
        }

        override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
            // Nunca prosseguir com certificado inválido.
            handler?.cancel()

            val errorHost = hostOf(error?.url) ?: return
            val isPageItself = errorHost == pendingHost || errorHost == hostOf(_state.value.url)
            if (isPageItself) {
                fail(
                    PageError.Certificate(errorHost, describeSslError(error)),
                    error?.url,
                    ConnectionSecurity.CERTIFICATE_ERROR,
                )
            }
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?,
        ) {
            if (request == null || !request.isForMainFrame) return
            val current = _state.value.error
            if (current is PageError.Certificate || current is PageError.InsecureOnly || current is PageError.Suspicious) {
                return
            }
            fail(
                PageError.Network(error?.description?.toString().orEmpty()),
                request.url?.toString(),
                ConnectionSecurity.NONE,
            )
        }

        /** Site da lista de golpes e malware do Google: conta o evento e mostra o aviso do próprio WebView. */
        override fun onSafeBrowsingHit(
            view: WebView?,
            request: WebResourceRequest?,
            threatType: Int,
            callback: SafeBrowsingResponse?,
        ) {
            request?.url?.host?.let { guard?.onSafeBrowsingHit(it) }
            callback?.showInterstitial(true)
        }

        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            // Devolver true evita que o app inteiro seja encerrado junto com o renderizador.
            rendererGone = true
            endFullscreen()
            fail(PageError.RendererCrashed, _state.value.url, ConnectionSecurity.NONE)
            return true
        }
    }

    private inner class Chrome : WebChromeClient() {

        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            _state.update { it.copy(progress = newProgress) }
        }

        override fun onReceivedTitle(view: WebView?, title: String?) {
            _state.update { it.copy(title = title.orEmpty()) }
        }

        override fun onPermissionRequest(request: PermissionRequest?) {
            if (request == null) return
            val origin = request.origin?.toString().orEmpty()
            val wanted = request.resources.orEmpty().mapNotNull { resource ->
                when (resource) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> resource to SitePermission.CAMERA
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> resource to SitePermission.MICROPHONE
                    else -> null // DRM e MIDI não são concedidos
                }
            }
            if (wanted.isEmpty() || !origin.startsWith("https://")) {
                request.deny()
                return
            }
            val event = EngineEvent.PermissionRequested(
                origin = origin,
                permissions = wanted.map { it.second }.toSet(),
                respond = { allow ->
                    try {
                        if (allow) request.grant(wanted.map { it.first }.toTypedArray()) else request.deny()
                    } catch (e: IllegalStateException) {
                        // Pedido já cancelado pela página.
                    }
                },
            )
            // Sem tela ouvindo (aba em segundo plano), nega na hora em vez de deixar o pedido pendente.
            if (_events.subscriptionCount.value == 0 || !_events.tryEmit(event)) request.deny()
        }

        override fun onPermissionRequestCanceled(request: PermissionRequest?) {
            val origin = request?.origin?.toString() ?: return
            _events.tryEmit(EngineEvent.PermissionCanceled(origin))
        }

        override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
            if (view == null || callback == null) return
            fullscreenCallback = callback
            val event = EngineEvent.EnterFullscreen(view) { endFullscreen() }
            if (_events.subscriptionCount.value == 0 || !_events.tryEmit(event)) endFullscreen()
        }

        override fun onHideCustomView() {
            fullscreenCallback = null
            _events.tryEmit(EngineEvent.ExitFullscreen)
        }

        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: android.webkit.ValueCallback<Array<Uri>>?,
            fileChooserParams: WebChromeClient.FileChooserParams?,
        ): Boolean {
            if (filePathCallback == null || fileChooserParams == null) return false
            val intent = try {
                fileChooserParams.createIntent()
            } catch (e: RuntimeException) {
                filePathCallback.onReceiveValue(null)
                return true
            }
            var answered = false
            val event = EngineEvent.FileChooserRequested(intent) { uris ->
                if (!answered) {
                    answered = true
                    filePathCallback.onReceiveValue(uris)
                }
            }
            if (_events.subscriptionCount.value == 0 || !_events.tryEmit(event)) filePathCallback.onReceiveValue(null)
            return true
        }

        override fun onGeolocationPermissionsShowPrompt(
            origin: String?,
            callback: GeolocationPermissions.Callback?,
        ) {
            if (origin == null || callback == null) return
            if (!origin.startsWith("https://")) {
                callback.invoke(origin, false, false)
                return
            }
            val event = EngineEvent.PermissionRequested(
                origin = origin,
                permissions = setOf(SitePermission.LOCATION),
                respond = { allow -> callback.invoke(origin, allow, false) },
            )
            if (_events.subscriptionCount.value == 0 || !_events.tryEmit(event)) callback.invoke(origin, false, false)
        }
    }

    private fun describeSslError(error: SslError?): String = when (error?.primaryError) {
        SslError.SSL_EXPIRED -> "o certificado expirou"
        SslError.SSL_IDMISMATCH -> "o certificado pertence a outro site"
        SslError.SSL_UNTRUSTED -> "a autoridade que emitiu o certificado não é confiável"
        SslError.SSL_NOTYETVALID -> "o certificado ainda não é válido"
        SslError.SSL_DATE_INVALID -> "a data do certificado é inválida"
        else -> "o certificado é inválido"
    }

    companion object {
        private var serviceWorkerFilterInstalled = false

        /** Pacote e versão do WebView do sistema, para exibir em Configurações. */
        fun engineDescription(context: Context): String? {
            val info = WebViewCompat.getCurrentWebViewPackage(context) ?: return null
            return "${info.packageName} ${info.versionName}"
        }

        /** Nome do perfil usado por todas as abas anônimas abertas ao mesmo tempo. */
        const val PRIVATE_PROFILE = "gab-anonimo"

        /** true quando o WebView do aparelho consegue isolar abas anônimas em um perfil separado. */
        fun supportsIsolatedPrivateTabs(): Boolean =
            WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)

        /**
         * Apaga cookies e armazenamento do perfil anônimo e, se nenhum WebView o estiver usando,
         * o próprio perfil (cache incluído). Chamar na thread principal.
         * Devolve false se o perfil ainda estava em uso e não pôde ser excluído.
         */
        fun wipePrivateProfile(): Boolean {
            if (!supportsIsolatedPrivateTabs()) return true
            val store = ProfileStore.getInstance()
            val existing = store.getProfile(PRIVATE_PROFILE) ?: return true
            existing.cookieManager.removeAllCookies(null)
            existing.webStorage.deleteAllData()
            return try {
                store.deleteProfile(PRIVATE_PROFILE)
                true
            } catch (e: IllegalStateException) {
                false
            }
        }

        /**
         * GabOne: apaga dados de navegação do perfil normal. Chamar na thread principal.
         * Senhas e favoritos do GabBrowser não ficam no WebView, então não são afetados.
         */
        fun clearBrowsingData(
            context: Context,
            cookies: Boolean,
            siteData: Boolean,
            cache: Boolean,
            onDone: () -> Unit,
        ) {
            if (siteData) android.webkit.WebStorage.getInstance().deleteAllData()
            if (cache) {
                // O cache é do processo do WebView; qualquer instância limpa tudo.
                WebView(context).apply {
                    clearCache(true)
                    destroy()
                }
            }
            if (cookies) {
                // A remoção é assíncrona: só avisa que terminou depois da confirmação do WebView.
                val manager = CookieManager.getInstance()
                manager.removeAllCookies {
                    manager.flush()
                    onDone()
                }
            } else {
                onDone()
            }
        }

        /** true quando o WebView do aparelho permite remover anúncios do YouTube antes de tocarem. */
        fun supportsFullYoutubeBlocking(): Boolean =
            WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)

        /**
         * Requisições feitas por service workers não passam pelo WebViewClient.
         * Este filtro global cobre esse caminho. Chamar na thread principal, depois de criar um WebView.
         */
        fun installServiceWorkerFilter(blocker: ContentBlocker) {
            if (serviceWorkerFilterInstalled) return
            val supported = WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_BASIC_USAGE) &&
                WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST)
            if (!supported) return
            ServiceWorkerControllerCompat.getInstance().setServiceWorkerClient(
                object : ServiceWorkerClientCompat() {
                    override fun shouldInterceptRequest(request: WebResourceRequest): WebResourceResponse? =
                        if (filterRequest(blocker, request, topHost = null, private = false) != null) blockedResponse() else null
                },
            )
            serviceWorkerFilterInstalled = true
        }

        private val FILTERED_SCHEMES = setOf("https", "http", "wss", "ws")

        private fun filterRequest(
            blocker: ContentBlocker,
            request: WebResourceRequest,
            topHost: String?,
            private: Boolean,
        ) = run {
            if (request.isForMainFrame) return@run null
            val uri: Uri = request.url ?: return@run null
            val scheme = uri.scheme?.lowercase() ?: return@run null
            if (scheme !in FILTERED_SCHEMES) return@run null
            val host = uri.host?.lowercase() ?: return@run null
            val category = blocker.evaluate(uri.toString(), host, topHost) ?: return@run null
            // Aba anônima: bloqueia, mas não grava nada nas estatísticas (seria rastro da navegação).
            if (!private) blocker.onBlocked(host, category, topHost)
            category
        }

        /** Resposta local e vazia: o servidor de anúncio nunca é contatado. */
        private fun blockedResponse(): WebResourceResponse = WebResourceResponse(
            "text/plain",
            "utf-8",
            403,
            "Blocked by GabClean",
            emptyMap(),
            ByteArrayInputStream(ByteArray(0)),
        )
    }
}
