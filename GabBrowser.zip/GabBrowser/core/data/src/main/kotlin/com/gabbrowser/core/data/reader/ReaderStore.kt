package com.gabbrowser.core.data.reader

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException

enum class BlockType { HEADING, PARAGRAPH, LIST_ITEM, QUOTE }

data class ReaderBlock(val type: BlockType, val text: String)

data class ReaderArticle(
    val title: String,
    val url: String,
    val byline: String,
    val blocks: List<ReaderBlock>,
    val savedAt: Long = 0L,
) {
    /** SHA-256 do endereço: nome de arquivo seguro e sem colisões entre artigos. */
    val id: String
        get() = java.security.MessageDigest.getInstance("SHA-256")
            .digest(url.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
            .take(32)

    /** Texto contínuo, para leitura em voz alta. */
    val plainText: String get() = (listOf(title) + blocks.map { it.text }).joinToString("\n\n")

    val wordCount: Int get() = blocks.sumOf { block -> block.text.split(' ').count { it.isNotBlank() } }
}

data class SavedArticle(val id: String, val title: String, val url: String, val savedAt: Long)

/**
 * GabReader: converte o resultado do script de leitura e guarda artigos para ler offline.
 * Os artigos salvos ficam como texto na pasta interna do app (sem imagens).
 */
class ReaderStore(context: Context) {

    private val dir = File(context.applicationContext.filesDir, "reader")
    private val _saved = MutableStateFlow<List<SavedArticle>>(emptyList())
    val saved: StateFlow<List<SavedArticle>> = _saved.asStateFlow()

    /** [raw] é o valor devolvido pelo WebView (uma string JSON contendo o JSON do artigo). */
    fun parse(raw: String?, url: String): ReaderArticle? {
        if (raw.isNullOrEmpty()) return null
        return try {
            val inner = JSONArray("[$raw]").optString(0)
            val json = JSONObject(inner)
            val blocks = json.optJSONArray("blocks") ?: JSONArray()
            val list = (0 until blocks.length()).mapNotNull { index ->
                val block = blocks.optJSONObject(index) ?: return@mapNotNull null
                val text = block.optString("x").trim()
                if (text.isEmpty()) return@mapNotNull null
                val type = when (block.optString("t")) {
                    "h" -> BlockType.HEADING
                    "li" -> BlockType.LIST_ITEM
                    "q" -> BlockType.QUOTE
                    else -> BlockType.PARAGRAPH
                }
                ReaderBlock(type, text)
            }
            if (list.count { it.type == BlockType.PARAGRAPH } < 2) return null
            ReaderArticle(json.optString("title").trim(), url, json.optString("byline").trim(), list)
        } catch (e: JSONException) {
            null
        }
    }

    suspend fun refresh() = withContext(Dispatchers.IO) {
        val files = dir.listFiles { file -> file.name.endsWith(".json") }.orEmpty()
        _saved.value = files.mapNotNull { file ->
            try {
                val json = JSONObject(file.readText())
                SavedArticle(
                    id = file.nameWithoutExtension,
                    title = json.optString("title"),
                    url = json.optString("url"),
                    savedAt = json.optLong("savedAt"),
                )
            } catch (e: IOException) {
                null
            } catch (e: JSONException) {
                null
            }
        }.sortedByDescending { it.savedAt }
    }

    suspend fun save(article: ReaderArticle) = withContext(Dispatchers.IO) {
        dir.mkdirs()
        val json = JSONObject()
            .put("title", article.title)
            .put("url", article.url)
            .put("byline", article.byline)
            .put("savedAt", System.currentTimeMillis())
            .put(
                "blocks",
                JSONArray().apply {
                    article.blocks.forEach { block ->
                        put(JSONObject().put("t", block.type.name).put("x", block.text))
                    }
                },
            )
        File(dir, "${article.id}.json").writeText(json.toString())
        refresh()
    }

    suspend fun load(id: String): ReaderArticle? = withContext(Dispatchers.IO) {
        val file = File(dir, "$id.json")
        if (!file.exists() || file.parentFile != dir) return@withContext null
        try {
            val json = JSONObject(file.readText())
            val blocks = json.optJSONArray("blocks") ?: JSONArray()
            ReaderArticle(
                title = json.optString("title"),
                url = json.optString("url"),
                byline = json.optString("byline"),
                blocks = (0 until blocks.length()).mapNotNull { index ->
                    val block = blocks.optJSONObject(index) ?: return@mapNotNull null
                    val type = BlockType.entries.firstOrNull { it.name == block.optString("t") } ?: BlockType.PARAGRAPH
                    ReaderBlock(type, block.optString("x"))
                },
                savedAt = json.optLong("savedAt"),
            )
        } catch (e: IOException) {
            null
        } catch (e: JSONException) {
            null
        }
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        val file = File(dir, "$id.json")
        if (file.parentFile == dir) file.delete()
        refresh()
    }
}
