package com.gabbrowser.core.data.downloads

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import com.gabbrowser.core.data.DownloadEntity
import com.gabbrowser.core.data.GabData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext

enum class DownloadStatus { PENDING, RUNNING, PAUSED, SUCCESSFUL, FAILED, MISSING }

data class DownloadItem(
    val id: Long,
    val fileName: String,
    val url: String,
    val mimeType: String?,
    val createdAt: Long,
    val status: DownloadStatus,
    val downloadedBytes: Long,
    val totalBytes: Long,
) {
    /** 0 a 1, ou null quando o servidor não informou o tamanho. */
    val progress: Float? get() = if (totalBytes > 0) (downloadedBytes.toFloat() / totalBytes).coerceIn(0f, 1f) else null
}

/** Pedido de download já analisado, para mostrar ao usuário antes de confirmar. */
data class DownloadRequest(
    val url: String,
    val fileName: String,
    val mimeType: String?,
    val sizeBytes: Long,
    val host: String,
    val userAgent: String,
    val cookies: String?,
    val isPrivate: Boolean,
) {
    /** Instaladores e scripts merecem um aviso a mais antes de baixar. */
    val isRisky: Boolean
        get() = RISKY_EXTENSIONS.any { fileName.lowercase().endsWith(it) } ||
            mimeType == "application/vnd.android.package-archive"

    companion object {
        private val RISKY_EXTENSIONS = listOf(
            ".apk", ".apks", ".apkm", ".xapk", ".aab", ".dex", ".exe", ".msi", ".bat", ".cmd", ".ps1", ".sh",
            ".jar", ".js", ".vbs", ".scr", ".html", ".htm", ".xhtml", ".svg",
        )
    }
}

sealed interface EnqueueResult {
    data class Started(val fileName: String) : EnqueueResult

    data class Failed(val reason: String) : EnqueueResult
}

/**
 * GabDownload: usa o gerenciador de downloads do Android, que continua baixando com o app
 * fechado, retoma sozinho depois de queda de rede e mostra o progresso na notificação.
 * O app guarda só a lista dos downloads que ele iniciou (exceto os de abas anônimas).
 */
class GabDownloads(context: Context) {

    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val dao = GabData.database(appContext).downloadDao()

    /** Lista com progresso atualizado a cada segundo enquanto alguém estiver observando. */
    val items: Flow<List<DownloadItem>> = combine(dao.all(), ticker()) { rows, _ -> withStatus(rows) }
        .flowOn(Dispatchers.IO)

    /**
     * Analisa um pedido vindo da página. Devolve null para endereços que não podem ser baixados
     * por aqui (blob:, data:), que são gerados pela própria página.
     */
    fun prepare(
        url: String,
        userAgent: String,
        contentDisposition: String?,
        mimeType: String?,
        contentLength: Long,
        cookies: String?,
        isPrivate: Boolean,
    ): DownloadRequest? {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase()
        if (scheme != "https" && scheme != "http") return null
        val secureUrl = if (scheme == "http") "https://" + url.substring(url.indexOf("://") + 3) else url
        val cleanMime = mimeType?.substringBefore(';')?.trim()?.takeIf { it.isNotEmpty() && it != "application/octet-stream" }
        val guessed = URLUtil.guessFileName(secureUrl, contentDisposition, cleanMime)
        return DownloadRequest(
            url = secureUrl,
            fileName = sanitize(guessed),
            mimeType = cleanMime ?: mimeFromName(guessed),
            sizeBytes = contentLength,
            host = uri.host.orEmpty(),
            userAgent = userAgent,
            cookies = cookies,
            isPrivate = isPrivate,
        )
    }

    suspend fun enqueue(request: DownloadRequest): EnqueueResult = withContext(Dispatchers.IO) {
        try {
            val dmRequest = DownloadManager.Request(Uri.parse(request.url)).apply {
                setTitle(request.fileName)
                setDescription(request.host)
                request.mimeType?.let { setMimeType(it) }
                if (!request.cookies.isNullOrEmpty()) addRequestHeader("Cookie", request.cookies)
                if (request.userAgent.isNotEmpty()) addRequestHeader("User-Agent", request.userAgent)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // Pasta Downloads pública: não precisa de permissão a partir do Android 10.
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, request.fileName)
                } else {
                    // Android 8 e 9: pasta do app, para não pedir permissão de armazenamento.
                    setDestinationInExternalFilesDir(appContext, Environment.DIRECTORY_DOWNLOADS, request.fileName)
                }
            }
            val id = manager.enqueue(dmRequest)
            if (!request.isPrivate) {
                dao.insert(
                    DownloadEntity(
                        id = id,
                        fileName = request.fileName,
                        url = request.url,
                        mimeType = request.mimeType,
                        createdAt = System.currentTimeMillis(),
                    ),
                )
            }
            EnqueueResult.Started(request.fileName)
        } catch (e: IllegalArgumentException) {
            EnqueueResult.Failed("endereço não aceito pelo gerenciador de downloads")
        } catch (e: IllegalStateException) {
            EnqueueResult.Failed("pasta de downloads indisponível")
        } catch (e: SecurityException) {
            EnqueueResult.Failed("o Android não permitiu salvar o arquivo")
        }
    }

    /** Cancela um download em andamento ou apaga o arquivo baixado. */
    suspend fun deleteFile(id: Long) = withContext(Dispatchers.IO) {
        manager.remove(id)
        dao.delete(id)
    }

    /** Tira da lista do GabBrowser, mantendo o arquivo no aparelho. */
    suspend fun forget(id: Long) = withContext(Dispatchers.IO) {
        dao.delete(id)
    }

    /** Intent para abrir o arquivo em outro app, ou null se ele não existe mais. */
    fun openIntent(item: DownloadItem): Intent? {
        val uri = manager.getUriForDownloadedFile(item.id) ?: return null
        val mime = manager.getMimeTypeForDownloadedFile(item.id) ?: item.mimeType ?: "*/*"
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    private fun withStatus(rows: List<DownloadEntity>): List<DownloadItem> {
        if (rows.isEmpty()) return emptyList()
        val info = HashMap<Long, Triple<DownloadStatus, Long, Long>>()
        val query = DownloadManager.Query().setFilterById(*rows.map { it.id }.toLongArray())
        manager.query(query)?.use { cursor ->
            while (cursor.moveToNext()) {
                info[cursor.long(DownloadManager.COLUMN_ID)] = Triple(
                    statusOf(cursor.int(DownloadManager.COLUMN_STATUS)),
                    cursor.long(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR),
                    cursor.long(DownloadManager.COLUMN_TOTAL_SIZE_BYTES),
                )
            }
        }
        return rows.map { row ->
            val (status, done, total) = info[row.id] ?: Triple(DownloadStatus.MISSING, 0L, 0L)
            DownloadItem(row.id, row.fileName, row.url, row.mimeType, row.createdAt, status, done, total)
        }
    }

    private fun statusOf(code: Int): DownloadStatus = when (code) {
        DownloadManager.STATUS_PENDING -> DownloadStatus.PENDING
        DownloadManager.STATUS_RUNNING -> DownloadStatus.RUNNING
        DownloadManager.STATUS_PAUSED -> DownloadStatus.PAUSED
        DownloadManager.STATUS_SUCCESSFUL -> DownloadStatus.SUCCESSFUL
        else -> DownloadStatus.FAILED
    }

    private fun Cursor.long(column: String): Long = getColumnIndex(column).let { if (it < 0) 0L else getLong(it) }

    private fun Cursor.int(column: String): Int = getColumnIndex(column).let { if (it < 0) 0 else getInt(it) }

    private fun ticker(): Flow<Unit> = flow {
        while (true) {
            emit(Unit)
            delay(1_000)
        }
    }

    private fun mimeFromName(name: String): String? {
        val extension = name.substringAfterLast('.', "").lowercase()
        if (extension.isEmpty()) return null
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
    }

    private fun sanitize(name: String): String {
        // \p{Cf} remove caracteres invisíveis de formatação, como o que inverte o texto
        // ("fatura\u202Efdp.apk" apareceria como "faturakpa.pdf").
        val cleaned = name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}\\p{Cf}]"), "_")
            .trim()
            .trimStart('.')
            .trimEnd('.', ' ')
        return cleaned.take(120).ifEmpty { "download" }
    }
}
