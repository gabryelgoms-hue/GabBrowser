package com.gabbrowser.core.data.gabclean

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Room
import com.gabbrowser.core.common.blocking.BlockCategory
import com.gabbrowser.core.common.blocking.BlockLevel
import com.gabbrowser.core.common.blocking.BlockRules
import com.gabbrowser.core.common.blocking.BlockerSnapshot
import com.gabbrowser.core.common.blocking.ContentBlocker
import com.gabbrowser.core.common.blocking.ContentScriptConfig
import com.gabbrowser.core.common.blocking.DomainList
import com.gabbrowser.core.common.blocking.FilterListParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

data class GabCleanSettings(
    val enabled: Boolean = true,
    val level: BlockLevel = BlockLevel.STANDARD,
    val youtube: Boolean = true,
    val extendedEnabled: Boolean = true,
    val exceptions: Set<String> = emptySet(),
    val extendedRuleCount: Int = 0,
    val extendedUpdatedAt: Long = 0L,
) {
    fun isException(host: String?): Boolean = BlockerSnapshot(exceptions = exceptions).isException(host)
}

data class HostCount(
    val host: String,
    val category: BlockCategory,
    val count: Long,
)

data class GabCleanStats(
    val ads: Long = 0,
    val trackers: Long = 0,
    val extended: Long = 0,
    val youtube: Long = 0,
    val topHosts: List<HostCount> = emptyList(),
) {
    val requests: Long get() = ads + trackers + extended
}

sealed interface ListUpdateResult {
    data class Success(val rules: Int) : ListUpdateResult

    data class Failure(val reason: String) : ListUpdateResult
}

private val Context.gabCleanStore: DataStore<Preferences> by preferencesDataStore(name = "gabclean_settings")

/**
 * Configurações, lista ampliada e estatísticas do GabClean.
 *
 * Também é o [ContentBlocker] usado pelo motor: [evaluate] lê um retrato imutável do estado,
 * então pode ser chamado das threads de rede do WebView sem travas.
 * Os bloqueios são somados em memória e gravados em lote a cada poucos segundos.
 */
class GabCleanRepository(
    context: Context,
    private val scope: CoroutineScope,
) : ContentBlocker {

    private val appContext = context.applicationContext
    private val store = appContext.gabCleanStore
    private val dao = Room.databaseBuilder(appContext, GabCleanDatabase::class.java, "gabclean.db")
        .addMigrations(GabCleanDatabase.MIGRATION_1_2)
        .build()
        .blockCountDao()
    private val listFile = File(File(appContext.filesDir, "gabclean"), "lista-ampliada.txt")

    @Volatile
    private var currentSettings = GabCleanSettings()

    @Volatile
    private var extendedList: DomainList? = null

    @Volatile
    private var snapshot = BlockerSnapshot()

    private val pending = ConcurrentHashMap<String, Long>()
    private val pendingDays = ConcurrentHashMap<String, Long>()
    private val pendingSites: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val knownSites: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val flushScheduled = AtomicBoolean(false)

    val settings: Flow<GabCleanSettings> = store.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map(::toSettings)

    val scriptConfig: Flow<ContentScriptConfig> = settings.map(::scriptConfigOf).distinctUntilChanged()

    val stats: Flow<GabCleanStats> = combine(dao.totals(), dao.top(limit = 5)) { totals, top ->
        fun total(category: BlockCategory): Long =
            totals.firstOrNull { it.category == category.id }?.total ?: 0L
        GabCleanStats(
            ads = total(BlockCategory.AD),
            trackers = total(BlockCategory.TRACKER),
            extended = total(BlockCategory.EXTENDED_LIST),
            youtube = total(BlockCategory.YOUTUBE_AD),
            topHosts = top.mapNotNull { row ->
                BlockCategory.fromId(row.category)?.let { HostCount(row.host, it, row.hits) }
            },
        )
    }

    init {
        scope.launch {
            settings.collect { applySettings(it) }
        }
        scope.launch(Dispatchers.IO) {
            loadSavedList()
            refreshListIfOld()
        }
    }

    fun currentScriptConfig(): ContentScriptConfig = scriptConfigOf(currentSettings)

    // ------------------------------------------------------------------ ContentBlocker

    override fun evaluate(url: String, host: String, topHost: String?): BlockCategory? =
        BlockRules.decide(snapshot, url, host, topHost)

    override fun shouldApplyCosmetics(topHost: String?): Boolean {
        val current = snapshot
        return current.enabled && !current.isException(topHost)
    }

    override fun onBlocked(host: String, category: BlockCategory, topHost: String?) {
        pendingDays.merge(LocalDate.now().toString(), 1L) { a, b -> a + b }
        if (topHost != null) {
            val site = topHost.lowercase().removePrefix("www.")
            if (knownSites.add(site)) pendingSites.add(site)
        }
        count(category, host)
    }

    override fun onYoutubeAdHandled() {
        count(BlockCategory.YOUTUBE_AD, "youtube.com")
    }

    // ------------------------------------------------------------------ Configurações

    suspend fun setEnabled(enabled: Boolean) = edit { it[KEY_ENABLED] = enabled }

    suspend fun setLevel(level: BlockLevel) = edit { it[KEY_LEVEL] = level.id }

    suspend fun setYoutube(enabled: Boolean) = edit { it[KEY_YOUTUBE] = enabled }

    suspend fun setExtendedEnabled(enabled: Boolean) = edit { it[KEY_EXTENDED_ENABLED] = enabled }

    /** [blocked] = false cria uma exceção: o GabClean deixa de agir nesse site. */
    suspend fun setBlockingOnSite(host: String, blocked: Boolean) {
        val normalized = host.lowercase().removePrefix("www.")
        if (normalized.isEmpty()) return
        edit { prefs ->
            val current = prefs[KEY_EXCEPTIONS].orEmpty()
            prefs[KEY_EXCEPTIONS] = if (blocked) {
                current.filterNot { it == normalized || normalized.endsWith(".$it") }.toSet()
            } else {
                current + normalized
            }
        }
    }

    suspend fun removeException(host: String) = edit { prefs ->
        prefs[KEY_EXCEPTIONS] = prefs[KEY_EXCEPTIONS].orEmpty() - host
    }

    // ------------------------------------------------------------------ Lista ampliada

    suspend fun updateExtendedList(): ListUpdateResult = withContext(Dispatchers.IO) {
        try {
            val connection = URL(EXTENDED_LIST_URL).openConnection() as HttpURLConnection
            try {
                connection.connectTimeout = 15_000
                connection.readTimeout = 30_000
                connection.setRequestProperty("User-Agent", "GabBrowser")
                val code = connection.responseCode
                if (code != HttpURLConnection.HTTP_OK) {
                    return@withContext ListUpdateResult.Failure("o servidor respondeu com o código $code")
                }
                val bytes = connection.inputStream.use { readLimited(it, MAX_LIST_BYTES) }
                    ?: return@withContext ListUpdateResult.Failure("o arquivo passou do limite de tamanho")
                val list = FilterListParser.parse(String(bytes, Charsets.UTF_8))
                if (list.blocked.size < MIN_RULES) {
                    return@withContext ListUpdateResult.Failure("o arquivo recebido não parece uma lista de filtros")
                }
                saveList(list)
                extendedList = list
                edit {
                    it[KEY_EXTENDED_COUNT] = list.blocked.size
                    it[KEY_EXTENDED_UPDATED] = System.currentTimeMillis()
                    it[KEY_EXTENDED_ENABLED] = true
                }
                ListUpdateResult.Success(list.blocked.size)
            } finally {
                connection.disconnect()
            }
        } catch (e: IOException) {
            ListUpdateResult.Failure("sem conexão ou servidor indisponível")
        }
    }

    /**
     * Quem já baixou a lista ampliada recebe a versão nova uma vez por semana, ao abrir o app.
     * Sem lista baixada, nada é buscado (a primeira vez é sempre por escolha do usuário).
     */
    private suspend fun refreshListIfOld() {
        val current = settings.first()
        if (current.extendedRuleCount <= 0) return
        val age = System.currentTimeMillis() - current.extendedUpdatedAt
        if (age < LIST_MAX_AGE_MS) return
        delay(15_000) // depois que o app terminou de abrir
        updateExtendedList()
    }

    suspend fun removeExtendedList() {
        withContext(Dispatchers.IO) { listFile.delete() }
        extendedList = null
        edit {
            it[KEY_EXTENDED_COUNT] = 0
            it[KEY_EXTENDED_UPDATED] = 0L
        }
    }

    // ------------------------------------------------------------------ Estatísticas

    suspend fun resetStats() {
        pending.clear()
        pendingDays.clear()
        pendingSites.clear()
        knownSites.clear()
        withContext(Dispatchers.IO) {
            dao.clear()
            dao.clearDays()
            dao.clearSites()
        }
    }

    /** "Sites protegidos" funciona como uma lista de sites visitados: o GabOne apaga junto com o histórico. */
    suspend fun clearProtectedSites() {
        pendingSites.clear()
        knownSites.clear()
        withContext(Dispatchers.IO) { dao.clearSites() }
    }

    /** Bloqueios por dia nos últimos [days] dias, do mais antigo para hoje (dias sem bloqueio = 0). */
    fun dailyBlocks(days: Int = 7): Flow<List<Pair<LocalDate, Long>>> {
        val today = LocalDate.now()
        val first = today.minusDays((days - 1).toLong())
        return dao.daysSince(first.toString()).map { rows ->
            val byDay = rows.associate { it.day to it.hits }
            (0 until days).map { offset ->
                val day = first.plusDays(offset.toLong())
                day to (byDay[day.toString()] ?: 0L)
            }
        }
    }

    val protectedSites: Flow<Int> = dao.protectedSiteCount()

    /** Grava o que ainda está em memória. Chamado quando o app vai para segundo plano. */
    fun flushSoon() {
        scope.launch { flush() }
    }

    private fun count(category: BlockCategory, host: String) {
        pending.merge("${category.id}|$host", 1L) { a, b -> a + b }
        if (flushScheduled.compareAndSet(false, true)) {
            scope.launch {
                delay(FLUSH_DELAY_MS)
                flushScheduled.set(false)
                flush()
            }
        }
    }

    private suspend fun flush() = withContext(Dispatchers.IO) {
        try {
            flushPending()
        } catch (e: android.database.SQLException) {
            // Disco cheio ou banco indisponível: as contagens deste lote se perdem, o app segue.
        }
    }

    private suspend fun flushPending() {
        for (day in pendingDays.keys.toList()) {
            val amount = pendingDays.remove(day) ?: continue
            dao.addDay(day, amount)
        }
        for (site in pendingSites.toList()) {
            pendingSites.remove(site)
            dao.insertSite(ProtectedSiteEntity(site, System.currentTimeMillis()))
        }
        for (key in pending.keys.toList()) {
            val amount = pending.remove(key) ?: continue
            val category = BlockCategory.fromId(key.substringBefore('|')) ?: continue
            dao.add(key.substringAfter('|'), category.id, amount)
        }
    }

    // ------------------------------------------------------------------ Interno

    private suspend fun edit(block: (MutablePreferences) -> Unit) {
        val saved = store.edit { block(it) }
        applySettings(toSettings(saved))
    }

    private fun applySettings(settings: GabCleanSettings) {
        currentSettings = settings
        rebuildSnapshot()
    }

    @Synchronized
    private fun rebuildSnapshot() {
        val s = currentSettings
        snapshot = BlockerSnapshot(
            enabled = s.enabled,
            level = s.level,
            youtube = s.youtube,
            exceptions = s.exceptions,
            extended = if (s.extendedEnabled) extendedList else null,
        )
    }

    private fun loadSavedList() {
        if (!listFile.exists()) return
        val list = try {
            FilterListParser.parse(listFile.readText())
        } catch (e: IOException) {
            return
        }
        if (list.blocked.isEmpty()) return
        extendedList = list
        rebuildSnapshot()
    }

    private fun saveList(list: DomainList) {
        val dir = listFile.parentFile ?: return
        dir.mkdirs()
        val temp = File(dir, "lista-ampliada.tmp")
        temp.writeText(list.toFilterText())
        if (!temp.renameTo(listFile)) {
            listFile.delete()
            temp.renameTo(listFile)
        }
    }

    private fun readLimited(input: InputStream, max: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            if (total > max) return null
            out.write(buffer, 0, read)
        }
        return out.toByteArray()
    }

    private fun scriptConfigOf(settings: GabCleanSettings) = ContentScriptConfig(
        youtube = settings.enabled && settings.youtube &&
            settings.exceptions.none { it == "youtube.com" || it.endsWith(".youtube.com") },
    )

    private fun toSettings(prefs: Preferences) = GabCleanSettings(
        enabled = prefs[KEY_ENABLED] ?: true,
        level = BlockLevel.fromId(prefs[KEY_LEVEL]),
        youtube = prefs[KEY_YOUTUBE] ?: true,
        extendedEnabled = prefs[KEY_EXTENDED_ENABLED] ?: true,
        exceptions = prefs[KEY_EXCEPTIONS].orEmpty(),
        extendedRuleCount = prefs[KEY_EXTENDED_COUNT] ?: 0,
        extendedUpdatedAt = prefs[KEY_EXTENDED_UPDATED] ?: 0L,
    )

    companion object {
        /** AdGuard DNS filter: anúncios e rastreadores, mantido pela AdGuard e pensado para quebrar pouco. */
        const val EXTENDED_LIST_URL = "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt"
        const val EXTENDED_LIST_NAME = "AdGuard DNS filter"

        private const val MAX_LIST_BYTES = 8 * 1024 * 1024
        private const val MIN_RULES = 1_000
        private const val FLUSH_DELAY_MS = 3_000L
        private const val LIST_MAX_AGE_MS = 7L * 24 * 60 * 60 * 1000

        private val KEY_ENABLED = booleanPreferencesKey("enabled")
        private val KEY_LEVEL = stringPreferencesKey("level")
        private val KEY_YOUTUBE = booleanPreferencesKey("youtube")
        private val KEY_EXTENDED_ENABLED = booleanPreferencesKey("extended_enabled")
        private val KEY_EXCEPTIONS = stringSetPreferencesKey("exceptions")
        private val KEY_EXTENDED_COUNT = intPreferencesKey("extended_count")
        private val KEY_EXTENDED_UPDATED = longPreferencesKey("extended_updated")
    }
}
