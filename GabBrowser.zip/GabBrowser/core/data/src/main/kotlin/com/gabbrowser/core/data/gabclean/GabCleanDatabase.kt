package com.gabbrowser.core.data.gabclean

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

/** Quantas vezes cada domínio foi bloqueado, por motivo. Fica só no aparelho. */
@Entity(tableName = "block_counts", primaryKeys = ["host", "category"])
data class BlockCountEntity(
    val host: String,
    val category: String,
    val hits: Long,
)

/** Bloqueios por dia (dia no formato 2026-11-11), para o gráfico do GabShield. */
@Entity(tableName = "daily_blocks")
data class DailyBlockEntity(
    @PrimaryKey val day: String,
    val hits: Long,
)

/** Sites em que o GabClean bloqueou algo pelo menos uma vez. */
@Entity(tableName = "protected_sites")
data class ProtectedSiteEntity(
    @PrimaryKey val host: String,
    val firstSeen: Long,
)

data class CategoryTotal(
    val category: String,
    val total: Long,
)

@Dao
abstract class BlockCountDao {

    @Query("UPDATE block_counts SET hits = hits + :amount WHERE host = :host AND category = :category")
    abstract suspend fun increment(host: String, category: String, amount: Long): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insert(entity: BlockCountEntity): Long

    @Transaction
    open suspend fun add(host: String, category: String, amount: Long) {
        if (increment(host, category, amount) == 0) {
            insert(BlockCountEntity(host = host, category = category, hits = amount))
        }
    }

    @Query("SELECT category, SUM(hits) AS total FROM block_counts GROUP BY category")
    abstract fun totals(): Flow<List<CategoryTotal>>

    @Query("SELECT * FROM block_counts WHERE category != 'youtube' ORDER BY hits DESC LIMIT :limit")
    abstract fun top(limit: Int): Flow<List<BlockCountEntity>>

    @Query("DELETE FROM block_counts")
    abstract suspend fun clear()

    @Query("UPDATE daily_blocks SET hits = hits + :amount WHERE day = :day")
    abstract suspend fun incrementDay(day: String, amount: Long): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insertDay(entity: DailyBlockEntity): Long

    @Transaction
    open suspend fun addDay(day: String, amount: Long) {
        if (incrementDay(day, amount) == 0) insertDay(DailyBlockEntity(day, amount))
    }

    @Query("SELECT * FROM daily_blocks WHERE day >= :fromDay ORDER BY day")
    abstract fun daysSince(fromDay: String): Flow<List<DailyBlockEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insertSite(entity: ProtectedSiteEntity): Long

    @Query("SELECT COUNT(*) FROM protected_sites")
    abstract fun protectedSiteCount(): Flow<Int>

    @Query("DELETE FROM daily_blocks")
    abstract suspend fun clearDays()

    @Query("DELETE FROM protected_sites")
    abstract suspend fun clearSites()
}

/** Banco separado do histórico, para o GabClean não exigir migração do banco principal. */
@Database(
    entities = [BlockCountEntity::class, DailyBlockEntity::class, ProtectedSiteEntity::class],
    version = 2,
    exportSchema = false,
)
abstract class GabCleanDatabase : RoomDatabase() {
    abstract fun blockCountDao(): BlockCountDao

    companion object {
        /** 0.3 → 0.4: tabelas novas para o GabShield; as contagens antigas são mantidas. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `daily_blocks` (" +
                        "`day` TEXT NOT NULL, `hits` INTEGER NOT NULL, PRIMARY KEY(`day`))",
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `protected_sites` (" +
                        "`host` TEXT NOT NULL, `firstSeen` INTEGER NOT NULL, PRIMARY KEY(`host`))",
                )
            }
        }
    }
}
