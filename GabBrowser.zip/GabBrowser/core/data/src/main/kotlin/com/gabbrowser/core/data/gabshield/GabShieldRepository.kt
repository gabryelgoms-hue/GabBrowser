package com.gabbrowser.core.data.gabshield

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.gabbrowser.core.common.blocking.BlockLevel
import com.gabbrowser.core.common.security.NavigationGuard
import com.gabbrowser.core.common.security.SitePermission
import com.gabbrowser.core.common.security.SuspicionAnalyzer
import com.gabbrowser.core.common.security.SuspicionReport
import com.gabbrowser.core.data.gabclean.GabCleanRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** Padrão e Avançada ajustam o GabClean junto; Personalizada deixa cada opção como o usuário escolher. */
enum class ShieldLevel(val id: String, val label: String) {
    STANDARD("standard", "Padrão"),
    ADVANCED("advanced", "Avançada"),
    CUSTOM("custom", "Personalizada");

    companion object {
        fun fromId(id: String?): ShieldLevel = entries.firstOrNull { it.id == id } ?: STANDARD
    }
}

data class PermissionDecision(
    val origin: String,
    val permission: SitePermission,
    val allowed: Boolean,
)

data class GabShieldSettings(
    val level: ShieldLevel = ShieldLevel.STANDARD,
    val phishingAlerts: Boolean = true,
    val trustedHosts: Set<String> = emptySet(),
    val httpHosts: Set<String> = emptySet(),
    val permissions: List<PermissionDecision> = emptyList(),
    val warningsShown: Long = 0,
    val safeBrowsingHits: Long = 0,
) {
    val suspiciousAttempts: Long get() = warningsShown + safeBrowsingHits
}

private val Context.gabShieldStore: DataStore<Preferences> by preferencesDataStore(name = "gabshield_settings")

/**
 * GabShield: alertas de golpe, exceções de HTTPS e permissões por site.
 * Tudo fica no aparelho; a análise de endereços é local ([SuspicionAnalyzer]).
 */
class GabShieldRepository(
    context: Context,
    private val gabClean: GabCleanRepository,
    private val scope: CoroutineScope,
) : NavigationGuard {

    private val store = context.applicationContext.gabShieldStore

    @Volatile
    private var current = GabShieldSettings()

    /** Decisões tomadas em abas anônimas: valem só até o app fechar e nunca são gravadas. */
    private val sessionTrusted: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val sessionHttp: MutableSet<String> = ConcurrentHashMap.newKeySet()

    val settings: Flow<GabShieldSettings> = store.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map(::toSettings)

    init {
        scope.launch { settings.collect { current = it } }
    }

    // ------------------------------------------------------------------ NavigationGuard

    override fun inspect(host: String, private: Boolean): SuspicionReport {
        val normalized = normalize(host)
        val settings = current
        if (!settings.phishingAlerts || normalized in settings.trustedHosts || (private && normalized in sessionTrusted)) {
            return SuspicionReport.SAFE
        }
        return SuspicionAnalyzer.analyze(normalized)
    }

    override fun isHttpAllowed(host: String, private: Boolean): Boolean =
        normalize(host).let { it in current.httpHosts || (private && it in sessionHttp) }

    /** Chamado quando a última aba anônima fecha: esquece as decisões tomadas nela. */
    fun clearPrivateSession() {
        sessionTrusted.clear()
        sessionHttp.clear()
    }

    override fun onWarningShown(host: String) {
        scope.launch { edit { it[KEY_WARNINGS] = (it[KEY_WARNINGS] ?: 0L) + 1 } }
    }

    override fun onSafeBrowsingHit(host: String) {
        scope.launch { edit { it[KEY_SAFE_BROWSING] = (it[KEY_SAFE_BROWSING] ?: 0L) + 1 } }
    }

    // ------------------------------------------------------------------ Ações do usuário

    suspend fun setLevel(level: ShieldLevel) {
        edit { it[KEY_LEVEL] = level.id }
        when (level) {
            ShieldLevel.STANDARD -> {
                gabClean.setEnabled(true)
                gabClean.setLevel(BlockLevel.STANDARD)
                edit { it[KEY_PHISHING] = true }
            }

            ShieldLevel.ADVANCED -> {
                gabClean.setEnabled(true)
                gabClean.setLevel(BlockLevel.STRICT)
                edit { it[KEY_PHISHING] = true }
            }

            ShieldLevel.CUSTOM -> Unit
        }
    }

    suspend fun setPhishingAlerts(enabled: Boolean) = edit {
        it[KEY_PHISHING] = enabled
        it[KEY_LEVEL] = ShieldLevel.CUSTOM.id
    }

    /** O usuário viu o aviso e decidiu continuar: o site deixa de ser avisado. */
    suspend fun trust(host: String, private: Boolean = false) {
        if (private) sessionTrusted.add(normalize(host)) else editSet(KEY_TRUSTED) { it + normalize(host) }
    }

    suspend fun untrust(host: String) = editSet(KEY_TRUSTED) { it - host }

    suspend fun allowHttp(host: String, private: Boolean = false) {
        if (private) sessionHttp.add(normalize(host)) else editSet(KEY_HTTP) { it + normalize(host) }
    }

    suspend fun disallowHttp(host: String) = editSet(KEY_HTTP) { it - host }

    /** Decisão gravada para o site, ou null se ainda não perguntado. */
    fun decisionFor(origin: String, permission: SitePermission): Boolean? =
        current.permissions.firstOrNull { it.origin == normalizeOrigin(origin) && it.permission == permission }?.allowed

    suspend fun remember(origin: String, permissions: Set<SitePermission>, allowed: Boolean) {
        val key = normalizeOrigin(origin)
        editSet(KEY_PERMISSIONS) { entries ->
            val others = entries.filterNot { entry ->
                val parts = entry.split(SEPARATOR)
                parts.getOrNull(0) == key && permissions.any { it.id == parts.getOrNull(1) }
            }.toSet()
            others + permissions.map { listOf(key, it.id, if (allowed) "allow" else "block").joinToString(SEPARATOR) }
        }
    }

    suspend fun forgetPermissions(origin: String) {
        val key = normalizeOrigin(origin)
        editSet(KEY_PERMISSIONS) { entries -> entries.filterNot { it.split(SEPARATOR).getOrNull(0) == key }.toSet() }
    }

    fun permissionsFor(origin: String): List<PermissionDecision> =
        current.permissions.filter { it.origin == normalizeOrigin(origin) }

    // ------------------------------------------------------------------ Interno

    private suspend fun edit(block: (MutablePreferences) -> Unit) {
        val saved = store.edit { block(it) }
        current = toSettings(saved)
    }

    private suspend fun editSet(key: Preferences.Key<Set<String>>, transform: (Set<String>) -> Set<String>) =
        edit { it[key] = transform(it[key].orEmpty()) }

    private fun normalize(host: String) = host.lowercase().removePrefix("www.")

    /** "https://meet.google.com:443/" → "https://meet.google.com" */
    private fun normalizeOrigin(origin: String): String = origin.trimEnd('/').removeSuffix(":443").lowercase()

    private fun toSettings(prefs: Preferences) = GabShieldSettings(
        level = ShieldLevel.fromId(prefs[KEY_LEVEL]),
        phishingAlerts = prefs[KEY_PHISHING] ?: true,
        trustedHosts = prefs[KEY_TRUSTED].orEmpty(),
        httpHosts = prefs[KEY_HTTP].orEmpty(),
        permissions = prefs[KEY_PERMISSIONS].orEmpty().mapNotNull { entry ->
            val parts = entry.split(SEPARATOR)
            val permission = parts.getOrNull(1)?.let { SitePermission.fromId(it) } ?: return@mapNotNull null
            PermissionDecision(parts[0], permission, parts.getOrNull(2) == "allow")
        }.sortedBy { it.origin },
        warningsShown = prefs[KEY_WARNINGS] ?: 0L,
        safeBrowsingHits = prefs[KEY_SAFE_BROWSING] ?: 0L,
    )

    private companion object {
        const val SEPARATOR = "|"
        val KEY_LEVEL = stringPreferencesKey("level")
        val KEY_PHISHING = booleanPreferencesKey("phishing_alerts")
        val KEY_TRUSTED = stringSetPreferencesKey("trusted_hosts")
        val KEY_HTTP = stringSetPreferencesKey("http_hosts")
        val KEY_PERMISSIONS = stringSetPreferencesKey("permissions")
        val KEY_WARNINGS = longPreferencesKey("warnings_shown")
        val KEY_SAFE_BROWSING = longPreferencesKey("safe_browsing_hits")
    }
}
