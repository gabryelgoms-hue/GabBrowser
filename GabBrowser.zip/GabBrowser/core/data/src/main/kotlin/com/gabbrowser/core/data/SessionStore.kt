package com.gabbrowser.core.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import java.io.IOException

data class SavedTab(
    val url: String,
    val title: String,
    val group: String? = null,
)

data class SavedSession(
    val tabs: List<SavedTab>,
    val selectedIndex: Int,
)

private val Context.sessionStore: DataStore<Preferences> by preferencesDataStore(name = "gab_session")

/**
 * Abas normais abertas, para reabrir depois de fechar o app ou de um encerramento inesperado.
 * Abas anônimas nunca são gravadas.
 */
class SessionStore(context: Context) {

    private val store = context.applicationContext.sessionStore

    suspend fun load(): SavedSession {
        val prefs = store.data
            .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
            .first()
        val tabs = prefs[KEY_TABS].orEmpty()
            .lineSequence()
            .mapNotNull(::decode)
            .toList()
        return SavedSession(tabs, (prefs[KEY_SELECTED] ?: 0).coerceIn(0, (tabs.size - 1).coerceAtLeast(0)))
    }

    suspend fun save(session: SavedSession) {
        store.edit { prefs ->
            prefs[KEY_TABS] = session.tabs.joinToString("\n", transform = ::encode)
            prefs[KEY_SELECTED] = session.selectedIndex
        }
    }

    private fun encode(tab: SavedTab): String =
        listOf(tab.url, tab.title, tab.group.orEmpty()).joinToString(SEPARATOR) { clean(it) }

    private fun decode(line: String): SavedTab? {
        val parts = line.split(SEPARATOR)
        val url = parts.getOrNull(0)?.takeIf { it.startsWith("https://") } ?: return null
        return SavedTab(
            url = url,
            title = parts.getOrNull(1).orEmpty(),
            group = parts.getOrNull(2)?.takeIf { it.isNotEmpty() },
        )
    }

    private fun clean(value: String): String = value.replace('\n', ' ').replace('\t', ' ').replace('\r', ' ')

    private companion object {
        const val SEPARATOR = "\t"
        val KEY_TABS = stringPreferencesKey("tabs")
        val KEY_SELECTED = intPreferencesKey("selected")
    }
}
