package com.gabbrowser.core.data.passwords

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.gabbrowser.core.data.security.VaultCrypto
import com.gabbrowser.core.data.security.VaultDecrypt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * A senha fica só no campo [secret], cifrada (ver [VaultCrypto]); [fingerprint] é um HMAC para comparar sem decifrar.
 * Usuário e site ficam em claro para listar.
 */
@Entity(tableName = "credentials", indices = [Index(value = ["origin", "username"], unique = true)])
data class CredentialEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val origin: String,
    val username: String,
    val secret: String,
    val fingerprint: String,
    val createdAt: Long,
    val updatedAt: Long,
)

/** O que pode aparecer na tela sem autenticação: nunca a senha. */
data class CredentialInfo(
    val id: Long,
    val origin: String,
    val username: String,
    val updatedAt: Long,
)

@Dao
interface CredentialDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CredentialEntity): Long

    @Query("SELECT id, origin, username, updatedAt FROM credentials ORDER BY origin, username")
    fun all(): Flow<List<CredentialInfo>>

    @Query("SELECT id, origin, username, updatedAt FROM credentials WHERE origin = :origin ORDER BY updatedAt DESC")
    suspend fun forOrigin(origin: String): List<CredentialInfo>

    @Query("SELECT * FROM credentials WHERE id = :id")
    suspend fun byId(id: Long): CredentialEntity?

    @Query("SELECT * FROM credentials WHERE origin = :origin AND username = :username")
    suspend fun find(origin: String, username: String): CredentialEntity?

    @Query("DELETE FROM credentials WHERE id = :id")
    suspend fun delete(id: Long)
}

@Database(entities = [CredentialEntity::class], version = 1, exportSchema = false)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun credentialDao(): CredentialDao
}

data class VaultSettings(
    val offerToSave: Boolean = true,
    val neverSaveOrigins: Set<String> = emptySet(),
)

sealed interface SaveCheck {
    /** Já existe exatamente esta senha: nada a perguntar. */
    data object AlreadySaved : SaveCheck

    data object NeverForThisSite : SaveCheck

    data object Disabled : SaveCheck

    /** Perguntar; [isUpdate] = já existe login com esse usuário e a senha mudou. */
    data class Ask(val isUpdate: Boolean) : SaveCheck
}

private val Context.vaultStore: DataStore<Preferences> by preferencesDataStore(name = "vault_settings")

/**
 * Senhas salvas. Salvar é opcional e sempre perguntado; ver ou preencher exige a digital, o rosto ou o PIN
 * do aparelho (feito pela tela, antes de chamar [reveal]). Nada é sincronizado nem sai do aparelho.
 */
class PasswordVault(context: Context) {

    private val appContext = context.applicationContext
    private val dao = Room.databaseBuilder(appContext, VaultDatabase::class.java, "vault.db").build().credentialDao()
    private val store = appContext.vaultStore

    val credentials: Flow<List<CredentialInfo>> = dao.all()

    val settings: Flow<VaultSettings> = store.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { prefs ->
            VaultSettings(
                offerToSave = prefs[KEY_OFFER] ?: true,
                neverSaveOrigins = prefs[KEY_NEVER].orEmpty(),
            )
        }

    suspend fun setOfferToSave(enabled: Boolean) {
        store.edit { it[KEY_OFFER] = enabled }
    }

    suspend fun neverSaveFor(origin: String) {
        store.edit { it[KEY_NEVER] = it[KEY_NEVER].orEmpty() + normalizeOrigin(origin) }
    }

    suspend fun allowSavingFor(origin: String) {
        store.edit { it[KEY_NEVER] = it[KEY_NEVER].orEmpty() - normalizeOrigin(origin) }
    }

    suspend fun check(origin: String, username: String, password: String, settings: VaultSettings): SaveCheck {
        val key = normalizeOrigin(origin)
        if (!settings.offerToSave) return SaveCheck.Disabled
        if (key in settings.neverSaveOrigins) return SaveCheck.NeverForThisSite
        val existing = dao.find(key, username) ?: return SaveCheck.Ask(isUpdate = false)
        // Compara pela impressão (HMAC): a senha salva nunca é decifrada sem autenticação.
        val print = withContext(Dispatchers.Default) { VaultCrypto.fingerprint(key, username, password) }
        return if (print != null && print == existing.fingerprint) SaveCheck.AlreadySaved else SaveCheck.Ask(isUpdate = true)
    }

    /** Devolve false se o Keystore não conseguir cifrar (a senha não é gravada em texto puro nunca). */
    suspend fun save(origin: String, username: String, password: String): Boolean {
        val key = normalizeOrigin(origin)
        val secret = withContext(Dispatchers.Default) { VaultCrypto.encrypt(password) } ?: return false
        val print = withContext(Dispatchers.Default) { VaultCrypto.fingerprint(key, username, password) } ?: return false
        val now = System.currentTimeMillis()
        val existing = dao.find(key, username)
        dao.upsert(
            CredentialEntity(
                id = existing?.id ?: 0,
                origin = key,
                username = username,
                secret = secret,
                fingerprint = print,
                createdAt = existing?.createdAt ?: now,
                updatedAt = now,
            ),
        )
        return true
    }

    suspend fun forOrigin(origin: String): List<CredentialInfo> = dao.forOrigin(normalizeOrigin(origin))

    /**
     * Só funciona até 30 s depois de o usuário se autenticar: a exigência é do próprio Keystore.
     * Sem autenticação recente, devolve [VaultDecrypt.NeedsAuthentication].
     */
    suspend fun reveal(id: Long): VaultDecrypt {
        val entity = dao.byId(id) ?: return VaultDecrypt.Failed
        return withContext(Dispatchers.Default) { VaultCrypto.decrypt(entity.secret) }
    }

    suspend fun delete(id: Long) = dao.delete(id)

    companion object {
        private val KEY_OFFER = booleanPreferencesKey("offer_to_save")
        private val KEY_NEVER = stringSetPreferencesKey("never_save_origins")

        /** "https://Contas.Exemplo.com:443/" → "https://contas.exemplo.com" (mesma regra para salvar e preencher). */
        fun normalizeOrigin(origin: String): String {
            val uri = android.net.Uri.parse(origin.trim())
            val scheme = uri.scheme?.lowercase() ?: return origin.trim().lowercase()
            val host = uri.host?.lowercase() ?: return origin.trim().lowercase()
            val port = uri.port
            val defaultPort = (scheme == "https" && port == 443) || (scheme == "http" && port == 80)
            return if (port == -1 || defaultPort) "$scheme://$host" else "$scheme://$host:$port"
        }
    }
}
