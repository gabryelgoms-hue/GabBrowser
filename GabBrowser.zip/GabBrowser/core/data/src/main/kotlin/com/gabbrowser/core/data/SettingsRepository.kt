package com.gabbrowser.core.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.gabbrowser.core.common.SearchEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ThemeMode(val id: String, val displayName: String) {
    SYSTEM("system", "Seguir o sistema"),
    LIGHT("light", "Claro"),
    DARK("dark", "Escuro");

    companion object {
        fun fromId(id: String?): ThemeMode = entries.firstOrNull { it.id == id } ?: SYSTEM
    }
}

/** Ações do GabOne. Senhas e favoritos não existem aqui de propósito: nunca são apagados por ele. */
enum class CleanAction(val id: String, val label: String, val detail: String) {
    HISTORY("history", "Histórico", "Páginas visitadas e \"Mais acessados\""),
    COOKIES("cookies", "Cookies e logins", "Sai das contas nos sites"),
    SITE_DATA("site_data", "Dados de sites", "Armazenamento local e bancos de dados dos sites"),
    CACHE("cache", "Cache", "Arquivos temporários; os sites carregam um pouco mais devagar na próxima vez"),
    CLOSE_TABS("close_tabs", "Fechar todas as abas", "Normais e anônimas"),
    OPEN_PRIVATE("open_private", "Abrir aba anônima depois", "Continua navegando sem deixar rastro"),
    ;

    companion object {
        val DEFAULT: Set<CleanAction> = setOf(HISTORY, COOKIES, SITE_DATA, CACHE, CLOSE_TABS)

        fun fromIds(ids: Set<String>?): Set<CleanAction> =
            if (ids == null) DEFAULT else entries.filter { it.id in ids }.toSet()
    }
}

data class UserSettings(
    val searchEngine: SearchEngine = SearchEngine.GOOGLE,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    /** GabSaver: não baixar imagens das páginas. */
    val saverNoImages: Boolean = false,
    /** GabSaver: manter menos abas carregadas (menos memória e bateria). */
    val saverLowMemory: Boolean = false,
    val cleanActions: Set<CleanAction> = CleanAction.DEFAULT,
)

private val Context.gabDataStore: DataStore<Preferences> by preferencesDataStore(name = "gab_settings")

class SettingsRepository(context: Context) {

    private val store = context.applicationContext.gabDataStore

    val settings: Flow<UserSettings> = store.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs ->
            UserSettings(
                searchEngine = SearchEngine.fromId(prefs[KEY_SEARCH_ENGINE]),
                themeMode = ThemeMode.fromId(prefs[KEY_THEME]),
                saverNoImages = prefs[KEY_SAVER_IMAGES] ?: false,
                saverLowMemory = prefs[KEY_SAVER_MEMORY] ?: false,
                cleanActions = CleanAction.fromIds(prefs[KEY_CLEAN_ACTIONS]),
            )
        }

    suspend fun setSearchEngine(engine: SearchEngine) {
        store.edit { it[KEY_SEARCH_ENGINE] = engine.id }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        store.edit { it[KEY_THEME] = mode.id }
    }

    suspend fun setSaverNoImages(enabled: Boolean) {
        store.edit { it[KEY_SAVER_IMAGES] = enabled }
    }

    suspend fun setSaverLowMemory(enabled: Boolean) {
        store.edit { it[KEY_SAVER_MEMORY] = enabled }
    }

    suspend fun setCleanActions(actions: Set<CleanAction>) {
        store.edit { prefs -> prefs[KEY_CLEAN_ACTIONS] = actions.map { it.id }.toSet() }
    }

    private companion object {
        val KEY_SAVER_IMAGES = booleanPreferencesKey("saver_no_images")
        val KEY_SAVER_MEMORY = booleanPreferencesKey("saver_low_memory")
        val KEY_CLEAN_ACTIONS = stringSetPreferencesKey("gabone_actions")
        val KEY_SEARCH_ENGINE = stringPreferencesKey("search_engine")
        val KEY_THEME = stringPreferencesKey("theme_mode")
    }
}
