package com.gabbrowser.core.data.security

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.security.keystore.UserNotAuthenticatedException
import android.util.Base64
import java.security.GeneralSecurityException
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.MGF1ParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource

sealed interface VaultDecrypt {
    data class Success(val value: String) : VaultDecrypt

    /** O usuário não se autenticou nos últimos segundos: pedir a digital/PIN e tentar de novo. */
    data object NeedsAuthentication : VaultDecrypt

    data object Failed : VaultDecrypt
}

/**
 * Criptografia do cofre de senhas, com autenticação exigida pelo próprio Keystore:
 *
 * - Cada senha é cifrada com uma chave AES nova (AES-256-GCM).
 * - Essa chave AES é embrulhada com a chave pública RSA do cofre. Salvar não precisa de autenticação.
 * - A chave privada RSA fica no Android Keystore e só pode ser usada até 30 s depois de o usuário
 *   se autenticar (digital, rosto forte ou PIN/padrão/senha do aparelho) e com o aparelho desbloqueado.
 *   Nem um bug no app consegue decifrar senhas sem essa autenticação recente.
 * - Para saber se uma senha já está salva sem decifrar nada, guarda-se um HMAC dela (chave HMAC separada).
 */
object VaultCrypto {

    private const val KEYSTORE = "AndroidKeyStore"
    private const val RSA_ALIAS = "gabbrowser_vault_rsa"
    private const val HMAC_ALIAS = "gabbrowser_vault_hmac"
    private const val AUTH_SECONDS = 30
    private const val RSA = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding"
    private const val AES = "AES/GCM/NoPadding"

    /** O Keystore do Android aceita OAEP com SHA-256, mas o MGF1 precisa ser SHA-1. */
    private val OAEP = OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA1, PSource.PSpecified.DEFAULT)

    private fun keyStore(): KeyStore = KeyStore.getInstance(KEYSTORE).apply { load(null) }

    @Synchronized
    private fun publicKey(): PublicKey {
        val store = keyStore()
        if (!store.containsAlias(RSA_ALIAS)) createRsaKey()
        val keystorePublic = store.getCertificate(RSA_ALIAS).publicKey
        // Cópia fora do Keystore, para cifrar sem as restrições de uso da chave privada.
        return KeyFactory.getInstance(keystorePublic.algorithm).generatePublic(X509EncodedKeySpec(keystorePublic.encoded))
    }

    private fun createRsaKey() {
        val builder = KeyGenParameterSpec.Builder(RSA_ALIAS, KeyProperties.PURPOSE_DECRYPT or KeyProperties.PURPOSE_ENCRYPT)
            .setKeySize(2048)
            .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA1)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
            .setUserAuthenticationRequired(true)
            // Cadastrar uma digital nova não apaga o cofre (o PIN também desbloqueia).
            .setInvalidatedByBiometricEnrollment(false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            builder.setUserAuthenticationParameters(
                AUTH_SECONDS,
                KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL,
            )
        } else {
            @Suppress("DEPRECATION")
            builder.setUserAuthenticationValidityDurationSeconds(AUTH_SECONDS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) builder.setUnlockedDeviceRequired(true)
        val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, KEYSTORE)
        generator.initialize(builder.build())
        generator.generateKeyPair()
    }

    @Synchronized
    private fun hmacKey(): SecretKey {
        val store = keyStore()
        (store.getKey(HMAC_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, KEYSTORE)
        generator.init(KeyGenParameterSpec.Builder(HMAC_ALIAS, KeyProperties.PURPOSE_SIGN).build())
        return generator.generateKey()
    }

    /** "chaveEmbrulhada:iv:textoCifrado" em Base64, ou null se o aparelho não permitir. */
    fun encrypt(plain: String): String? = try {
        val aesKey = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
        val aes = Cipher.getInstance(AES)
        aes.init(Cipher.ENCRYPT_MODE, aesKey)
        val encrypted = aes.doFinal(plain.toByteArray(Charsets.UTF_8))
        val rsa = Cipher.getInstance(RSA)
        rsa.init(Cipher.ENCRYPT_MODE, publicKey(), OAEP)
        val wrapped = rsa.doFinal(aesKey.encoded)
        listOf(wrapped, aes.iv, encrypted).joinToString(":") { Base64.encodeToString(it, Base64.NO_WRAP) }
    } catch (e: GeneralSecurityException) {
        null
    } catch (e: RuntimeException) {
        // Sem bloqueio de tela o Keystore recusa criar chave com autenticação; defeitos do Keystore
        // (ProviderException) também caem aqui. A senha simplesmente não é salva.
        null
    }

    fun decrypt(stored: String): VaultDecrypt = try {
        val parts = stored.split(':').map { Base64.decode(it, Base64.NO_WRAP) }
        if (parts.size != 3) {
            VaultDecrypt.Failed
        } else {
            val privateKey = keyStore().getKey(RSA_ALIAS, null) as? PrivateKey
            if (privateKey == null) {
                VaultDecrypt.Failed
            } else {
                val rsa = Cipher.getInstance(RSA)
                rsa.init(Cipher.DECRYPT_MODE, privateKey, OAEP)
                val aesBytes = rsa.doFinal(parts[0])
                val aes = Cipher.getInstance(AES)
                aes.init(Cipher.DECRYPT_MODE, javax.crypto.spec.SecretKeySpec(aesBytes, "AES"), GCMParameterSpec(128, parts[1]))
                VaultDecrypt.Success(String(aes.doFinal(parts[2]), Charsets.UTF_8))
            }
        }
    } catch (e: UserNotAuthenticatedException) {
        VaultDecrypt.NeedsAuthentication
    } catch (e: GeneralSecurityException) {
        VaultDecrypt.Failed
    } catch (e: RuntimeException) {
        VaultDecrypt.Failed
    }

    /** Impressão da senha para comparar sem decifrar. Null se o Keystore falhar. */
    fun fingerprint(origin: String, username: String, password: String): String? = try {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(hmacKey())
        val bytes = mac.doFinal("$origin\u0000$username\u0000$password".toByteArray(Charsets.UTF_8))
        Base64.encodeToString(bytes, Base64.NO_WRAP)
    } catch (e: GeneralSecurityException) {
        null
    } catch (e: RuntimeException) {
        null
    }
}
