package com.gabbrowser.core.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "history", indices = [Index("url"), Index("visitedAt")])
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val visitedAt: Long,
)

@Entity(tableName = "bookmarks", indices = [Index(value = ["url"], unique = true)])
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val createdAt: Long,
    /** Pasta do favorito; null = sem pasta. Coluna criada na versão 2 do banco. */
    val folderId: Long? = null,
)

@Entity(tableName = "bookmark_folders")
data class BookmarkFolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
)

/** Download iniciado pelo app. O id é o do DownloadManager do Android. */
@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: Long,
    val fileName: String,
    val url: String,
    val mimeType: String?,
    val createdAt: Long,
)

data class MostVisitedRow(
    val url: String,
    val title: String,
    val visits: Int,
)

@Dao
interface HistoryDao {
    @Insert
    suspend fun insert(entry: HistoryEntity): Long

    @Query(
        "SELECT * FROM history WHERE id IN (SELECT MAX(id) FROM history GROUP BY url) " +
            "ORDER BY visitedAt DESC LIMIT :limit",
    )
    fun recent(limit: Int): Flow<List<HistoryEntity>>

    @Query(
        "SELECT url, MAX(title) AS title, COUNT(*) AS visits FROM history " +
            "GROUP BY url ORDER BY visits DESC, MAX(visitedAt) DESC LIMIT :limit",
    )
    fun mostVisited(limit: Int): Flow<List<MostVisitedRow>>

    @Query(
        "SELECT * FROM history WHERE (:query = '' OR url LIKE '%' || :query || '%' OR title LIKE '%' || :query || '%') " +
            "ORDER BY visitedAt DESC LIMIT :limit",
    )
    fun search(query: String, limit: Int): Flow<List<HistoryEntity>>

    @Query("DELETE FROM history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM history WHERE url = :url")
    suspend fun deleteByUrl(url: String)

    @Query("DELETE FROM history")
    suspend fun clear()
}

@Dao
interface BookmarkDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(bookmark: BookmarkEntity): Long

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun deleteByUrl(url: String)

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun all(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE url = :url)")
    fun isBookmarked(url: String): Flow<Boolean>

    @Query("UPDATE bookmarks SET title = :title, folderId = :folderId WHERE id = :id")
    suspend fun update(id: Long, title: String, folderId: Long?)

    @Query("SELECT * FROM bookmark_folders ORDER BY name COLLATE NOCASE")
    fun folders(): Flow<List<BookmarkFolderEntity>>

    @Insert
    suspend fun insertFolder(folder: BookmarkFolderEntity): Long

    @Query("UPDATE bookmark_folders SET name = :name WHERE id = :id")
    suspend fun renameFolder(id: Long, name: String)

    @Query("UPDATE bookmarks SET folderId = NULL WHERE folderId = :folderId")
    suspend fun detachFromFolder(folderId: Long)

    @Query("DELETE FROM bookmark_folders WHERE id = :id")
    suspend fun deleteFolderRow(id: Long)
}

@Dao
interface DownloadDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(download: DownloadEntity)

    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun all(): Flow<List<DownloadEntity>>

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: Long)
}

@Database(
    entities = [
        HistoryEntity::class,
        BookmarkEntity::class,
        BookmarkFolderEntity::class,
        DownloadEntity::class,
    ],
    version = 2,
    exportSchema = false,
)
abstract class GabDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao

    abstract fun bookmarkDao(): BookmarkDao

    abstract fun downloadDao(): DownloadDao

    companion object {
        /** Versão 0.2 → 0.3: pastas de favoritos e lista de downloads. Histórico e favoritos são mantidos. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `bookmarks` ADD COLUMN `folderId` INTEGER")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `bookmark_folders` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL)",
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `downloads` (" +
                        "`id` INTEGER NOT NULL, " +
                        "`fileName` TEXT NOT NULL, " +
                        "`url` TEXT NOT NULL, " +
                        "`mimeType` TEXT, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`id`))",
                )
            }
        }
    }
}
