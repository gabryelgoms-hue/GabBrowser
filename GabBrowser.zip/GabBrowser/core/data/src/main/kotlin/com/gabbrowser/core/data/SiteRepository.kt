package com.gabbrowser.core.data

import android.content.Context
import android.net.Uri
import androidx.room.Room
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class SiteLink(
    val url: String,
    val title: String,
)

data class Bookmark(
    val id: Long,
    val url: String,
    val title: String,
    val folderId: Long?,
)

data class BookmarkFolder(
    val id: Long,
    val name: String,
)

data class HistoryItem(
    val id: Long,
    val url: String,
    val title: String,
    val visitedAt: Long,
)

/** Favoritos e histórico. Tudo fica somente no aparelho. */
class SiteRepository(database: GabDatabase) {

    private val history = database.historyDao()
    private val bookmarkDao = database.bookmarkDao()

    val bookmarks: Flow<List<SiteLink>> =
        bookmarkDao.all().map { list -> list.map { SiteLink(it.url, it.title) } }

    val bookmarkEntries: Flow<List<Bookmark>> =
        bookmarkDao.all().map { list -> list.map { Bookmark(it.id, it.url, it.title, it.folderId) } }

    val folders: Flow<List<BookmarkFolder>> =
        bookmarkDao.folders().map { list -> list.map { BookmarkFolder(it.id, it.name) } }

    val recentHistory: Flow<List<SiteLink>> =
        history.recent(limit = 6).map { list -> list.map { SiteLink(it.url, it.title) } }

    /** Agrupado por site: várias páginas do google.com viram um único atalho para o google.com. */
    val mostVisited: Flow<List<SiteLink>> =
        history.mostVisited(limit = 200).map { rows ->
            rows.mapNotNull { row ->
                val host = Uri.parse(row.url).host?.lowercase() ?: return@mapNotNull null
                Triple(host.removePrefix("www."), host, row.visits)
            }
                .groupBy { it.first }
                .map { (site, entries) ->
                    // entries já vem do mais visitado para o menos; usa o host desse para o link.
                    SiteLink(url = "https://${entries.first().second}/", title = site) to entries.sumOf { it.third }
                }
                .sortedByDescending { it.second }
                .take(8)
                .map { it.first }
        }

    fun searchHistory(query: String): Flow<List<HistoryItem>> =
        history.search(query.trim(), limit = 500).map { list ->
            list.map { HistoryItem(it.id, it.url, it.title, it.visitedAt) }
        }

    fun isBookmarked(url: String): Flow<Boolean> = bookmarkDao.isBookmarked(url)

    suspend fun recordVisit(url: String, title: String) {
        history.insert(HistoryEntity(url = url, title = title, visitedAt = System.currentTimeMillis()))
    }

    suspend fun deleteHistoryEntry(id: Long) = history.deleteById(id)

    /** Remove todas as visitas a esta página (some também de "Mais acessados"). */
    suspend fun deleteHistoryUrl(url: String) = history.deleteByUrl(url)

    suspend fun clearHistory() = history.clear()

    suspend fun addBookmark(url: String, title: String) {
        bookmarkDao.insert(BookmarkEntity(url = url, title = title, createdAt = System.currentTimeMillis()))
    }

    suspend fun removeBookmark(url: String) {
        bookmarkDao.deleteByUrl(url)
    }

    suspend fun deleteBookmark(id: Long) = bookmarkDao.deleteById(id)

    suspend fun updateBookmark(id: Long, title: String, folderId: Long?) =
        bookmarkDao.update(id, title.trim(), folderId)

    suspend fun createFolder(name: String): Long =
        bookmarkDao.insertFolder(BookmarkFolderEntity(name = name.trim(), createdAt = System.currentTimeMillis()))

    suspend fun renameFolder(id: Long, name: String) = bookmarkDao.renameFolder(id, name.trim())

    /** Exclui a pasta; os favoritos dela continuam, sem pasta. */
    suspend fun deleteFolder(id: Long) {
        bookmarkDao.detachFromFolder(id)
        bookmarkDao.deleteFolderRow(id)
    }
}

object GabData {
    @Volatile
    private var database: GabDatabase? = null

    fun database(context: Context): GabDatabase =
        database ?: synchronized(this) {
            database ?: Room.databaseBuilder(
                context.applicationContext,
                GabDatabase::class.java,
                "gabbrowser.db",
            )
                .addMigrations(GabDatabase.MIGRATION_1_2)
                .build()
                .also { database = it }
        }

    fun siteRepository(context: Context): SiteRepository = SiteRepository(database(context))
}
